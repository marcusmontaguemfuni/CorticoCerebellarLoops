"""
experiment_running.py

This module defines classes to manage training, evaluation, and analysis of meta-learning experiments.
It integrates model configuration, dataset generation, training loop orchestration, and analysis methods
including decoding and activation pattern extraction. Supports single-run and multi-seed experiments.
"""

import copy
from pathlib import Path
from typing import Union, Optional, Dict, Any
import numpy as np
import torch
import torch.nn as nn
from src.analysis.representations import decode_across_epochs_and_time
from src.analysis.utils import get_models_activations
from src.data.data_generation import DataGenerator
from src.models.model_factory import load_checkpoint_models
from src.models.experiment_network import ExperimentNetwork
from src.training.trainers.StandardTrainer import StandardTrainer
from src.utils.config_handling import load_config
from src.training.trainers.LoraTrainer import LoRATrainer, LoRAOutputLayer

class Experiment:
    """
    Manages a single model experiment with representational analysis.

    This class handles the setup, training, and analysis of a single experiment run. 
    It integrates configuration loading, model initialization, training logic, and 
    analysis routines like decoding and representation extraction.
    """
    def __init__(self,
                 config_path: Optional[Union[str, Path]] = None,
                 config: Optional[Dict[str, Any]] = None,
                 variant_name: Optional[str] = None):
        """
        Initialize the Experiment with optional config file path, config dictionary, and variant name.

        Args:
            config_path (Optional[str or Path]): Path to the configuration file.
            config (Optional[dict]): Configuration dictionary (overrides config_path if provided).
            variant_name (Optional[str]): Name of the experiment variant (for saving or labeling).
        """
        self.config_path = Path(config_path) if config_path else None
        self.config = config
        self.variant_name = variant_name
        self.data_generator = None
        self.model = None
        self.trainer = None
        self.training_results = None
        self.decoding_scores = None

    def setup(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize experiment components: configuration, data generator, model, and trainer.

        Args:
            config (Optional[Dict[str, Any]]): Optional configuration dictionary to override default.
        """
        # Step 1: Load config from argument or file
        if config is not None:
            self.config = config
        elif self.config is None:
            if self.config_path is None:
                raise ValueError("Either config or config_path must be provided")
            self.config = load_config(self.config_path)

        # Step 2: Initialize the DataGenerator with loaded config
        self.data_generator = DataGenerator(config=self.config)
        self.data_generator.set_seed(self.config['reproducibility']['seed'])

        # Step 3: Build the model using the experiment-specific architecture
        ExperimentNetwork.set_seed(self.config['reproducibility']['seed'])
        self.model = ExperimentNetwork(
            plasticity_params=self.config['plasticity'],
            controller_params=self.config['model']['controller'],
            rnd_input_params=self.config['model']['random_input'],
            learning_rule= self.config['model']['learning_rule'],
            learning_rule_params= self.config['model']['learning_rule_params'],
            **self.config['model']['network']
        )
        self.model.to(device=self.config['hardware']['device'])

        # Step 4: Create the training loop controller
        if self.model.model.learning_rule == 'lora':
            print(f"Trainer initialized with config: {self.config}")
            self.trainer = LoRATrainer(self.model, self.config, self.data_generator)
        elif self.model.model.learning_rule == 'standard_bp':
            self.trainer = StandardTrainer(self.model, self.config, self.data_generator)
        else:
            raise ValueError(f"Unsupported learning rule: {self.model.model.learning_rule}")

    def run(self):
        """
        Run the training process for the current experiment.

        This method delegates to the trainer to carry out training and stores
        the resulting metrics and state changes.
        """
        self.training_results = self.trainer.train()

    def analyse(self):
        """
        Run post-training representational analysis.

        This triggers internal decoding and activation pattern analysis to populate
        decoding-related result metrics.
        """
        self._analyze_representations()

    @property
    def results(self):
        """
        Access all results generated from the experiment.

        Returns:
            dict: Dictionary containing training and decoding results.
        """
        return {
            'training_results': self.training_results,
            'decoding_scores': self.decoding_scores,
            'xgen_decoding_scores': self.decoding_scores,
        }
    
    def _analyze_representations(self):
        """
        Analyze internal model representations using decoding.

        This method:
        - Loads all model checkpoints from the training run.
        - Generates validation data using a fixed seed.
        - Extracts time-averaged activations from the stimulus window.
        - Computes decoding and cross-generalization scores across epochs.
        """
        # Load models from checkpoint directory
        checkpoint_path = Path(self.config['training']['checkpoint_path'])
        models = load_checkpoint_models(checkpoint_path)

        # Create a fresh data generator for validation
        val_generator = DataGenerator(config=self.config)
        val_generator.set_seed(31)  # Fixed seed for reproducibility

        # Generate validation data with trial type labels
        X, y, trial_types = val_generator.generate_data(
            input_noise_std=self.config['data']['input_noise_std'],
            n_trials=512,
            return_trial_types=True
        )

        # Generate temporal output mask (used for loss weighting during reward periods only)
        mask = val_generator.generate_mask(mask_format='bool')

        # Get activations for all models (shape: models x trials x time x features)
        activations, _ = get_models_activations(models, X, y, mask)

        # Time-average activations over reward stimulus period (time steps 49 to 74)
        activations_time_averaged = np.mean(
            activations[:, :, 49:74, :],
            axis=2,
            keepdims=True
        )
        # Compute decoding accuracy across time and epochs
        self.decoding_scores = decode_across_epochs_and_time(
            activations_time_averaged,
            trial_types
        )


class ExperimentRunner:
    """
    Manages multiple experiment runs with different configurations and seeds.

    This class automates running a series of experiments based on different
    configuration variants and random seeds. It also supports training across
    multiple phases by saving and loading models between runs.
    """

    def __init__(self, config_path: Union[str, Path]):
        """
        Initialize the experiment runner with a base configuration path.

        Args:
            config_path (str or Path): Path to the main configuration file.
        """
        self.config_path = Path(config_path)
        self.base_config = load_config(self.config_path)
        self.results = {}        # Stores training and decoding results per variant
        self.model_paths = {}    # Stores checkpoint paths per variant and seed
        self.trained_models = {} # Stores trained model instances for reuse across phases

    def apply_variant_config(self, base_config, variant_config):
        """
        Apply variant-specific overrides to the base configuration.

        Args:
            base_config (dict): The base configuration dictionary.
            variant_config (dict): Configuration modifications for this variant.

        Returns:
            dict: A modified configuration dictionary.
        """
        modified_config = copy.deepcopy(base_config)

        def deep_update(d, u):
            for k, v in u.items():
                if k == "name":  # Skip reserved name key
                    continue
                if isinstance(v, dict) and k in d and isinstance(d[k], dict):
                    deep_update(d[k], v)
                else:
                    d[k] = v

        deep_update(modified_config, variant_config)
        return modified_config

    def run_experiments(self, variants, speed=False):
        """
        Run a suite of experiments for each variant and seed combination.

        Args:
            variants (list): A list of configuration variant dictionaries.
        """
        # Determine if multiple seeds should be used
        seed_cfg = self.base_config['reproducibility']
        run_multiple = seed_cfg.get('run_multiple', False)

        # Generate list of seeds to use
        if run_multiple:
            base_seed = seed_cfg.get('seed')
            n_seeds = seed_cfg.get('n_seeds')
            seed_step = seed_cfg.get('seed_increment')
            seeds = [base_seed + i * seed_step for i in range(n_seeds)]
        else:
            seeds = [seed_cfg.get('seed')]

        for variant in variants:
            variant_name = variant.get("name", "unnamed")
            phase = variant.get("phase", 1)
            print(f"\n================ RUNNING: {variant_name.upper()} (PHASE {phase}) ================")

            # Initialize storage for results
            self.results[variant_name] = {
                'training_results': [],
                'decoding_scores': [],
                'xgen_decoding_scores': [],
            }
            self.model_paths[variant_name] = {}

            # Apply the variant-specific config
            variant_config = self.apply_variant_config(self.base_config, variant)

            for seed_idx, seed in enumerate(seeds):
                print(f"Running experiment {seed_idx + 1}/{len(seeds)} with seed {seed}")

                # Update config with current seed
                current_config = copy.deepcopy(variant_config)
                current_config['reproducibility']['seed'] = seed

                # Update checkpoint path with phase and variant metadata
                checkpoint_base = Path(current_config['training']['checkpoint_path'])
                phase_prefix = f"phase{phase}_" if phase > 1 else ""
                ckpt_name = f"{checkpoint_base.stem}_{phase_prefix}{variant_name}_seed{seed}{checkpoint_base.suffix}"
                current_config['training']['checkpoint_path'] = str(checkpoint_base.parent / ckpt_name)

                # Initialize and set up experiment
                experiment = Experiment(config=current_config, variant_name=variant_name)
                experiment.setup()
                #experiment.data_generator.plot_experiment_summary()

                # For multi-phase experiments, try to load previous phase model
                if phase > 1:
                    base_name = variant_name.split('_phase')[0] if '_phase' in variant_name else variant_name
                    previous_key = f"{base_name}_seed{seed}"
                    if previous_key in self.trained_models:
                        print(f"Loading weights from previous phase for {previous_key}")
                        if current_config['model']['learning_rule'] == 'lora':
                            # For LoRA, expand previous basis vectors size in the newly initialized model before loading
                            # in the previous model's state_dict. This is beccause the model will be initalized with empty
                            # LoRA basis vectors, but we want to expand this to the size of the previous phase's basis vectors
                            # and allow them to be copied in.
                            # Manually match expected shapes before loading state_dict
                            controller = experiment.model.model.controller
                            src_ctrl = self.trained_models[previous_key].model.controller
                            # controller.expand_past_basis_like(src_ctrl.LoRACtrl_prev_inpt_basis, src_ctrl.LoRACtrl_prev_outpt_basis)

                            # if isinstance(experiment.model.model.output_layer, LoRAOutputLayer):
                            #     experiment.model.model.output_layer.expand_past_basis(phase_number=phase)
                        experiment.model.load_state_dict(self.trained_models[previous_key].state_dict())
                    else:
                        print(f"Warning: No previous phase model found for {previous_key}")

                # Run training and analysis
                # If speed is True, skip decoding analysis and just run training
                experiment.run()
                if speed:
                    sillyvariable = 420
                else:
                    experiment.analyse()

                # Store trained model for use in future phases
                model_key = f"{variant_name}_seed{seed}"
                self.trained_models[model_key] = experiment.model

                # Store experiment results
                self.results[variant_name]['training_results'].append(experiment.results['training_results'])
                if speed:
                    sillyvariable = 420
                else:
                    self.results[variant_name]['decoding_scores'].append(experiment.results['decoding_scores'][0, :, 0, :])
                    self.results[variant_name]['xgen_decoding_scores'].append(experiment.results['decoding_scores'][1, :, 0, :])
