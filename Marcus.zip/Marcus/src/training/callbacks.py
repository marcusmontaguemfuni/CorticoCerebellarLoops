"""
callbacks.py

Defines utility classes for saving model checkpoints and implementing
training callbacks. These are used within the training loop to track
progress and persist model state at defined intervals.

Includes:
- Base Callback class
- ModelCheckpoint class to periodically save model weights
- Custom exceptions for checkpoint management
"""

import os
from copy import deepcopy
from pathlib import Path
import torch
from abc import ABC, abstractmethod


# -----------------------------
# Custom Exceptions
# -----------------------------

class CheckpointError(Exception):
    """Raised for errors related to checkpoint operations."""
    pass

class DuplicateModelError(CheckpointError):
    """Raised when a model with identical config already exists at path."""
    pass

class CheckpointIOError(CheckpointError):
    """Raised when file read/write fails during checkpointing."""
    pass


# -----------------------------
# Callback Base Class
# -----------------------------

class Callback(ABC):
    """
    Abstract base class for training callbacks.
    Subclasses should implement behavior on specific training events.
    """

    @abstractmethod
    def on_epoch_end(self, epoch: int, model: torch.nn.Module) -> None:
        """
        Triggered at the end of each epoch.
        Subclasses define what should happen (e.g., save checkpoint).
        """
        pass


# -----------------------------
# Model Checkpointing
# -----------------------------

class ModelCheckpoint(Callback):
    """
    Periodically saves model weights and config to disk during training.
    """

    def __init__(self, filepath: str, save_frequency: int, config: dict):
        """
        Args:
            filepath (str): Full path to the .pt file to save checkpoints.
            save_frequency (int): Save model every N epochs.
            config (dict): Model configuration used to verify uniqueness.
        """
        self.filepath = Path(filepath)
        self.save_frequency = save_frequency
        self.config = config
        self._validate_and_setup()

    def _validate_and_setup(self) -> None:
        """
        Ensure save path is valid and either clear or raise if file exists.
        Honors checkpoint_overwrite flag in config['training'].
        """
        self.filepath.parent.mkdir(parents=True, exist_ok=True)

        if self.filepath.exists() and not os.access(self.filepath, os.W_OK):
            raise CheckpointIOError(f"No write permission for {self.filepath}")

        overwrite = self.config.get('training', {}).get('checkpoint_overwrite', False)

        if self.filepath.exists():
            if overwrite:
                print(f"Warning: Overwriting existing checkpoint file at {self.filepath}")
                self.filepath.unlink()  # Clear old checkpoint
            else:
                raise DuplicateModelError(
                    f"Checkpoint file already exists. "
                    f"Use a different path or set checkpoint_overwrite=True."
                )

    def _configs_match(self, config1: dict, config2: dict) -> bool:
        """
        Recursively compare configs, ignoring runtime-specific or transient keys.
        Used to detect model duplication across runs.

        Args:
            config1 (dict): Reference config
            config2 (dict): Config to compare

        Returns:
            bool: True if configs are functionally identical
        """
        runtime_keys = {
            'hardware': {'device', 'precision'},
            'data': {'num_workers'},
        }
        top_level_ignore = {'seed'}

        def _compare_dicts(d1: dict, d2: dict, path="") -> bool:
            """
            Recursively compare two configuration dictionaries to determine if they are functionally equivalent,
            ignoring runtime- or hardware-specific differences.

            Args:
                d1 (dict): First dictionary to compare
                d2 (dict): Second dictionary to compare
                path (str): Dot-separated path used for recursion tracking (e.g., 'training.optimizer')

            Returns:
                bool: True if the dictionaries are equal ignoring irrelevant keys, False otherwise
            """
            # First check if both dictionaries have exactly the same keys
            if set(d1.keys()) != set(d2.keys()):
                return False

            for k in d1:
                # Ignore specified top-level keys (e.g., 'seed') if we're at the root
                if not path and k in top_level_ignore:
                    continue

                # Compute full path to key and top-level parent for runtime key skipping
                full_path = f"{path}.{k}" if path else k
                parent = full_path.split('.')[0]

                # Skip this key if it's part of runtime-specific exclusions (e.g., 'device' in 'hardware')
                if parent in runtime_keys and k in runtime_keys[parent]:
                    continue

                v1, v2 = d1[k], d2[k]

                # Recursively compare sub-dictionaries
                if isinstance(v1, dict) and isinstance(v2, dict):
                    if not _compare_dicts(v1, v2, full_path):
                        return False
                elif v1 != v2:
                    return False

            return True

        return _compare_dicts(config1, config2)

    def on_epoch_end(self, epoch: int, model: torch.nn.Module) -> None:
        """
        Save a checkpoint if current epoch matches the save frequency.
        """
        if (epoch + 1) % self.save_frequency == 0:
            self._save_checkpoint(epoch, model)

    def _save_checkpoint(self, epoch: int, model: torch.nn.Module) -> None:
        """
        Save model weights and training metadata to disk.

        Args:
            epoch (int): Current training epoch
            model (torch.nn.Module): Model instance to save
        """
        try:
            # Load or initialize checkpoint structure
            if self.filepath.exists():
                checkpoint_data = torch.load(self.filepath)
            else:
                checkpoint_data = {
                    'config': deepcopy(self.config),
                    'checkpoints': {}
                }

            checkpoint_data['checkpoints'][f'epoch_{epoch + 1}'] = {
                'model_state': deepcopy(model.state_dict())
            }

            torch.save(checkpoint_data, self.filepath)

        except Exception as e:
            raise CheckpointIOError(f"Failed to save checkpoint: {str(e)}")
