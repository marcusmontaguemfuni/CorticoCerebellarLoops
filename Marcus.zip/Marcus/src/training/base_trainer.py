"""
Abstract base trainer class for implementing different learning rules' training algorithms.

This module defines a shared interface for training models using different
learning rules/algorithms such as Standard training or MAML.

Common utility methods such as forward passes, loss computation, and accuracy
metrics are implemented here, while specific training strategies should be
defined in subclasses that implement the abstract `train_epoch` and `train` methods.
"""

from abc import ABC, abstractmethod
from typing import Dict, Optional, Tuple, List
import torch
import numpy as np
from tqdm import tqdm
from torch.nn import CrossEntropyLoss, MSELoss
from src.training.callbacks import ModelCheckpoint, CheckpointError
from src.training.metrics import MetricsTracker


class BaseNetworkTrainer(ABC):

    def __init__(self, model, config: dict, data_generator):
        self.device = config['hardware']['device']
        self.model = model
        self.config = config
        self.train_config = config['training']
        self.data_generator = data_generator

        # Group model parameters into two sets for differential learning rates:
        # Group 0 = core RNN layers (input2h and h2h) → lr_rnn
        # Group 1 = all other trainable components (output layer, controller) → lr_controller
        param_groups = [
            {'params': [], 'lr': self.train_config['lr_rnn']},         # Core RNN weights
            {'params': [], 'lr': self.train_config['lr_controller']}   # Output & controller
        ]

        # Assign parameters to the appropriate group based on their names
        for name, param in self.model.named_parameters():
            if 'model.input2h' in name or 'model.h2h' in name:
                param_groups[0]['params'].append(param)
            else:
                param_groups[1]['params'].append(param)

        # Instantiate optimizer using specified type from config (e.g., 'Adam', 'SGD')
        optimizer_class = getattr(torch.optim, self.train_config['optimizer'])
        self.optimizer = optimizer_class(
            param_groups,
            weight_decay=self.train_config['weight_decay']
        )
        
        # Initialize model checkpointing if configured
        if self.train_config.get('checkpoint_path'):
            self.checkpoint = ModelCheckpoint(
                filepath=self.train_config['checkpoint_path'],
                save_frequency=self.train_config['checkpoint_frequency'],
                config=config
            )
        else:
            self.checkpoint = None

        # Loss function
        if self.train_config['loss_type'] == 'mse':
            self.criterion = MSELoss()
        elif self.train_config['loss_type'] == 'crossentropy':
            self.criterion = CrossEntropyLoss()
        else:
            raise ValueError(f"Invalid loss_type: {self.train_config['loss_type']}. Must be 'mse' or 'crossentropy'")

        self.metrics = MetricsTracker(model.get_weights(), num_tasks=len(data_generator.task_indices))
        self.loss_mask = data_generator.generate_mask(mask_format='bool')

    def _forward_pass(self, inputs: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, Optional[torch.Tensor]]:
        """
        Run a single forward pass through the model.

        Returns:
            - outputs: model output tensor [T, B, O]
            - hidden_states: hidden state activations [T, B, H]
            - controller_outputs (optional): controller outputs [T, B, C] if controller is enabled
        """
        # Check if the controller is enabled in the CCtRNN model
        if self.model.model.controller_enabled:
            outputs, hidden_states, controller_outputs = self.model(inputs)
            return outputs, hidden_states, controller_outputs
        # Otherwise return just outputs and hidden states
        outputs, hidden_states = self.model(inputs)
        return outputs, hidden_states, None

    def _compute_loss(self, outputs: torch.Tensor, targets: torch.Tensor, hidden_states: torch.Tensor) -> torch.Tensor:
        """
        Compute the total loss (prediction + activity regularization) for the current batch.

        Args:
            outputs: Model predictions [T, B, O]
            targets: Ground truth targets [T, B, O]
            hidden_states: Hidden state activations [T, B, H]

        Returns:
            Computed loss (scalar tensor)
        """
        # Apply boolean mask to select timepoints for which loss should be computed
        outputs_masked = outputs[self.loss_mask, :, :]
        targets_masked = targets[self.loss_mask, :, :]

        # Flatten across time and batch dimensions for loss calculation
        outputs_flat = outputs_masked.reshape(-1, outputs_masked.shape[-1])
        targets_flat = targets_masked.reshape(-1, targets_masked.shape[-1])


        # Handle different loss types: cross-entropy assumes one-hot target encoding
        if self.train_config['loss_type'] == 'crossentropy':
            targets_indices = torch.argmax(targets_flat, dim=1)
            loss = self.criterion(outputs_flat, targets_indices)
        else:
            loss = self.criterion(outputs_flat, targets_flat)

        # Add optional L2 regularization on hidden state activity
        loss += self.train_config['activations_l2'] * torch.norm(hidden_states)
        return loss

    def _compute_accuracy(self, predictions: torch.Tensor, targets: torch.Tensor) -> float:
        """
        Compute overall classification accuracy over timepoints and batch.

        This function:
        - Applies a boolean loss mask to focus on relevant time steps.
        - Flattens the predictions and targets across time and batch dimensions.
        - Compares predicted class (argmax) to ground truth class (argmax).
        - Returns average classification accuracy across all masked elements.

        Args:
            predictions: [T, B, O] tensor of model output logits
            targets: [T, B, O] tensor of one-hot encoded ground truth labels

        Returns:
            Scalar float representing overall accuracy (between 0 and 1)
        """
        # Apply loss mask to restrict to relevant timepoints
        pred_masked = predictions[self.loss_mask, :, :]    # [T_masked, B, O]
        targets_masked = targets[self.loss_mask, :, :]     # [T_masked, B, O]

        # Flatten predictions and targets across time and batch dimensions
        pred_flat = pred_masked.reshape(-1, pred_masked.shape[-1])      # [(T*B), O]
        targets_flat = targets_masked.reshape(-1, targets_masked.shape[-1])  # [(T*B), O]

        # Compute accuracy as proportion of correct argmax predictions
        correct = (pred_flat.argmax(1) == targets_flat.argmax(1)).float()
        accuracy = correct.mean().item()

        return accuracy

    def _compute_task_accuracies(self, outputs: torch.Tensor, targets: torch.Tensor, task_labels: torch.Tensor) -> List[float]:
        """
        Compute classification accuracy separately for each task in a multitask setting.

        This function:
        - Transposes outputs and targets to shape [B, T, O] for task-based indexing.
        - For each task:
            - Identifies trials associated with the task.
            - Applies a shared loss mask to extract relevant timepoints.
            - Computes accuracy for that subset of trials.
        - Returns a list of per-task accuracies.

        Args:
            outputs: [T, B, O] model output logits
            targets: [T, B, O] one-hot encoded target labels
            task_labels: [B] tensor of integer task IDs


        Returns:
            List of float accuracies, one per task
        """
        task_accuracies = []

        # Transpose from [T, B, O] to [B, T, O] for trial-level masking
        outputs = outputs.transpose(0, 1)
        targets = targets.transpose(0, 1)

        # Loop over all task indices and evaluate separately
        for task_idx in range(self.metrics.num_tasks):
            task_mask = task_labels == task_idx  # Identify which trials belong to this task

            if task_mask.any():
                # Select only the trials for this task
                outputs_task = outputs[task_mask]  # [task_batch_size, T, O]
                targets_task = targets[task_mask]  # [task_batch_size, T, O]

                # Apply the loss mask across time dimension
                loss_mask = self.loss_mask.squeeze(-1)  # [T]
                outputs_masked = outputs_task[:, loss_mask, :]  # [task_batch_size, masked_T, O]
                targets_masked = targets_task[:, loss_mask, :]  # [task_batch_size, masked_T, O]

                # Flatten across batch and time for accuracy computation
                outputs_flat = outputs_masked.reshape(-1, outputs_masked.shape[-1])
                targets_flat = targets_masked.reshape(-1, targets_masked.shape[-1])

                acc = (outputs_flat.argmax(1) == targets_flat.argmax(1)).float().mean().item()
                task_accuracies.append(acc)
            else:
                # No examples for this task in batch
                task_accuracies.append(0.0)

        return task_accuracies

    @abstractmethod
    def train_epoch(self, dataloader) -> Tuple[float, float, torch.Tensor]:
        # Subclasses implement a single training epoch (forward, loss, backward, update)
        pass

    @abstractmethod
    def train(self) -> Dict:
        # Subclasses implement the full training loop across all epochs
        pass