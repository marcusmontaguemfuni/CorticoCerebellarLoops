"""
metrics.py

MetricsTracker class for tracking training metrics in modular networks,
including multitask learning support and compatibility with user-defined ExperimentalNetwork models.
"""
from typing import Dict, Optional, List
import numpy as np
import torch


class MetricsTracker:
    """
    Tracks and stores key training metrics for neural network models, including:
        - Layer-wise gradient norms
        - Layer-wise weight norms (to monitor weight changes)
        - Training losses and accuracies
        - Firing rates (mean activity of hidden states)
        - Per-task accuracies for multitask learning

    Designed for compatibility with modular models (e.g., ExperimentalNetwork),
    where layers and weights are accessed via model.get_weights() and
    gradients via model.get_gradient(name).
    """
    def __init__(self, initial_weights: Dict[str, torch.Tensor], num_tasks: Optional[int] = None):
        """
        Args:
            initial_weights: Dict mapping layer names to their initial weight tensors.
            num_tasks: If multitask learning, number of tasks (for per-task accuracy tracking).
        """
        # Store initial weights for later comparison
        self.initial_weights = initial_weights
        self.final_weights = []

        # Track gradient norms per layer (list of epoch-averaged norms)
        self.gradient_history = {name: [] for name in initial_weights.keys()}
        # Track weight norms per layer (list of norms at each epoch)
        self.weight_changes = {name: [] for name in initial_weights.keys()}

        # Track scalar loss and accuracy per epoch
        self.train_losses = []
        self.train_accuracies = []

        # Store mean firing rates (mean activity of hidden states) per epoch
        self.firing_rates = []

        # Temporary storage for gradients within the current epoch
        self._epoch_gradients = {name: [] for name in initial_weights.keys()}

        # Multitask learning support
        self.num_tasks = num_tasks
        if num_tasks is not None:
            # List of lists: train_accuracies_per_task[task][epoch]
            self.train_accuracies_per_task = [[] for _ in range(num_tasks)]

        # Store initial weight norms for all layers
        for name, weight in initial_weights.items():
            self.weight_changes[name].append(weight.norm().item())

    def update_epoch(self, model, loss: float, accuracy: float, hidden_states: torch.Tensor, task_accuracies: Optional[List[float]] = None):
        """
        Call at the end of each training epoch to update tracked metrics.

        Args:
            model: The network model (should provide get_weights()).
            loss: Training loss for the epoch.
            accuracy: Training accuracy for the epoch.
            hidden_states: Tensor of network activities (to compute mean firing rate).
            task_accuracies: (Optional) List of per-task accuracies (for multitask learning).
        """
        self.train_losses.append(loss)
        self.train_accuracies.append(accuracy)
        # Compute mean firing rate per sample, then average over batch
        self.firing_rates.append(hidden_states.detach().cpu().mean(1))
        # Track new weight norms
        self._update_weights(model.get_weights())
        # Finalize and store average gradient norms for this epoch
        self.finalize_epoch_gradients()

        # If multitask, store per-task accuracy for this epoch
        if task_accuracies is not None and self.num_tasks is not None:
            for task_idx, task_acc in enumerate(task_accuracies):
                self.train_accuracies_per_task[task_idx].append(task_acc)

    def update_gradients(self, model):
        """
        Call after each optimizer step (or batch) to accumulate gradient norms.

        Args:
            model: The network model (should provide _get_layer_mapping() and get_gradient(name)).
        """
        for name in model._get_layer_mapping().keys():
            grad = model.get_gradient(name)
            if grad is not None:
                # Store L2 norm of the gradient for this layer
                self._epoch_gradients[name].append(grad.norm().item())

    def _update_weights(self, current_weights: Dict[str, torch.Tensor]):
        """
        Store current L2 weight norms for each layer.
        """
        for name, weight in current_weights.items():
            self.weight_changes[name].append(weight.norm().item())

    def finalize_epoch_gradients(self):
        """
        At the end of each epoch, average accumulated gradient norms for each layer,
        store in history, and reset accumulators.
        """
        for name in self._epoch_gradients.keys():
            # Average over all gradient norms collected this epoch
            avg_grad = np.mean(self._epoch_gradients[name]) if self._epoch_gradients[name] else 0.0
            self.gradient_history[name].append(avg_grad)
            self._epoch_gradients[name] = []

    def get_results(self, final_weights: Dict[str, torch.Tensor]):
        """
        Collect all tracked metrics into a results dictionary.

        Args:
            final_weights: Dict mapping layer names to their final weights.
        Returns:
            Dictionary of metrics for saving or analysis.
        """
        results = {
            'initial_weights': self.initial_weights,
            'final_weights': final_weights,
            'gradient_history': self.gradient_history,
            'weight_changes': self.weight_changes,
            'train_losses': self.train_losses,
            'train_accuracies': self.train_accuracies,
            # Firing rates shape: (epochs, batch_size) as np.array
            'firing_rates': np.stack([f.detach().cpu().numpy() for f in self.firing_rates])
        }

        if self.num_tasks is not None:
            results['train_accuracies_per_task'] = self.train_accuracies_per_task

        return results
