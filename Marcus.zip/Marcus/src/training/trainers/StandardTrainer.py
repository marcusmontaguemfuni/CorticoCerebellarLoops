"""
StandardTrainer class: Implements a basic supervised training loop for RNN models.

This trainer performs standard outer-loop optimization with gradient descent. It supports both
single-task and multi-task training by dynamically handling input batches with optional task labels.

Key features:
- Computes forward and backward passes
- Supports task-specific accuracy tracking (e.g., for multi-task learning)
- Integrates with the Checkpoint and Metrics systems
- Designed for fixed plasticity models and non-meta-learning training regimes
"""
import numpy as np
import copy
import torch
from typing import Tuple, Dict
from tqdm import tqdm
from colorama import Fore, Style
from src.training.base_trainer import BaseNetworkTrainer
from src.training.callbacks import CheckpointError
from src.data.data_generation import DataGenerator


class StandardTrainer(BaseNetworkTrainer):
    def __init__(self, model, config: dict, data_generator):
        super().__init__(model, config, data_generator)


        # Check if validation checks are desired
        self.val_task_indices = self.config['data'].get('val_indices', None)
        if self.val_task_indices is not None:
            self.static_validation_sets = {}
            self.val_acc_per_epoch = []
            self.val_loss_per_epoch = []
            self._setup_validation()

    def _setup_validation(self):
        """
        Prepares static validation sets for each validation task index.
        """
        if self.val_task_indices is not None:
            for task_idx, temporal_config in self.val_task_indices.items():
                val_config = copy.deepcopy(self.config)
                val_config['data']['task_indices'] = [task_idx]
                val_config['temporal'].update(temporal_config)
                print(f"Setting up validation for task {task_idx} with config: {val_config}")
                val_gen = self.data_generator.__class__(config=val_config)
                val_gen.set_seed(31)
                X, y, _ = val_gen.generate_data(
                    input_noise_std=self.config['data']['input_noise_std'],
                    n_trials=512,
                    return_trial_types=True)

                inputs = X.transpose(0, 1).to(self.device)
                targets = y.transpose(0, 1).to(self.device)

                self.static_validation_sets[task_idx] = (inputs, targets)

    def train(self) -> Dict:

        # Generate a fresh dataloader for this training run
        dataloader = self.data_generator.prepare_dataloader()
        
        # Training loop over epochs
        progress_bar = tqdm(range(self.train_config['n_epochs']), desc='Training')
        for epoch in progress_bar:

            avg_loss, avg_accuracy, hidden_states = self.train_epoch(dataloader)
        
            acc_color = Fore.RED if avg_accuracy < 0.9 else Fore.GREEN
            progress_bar.set_postfix_str(
                f"loss={avg_loss:7.4f}  "
                f"{acc_color}acc={avg_accuracy:5.2f}{Style.RESET_ALL}  "
            )

            # Optionally run validation analysis if specified
            if self.val_task_indices is not None:
                val_metrics = self.run_validation_across_tasks()
                val_accs = {k: v[0] for k, v in val_metrics.items()}
                val_losses = {k: v[1] for k, v in val_metrics.items()}
                self.val_acc_per_epoch.append(val_accs)
                self.val_loss_per_epoch.append(val_losses)

            if self.checkpoint is not None:
                # Optionally save model checkpoint
                try:
                    self.checkpoint.on_epoch_end(epoch, self.model)
                except CheckpointError as e:
                    print(f"Warning: Failed to save checkpoint: {str(e)}")

        results = self.metrics.get_results(self.model.get_weights())
        if self.val_task_indices is not None:
            results['val_acc_per_epoch'] = self.val_acc_per_epoch
            results['val_loss_per_epoch'] = self.val_loss_per_epoch
        return results

    def train_epoch(self, dataloader) -> Tuple[float, float, torch.Tensor]:
        # Lists to accumulate loss and accuracy for the epoch
        epoch_losses = []
        epoch_accuracies = []
        epoch_task_accuracies = [[] for _ in range(self.metrics.num_tasks)]
        final_hidden_states = None
        
        for batch in dataloader:
            if len(batch) == 3:
                # Multi-task setting: task labels provided
                inputs, targets, task_labels = batch
                is_multitask = True
            else:
                # Single-task setting: no task labels
                inputs, targets = batch
                task_labels = None
                is_multitask = False
            
            # Transpose to shape (timesteps, batch, features)
            inputs = inputs.to(self.device).transpose(0, 1)
            targets = targets.to(self.device).transpose(0, 1)
            if task_labels is not None:
                task_labels = task_labels.to(self.device)

            # Forward pass through model (outputs: [T, B, output_dim])
            outputs, hidden_states, _ = self._forward_pass(inputs)
            # Compute loss based on model predictions and ground truth
            loss = self._compute_loss(outputs, targets, hidden_states)
            
            # Backpropagation
            self.optimizer.zero_grad()
            loss.backward()
            self.metrics.update_gradients(self.model)
            self.optimizer.step()
            
            # Track loss and accuracy for this batch
            accuracy = self._compute_accuracy(outputs, targets)
            epoch_losses.append(loss.item())
            epoch_accuracies.append(accuracy)
            if is_multitask:
                task_accs = self._compute_task_accuracies(outputs, targets, task_labels)
                # Accumulate per-task accuracies
                for task_idx in range(self.metrics.num_tasks):
                    epoch_task_accuracies[task_idx].append(task_accs[task_idx])

            final_hidden_states = hidden_states

        # Compute average metrics across batches
        avg_loss = np.mean(epoch_losses)
        avg_accuracy = np.mean(epoch_accuracies)
        task_accuracies = None
        if is_multitask:
            task_accuracies = [np.mean(accs) for accs in epoch_task_accuracies]

        # Update internal metrics tracker
        self.metrics.update_epoch(
            self.model, avg_loss, avg_accuracy, final_hidden_states,
            task_accuracies=task_accuracies
        )
        
        return avg_loss, avg_accuracy, final_hidden_states

    def run_validation_across_tasks(self) -> Dict[int, tuple]:
        """
        Returns a dict mapping task_idx to (accuracy, loss) tuple for each task.
        """
        task_metrics = {}
        for task_idx, (inputs, targets) in self.static_validation_sets.items():
            with torch.no_grad():
                outputs, hidden_states, _ = self._forward_pass(inputs)
                acc = self._compute_accuracy(outputs, targets)
                loss = self._compute_loss(outputs, targets, hidden_states)
                task_metrics[task_idx] = (acc, loss.item())
        return task_metrics