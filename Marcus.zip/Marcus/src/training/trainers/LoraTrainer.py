"""
LoRATrainer.py

This module defines the LoRATrainer class for training neural networks using a LoRA-based meta-learning controller.
It inherits from BaseNetworkTrainer and is structurally similar to StandardTrainer, but is designed specifically
to work with models that include a LoRAController. Each task is handled sequentially: the controller adapts to 
the task by updating low-rank basis vectors, which are orthogonalized across tasks to prevent interference.

The trainer handles:
- Task-based training loops with controller-specific reinitialization
- Selective optimization of LoRA parameters (keeping base weights frozen)
- Validation handling across tasks

Use this trainer when the model's controller is a LoRAController and you want to train task-specific subspaces
in a continual or multi-task setup.
"""

import copy
import torch
import numpy as np
from tqdm import tqdm
from src.training.base_trainer import BaseNetworkTrainer
from src.models.controllers.lora_controller import LoRAController, LoRAOutputLayer
from colorama import Fore, Style



class LoRATrainer(BaseNetworkTrainer):
    def __init__(self, model, config: dict, data_generator):
        super().__init__(model, config, data_generator)

        if not isinstance(self.model.model.controller, LoRAController):
            raise TypeError("Model's controller must be an instance of LoRAController.")
        
        self.lambda_orth = self.config['model']['learning_rule_params'].get('lambda_orth', 1)

        self.orthogonality_losses = []

        # Check if validation chceks are desired
        self.val_task_indices = self.config['data'].get('val_indices', None)
        if self.val_task_indices is not None:
            self.static_validation_sets = {}
            self.val_acc_per_epoch = []
            self.val_loss_per_epoch = []
            self._setup_validation()
            
    def _setup_validation(self):
        """
        Prepares static validation sets for each validation task index.
        """
        if self.val_task_indices is not None:
            for task_idx, temporal_config in self.val_task_indices.items():
                val_config = copy.deepcopy(self.config)
                val_config['data']['task_indices'] = [task_idx]
                val_config['temporal'].update(temporal_config)
                print(f"Setting up validation for task {task_idx} with config: {val_config}")
                val_gen = self.data_generator.__class__(config=val_config)
                val_gen.set_seed(31)
                X, y, _ = val_gen.generate_data(
                    input_noise_std=self.config['data']['input_noise_std'],
                    n_trials=512,
                    return_trial_types=True)

                inputs = X.transpose(0, 1).to(self.device)
                targets = y.transpose(0, 1).to(self.device)

                self.static_validation_sets[task_idx] = (inputs, targets)

    def train(self) -> dict:
        # Generate a fresh dataloader for this training run
        dataloader = self.data_generator.prepare_dataloader()

        # Training loop over epochs
        progress_bar = tqdm(range(self.train_config['n_epochs']), desc="Training")

        for epoch in progress_bar:

            # Compute epoch metrics
            avg_loss, avg_accuracy, avg_lora_orthogonality_loss, avg_prev_contrib, avg_curr_contrib, hidden_states = self.train_epoch(dataloader) #avg_grad_ratio
            
            # Progress bar
            #grad_ratio_color = Fore.GREEN if avg_grad_ratio < 1 else Fore.RED
            acc_color = Fore.RED if avg_accuracy < 0.9 else Fore.GREEN
            progress_bar.set_postfix_str(
                f"loss={avg_loss:7.4f}  "
                f"orth={avg_lora_orthogonality_loss:7.4f}  "
                f"{acc_color}acc={avg_accuracy:5.2f}{Style.RESET_ALL}  "
                #f"{grad_ratio_color}gradR={avg_grad_ratio:6.2f}{Style.RESET_ALL}  "
                f"prev={avg_prev_contrib:7.4f}  "
                f"curr={avg_curr_contrib:7.4f}"
            )

            # Run validation analysis if specified
            if self.val_task_indices is not None:
                val_metrics = self.run_validation_across_tasks()
                val_accs = {k: v[0] for k, v in val_metrics.items()}
                val_losses = {k: v[1] for k, v in val_metrics.items()}
                self.val_acc_per_epoch.append(val_accs)
                self.val_loss_per_epoch.append(val_losses)
            self.orthogonality_losses.append(avg_lora_orthogonality_loss)

        # After training, accumulate the LoRA task contributions to the persistent memory
        self.model.model.controller.accumulate_task()
        for group in self.optimizer.param_groups:
            for p in group['params']:
                state = self.optimizer.state.get(p, None)
                if state is not None:
                    state.clear()
        # if isinstance(self.model.model.output_layer, LoRAOutputLayer):
        #     self.model.model.output_layer.accumulate_task()

        results = self.metrics.get_results(self.model.get_weights())
        if self.val_task_indices is not None:
            results['val_acc_per_epoch'] = self.val_acc_per_epoch
            results['val_loss_per_epoch'] = self.val_loss_per_epoch
        results['orthogonality_losses'] = self.orthogonality_losses

        return results

    def train_epoch(self, dataloader):
        """
        Trains for one epoch on the given dataloader.
        Args:
            dataloader: DataLoader for the current task.
        Returns:
            tuple: (avg_loss, avg_accuracy, final_hidden_states)
        """

        # Lists to accumulate loss and accuracy for the epoch
        epoch_losses = []
        epoch_accuracies = []
        epoch_task_accuracies = [[] for _ in range(self.metrics.num_tasks)]
        epoch_orthogonality_losses = []
        epoch_prev_contribs = []
        epoch_curr_contribs = []
        grad_ratios = []
        final_hidden_states = None

        for batch in dataloader:
            if len(batch) == 3:
                # Multi-task setting: task labels provided
                inputs, targets, task_labels = batch
                is_multitask = True
            else:
                # Single-task setting: no task labels
                inputs, targets = batch
                task_labels = None
                is_multitask = False

            # Transpose to shape (timesteps, batch, features)
            inputs = inputs.to(self.device).transpose(0, 1)
            targets = targets.to(self.device).transpose(0, 1)
            if task_labels is not None:
                task_labels = task_labels.to(self.device)

            # Forward pass through model (outputs: [T, B, output_dim])
            outputs, hidden_states, _ = self._forward_pass(inputs)           
            
            # Compute performance loss on task 
            performance_loss = self._compute_loss(outputs, targets, hidden_states)

            # Compute LoRA orthogonality penalty
            lora_orthogonality_loss = self.model.model.controller.orthogonality_penalty(hidden_states)
            if isinstance(self.model.model.output_layer, LoRAOutputLayer):
                lora_orthogonality_loss += self.model.model.output_layer.orthogonality_penalty(hidden_states)

            # Apply the orthogonality penalty scaling factor
            lora_orthogonality_loss = lora_orthogonality_loss * self.lambda_orth
            # # -------- Gradient norm separation --------
            # # Task loss gradients
            # self.optimizer.zero_grad()
            # performance_loss.backward(retain_graph=True)
            # task_grad_norm = 0.0
            # for name, p in self.model.model.controller.named_parameters():
            #     if p.grad is not None:
            #         task_grad_norm += p.grad.norm(2).item() ** 2
            # task_grad_norm = task_grad_norm ** 0.5

            # # Orth loss gradients
            # self.optimizer.zero_grad()
            # lora_orthogonality_loss.backward(retain_graph=True)
            # orth_grad_norm = 0.0
            # for name, p in self.model.model.controller.named_parameters():
            #     if p.grad is not None:
            #         orth_grad_norm += p.grad.norm(2).item() ** 2
            # orth_grad_norm = orth_grad_norm ** 0.5

            # grad_ratio = orth_grad_norm / (task_grad_norm + 1e-8)

            # -------- Actual combined update --------
            self.optimizer.zero_grad()
            total_loss = performance_loss + lora_orthogonality_loss
            total_loss.backward()
            self.metrics.update_gradients(self.model)
            self.optimizer.step()

            # Track values
            epoch_losses.append(total_loss.item())
            epoch_accuracies.append(self._compute_accuracy(outputs, targets))
            epoch_orthogonality_losses.append(lora_orthogonality_loss.item())
            epoch_prev_contribs.append(self.model.model.controller.W_previous_contrib)
            epoch_curr_contribs.append(self.model.model.controller.W_current_contrib)
            #grad_ratios.append(grad_ratio)

            if is_multitask:
                task_accs = self._compute_task_accuracies(outputs, targets, task_labels)
                for task_idx in range(self.metrics.num_tasks):
                    epoch_task_accuracies[task_idx].append(task_accs[task_idx])

            final_hidden_states = hidden_states

        avg_loss = np.mean(epoch_losses)
        avg_accuracy = np.mean(epoch_accuracies)
        avg_lora_orthogonality_loss = np.mean(epoch_orthogonality_losses)
        avg_prev_contrib = np.mean(epoch_prev_contribs)
        avg_curr_contrib = np.mean(epoch_curr_contribs)
        #avg_grad_ratio = np.mean(grad_ratios)

        task_accuracies = None
        if is_multitask:
            task_accuracies = [np.mean(accs) for accs in epoch_task_accuracies]

        self.metrics.update_epoch(
            self.model, avg_loss, avg_accuracy, final_hidden_states,
            task_accuracies=task_accuracies
        )

        return avg_loss, avg_accuracy, avg_lora_orthogonality_loss, avg_prev_contrib, avg_curr_contrib, final_hidden_states, #avg_grad_ratio
    
    def run_validation_across_tasks(self) -> dict:
        """
        Runs validation on all static validation sets.
        Returns:
            dict: task index -> (accuracy, loss)
        """
        task_metrics = {}
        for task_idx, (inputs, targets) in self.static_validation_sets.items():
            with torch.no_grad():
                outputs, hidden_states, _ = self._forward_pass(inputs)
                acc = self._compute_accuracy(outputs, targets)
                loss = self._compute_loss(outputs, targets, hidden_states)
                task_metrics[task_idx] = (acc, loss.item())
        return task_metrics
    
   
   
   