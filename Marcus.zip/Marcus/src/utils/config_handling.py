"""
Configuration management for meta-learning controller models.

This file provides utilities for creating, loading, and modifying experiment 
configuration dictionaries from YAML files or code. Configurations typically
include model architecture, plasticity settings, training parameters, and data setup.
"""

from typing import Dict, Any, Optional, Union
from pathlib import Path
import yaml
from copy import deepcopy


class ConfigurationError(Exception):
    """Raised when there's an error in the configuration."""
    pass


def create_experiment_config(
        experiment_name: str,
        save_path: Optional[Union[str, Path]] = None,
        config_fname: Optional[str] = None,
        overwrite: bool = False,
        **kwargs
) -> Dict[str, Any]:
    """
    Create and optionally save an experiment configuration dictionary.

    Args:
        experiment_name (str): Name of the experiment.
        save_path (str or Path, optional): Directory to save the configuration file.
        config_fname (str, optional): Name of the YAML config file.
        overwrite (bool): Whether to overwrite existing file.
        **kwargs: Arbitrary key-value pairs to include in the config.

    Returns:
        dict: The created configuration dictionary.

    Raises:
        ConfigurationError: If the config file exists and overwrite=False.
    """
    if save_path is None:
        raise ValueError("save_path must be provided")
    if config_fname is None:
        raise ValueError("config_fname must be provided")

    save_path = Path(save_path) if isinstance(save_path, str) else save_path
    config_path = save_path / config_fname

    if not save_path.exists():
        save_path.mkdir(parents=True, exist_ok=True)

    config = {**kwargs}
    config['experiment_name'] = experiment_name

    if config_path.exists() and not overwrite:
        raise ConfigurationError(
            f"Configuration file already exists at {config_path}. "
            "Set overwrite=True to overwrite it."
        )

    print(f"{'Overwriting' if config_path.exists() else 'Creating'} configuration file at {config_path}")
    with open(config_path, 'w') as f:
        yaml.dump(config, f, default_flow_style=False, sort_keys=False)

    return config


def load_config(config_path: Union[str, Path]) -> Dict[str, Any]:
    """
    Load configuration from a YAML file and validate essential sections.

    Args:
        config_path (str or Path): Path to a .yml or .yaml config file.

    Returns:
        dict: Parsed and validated configuration dictionary.

    Raises:
        FileNotFoundError: If the file doesn't exist.
        ConfigurationError: If file format is invalid or required keys are missing.
    """
    path = Path(config_path)
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")

    if path.suffix not in ['.yml', '.yaml']:
        raise ConfigurationError(f"Unsupported config format: {path.suffix}")

    with open(path) as f:
        config = yaml.safe_load(f)

    # Validate essential parameters
    required_keys = ['model', 'plasticity', 'training', 'data']
    for key in required_keys:
        if key not in config:
            raise ConfigurationError(f"Missing required config section: {key}")

    return config


def update_config(config: Dict[str, Any], updates: Dict[str, Any], validate: bool = True) -> Dict[str, Any]:
    """
    Update an existing configuration dictionary with new values.

    Args:
        config (dict): Original configuration dictionary.
        updates (dict): Dictionary of updates to apply.
        validate (bool): Whether to validate the updated config after applying updates.

    Returns:
        dict: The updated configuration dictionary.

    Raises:
        ConfigurationError: If required keys are missing after update.
    """
    updated_config = deepcopy(config)

    def _recursive_update(base: Dict, updates: Dict) -> None:
        for key, value in updates.items():
            if isinstance(value, dict) and key in base:
                _recursive_update(base[key], value)
            else:
                base[key] = value

    _recursive_update(updated_config, updates)

    if validate:
        required_keys = ['model', 'plasticity', 'training', 'data']
        for key in required_keys:
            if key not in updated_config:
                raise ConfigurationError(f"Missing required config section: {key}")
            
    # Additional validation could be added here
    # For example, checking types, ranges, etc.
    return updated_config