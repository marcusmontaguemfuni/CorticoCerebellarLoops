"""
Data generation module for cortico-cerebellar meta-learning experiments.

This module defines the basic components for creating temporally structured input/output
data for tasks such as XOR, AND, OR, and abstract logic tasks. It includes experiment type
enums, encoding modes, and infrastructure for task parameterization and error handling.

"""

from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Tuple, Optional, Union, List, Dict, Any
import warnings
import numpy as np
import torch
import yaml
from numpy.typing import NDArray
from pydantic import BaseModel, model_validator, Field, validator
import matplotlib.pyplot as plt
import seaborn as sns
from torch.utils.data import TensorDataset, DataLoader
import itertools

class DataValidationError(Exception):
    """Custom exception for data validation errors."""
    pass

class EncodingMode(Enum):
    """Encoding modes for the XOR task."""
    ORTHOGONAL = "orthogonal"
    NON_ORTHOGONAL = "non-orthogonal"

class ExperimentType(Enum):
    """Available experiment types."""
    xor_basic = "xor_basic"
    xor_inactive_feat = "xor_inactive_feat"
    xor_colour_gen = "xor_colour_gen"
    and_basic = "and_basic"
    or_basic = "or_basic"
    abstract_binary = "abstract_binary"
    abstract_binary_multitask = "abstract_binary_multitask"
    continual_abstract = 'continual_abstract'

class TemporalParams(BaseModel):
    t_min: int = Field(-500, description="Start time in ms")
    t_max: int = Field(1500, description="End time in ms")
    dt: int = Field(20, description="Time step in ms")
    task_id_onset: float = Field(-200.0, description="Task ID signal onset")
    task_id_offset: float = Field(1000.0, description="Task ID signal offset")
    colour_onset: float = Field(0.0, description="Color stimulus onset")
    colour_offset: float = Field(1000.0, description="Color stimulus offset")
    shape_onset: float = Field(500.0, description="Shape stimulus onset")
    shape_offset: float = Field(1000.0, description="Shape stimulus offset")
    reward_onset: float = Field(1000.0, description="Reward onset")
    reward_offset: float = Field(1200.0, description="Reward offset")

    @model_validator(mode='after')
    def validate(self):
        """Validate temporal sequence is logical"""
        if self.t_min >= self.t_max:
            raise ValueError("t_min must be less than t_max")
        if self.task_id_onset >= self.task_id_offset:
            raise ValueError("task_id_onset must be before task_id_offset")
        if self.colour_onset >= self.colour_offset:
            raise ValueError("colour_onset must be before colour_offset")
        if self.shape_onset >= self.shape_offset:
            raise ValueError("shape_onset must be before shape_offset")
        if self.reward_onset >= self.reward_offset:
            raise ValueError("reward_onset must be before reward_offset")
        if self.dt <= 0:
            raise ValueError("dt must be positive")
        if (self.t_max - self.t_min) % self.dt != 0:
            raise ValueError(f"Time range ({self.t_max - self.t_min}) is not divisible by dt ({self.dt})")
        return self
    
    @property
    def total_duration(self):
        return self.t_max - self.t_min

    @property
    def num_timesteps(self):
        return (self.t_max - self.t_min) // self.dt


# === DataGenerator class for temporally structured data ===
class DataGenerator:
    """
    Generator for temporally structured input/output data for logic tasks (XOR, AND, abstract binary etc).

    This class creates trial-structured datasets with configurable temporal dynamics and task structure.
    It supports both single-task and multi-task experiments, different input encodings, and flexible
    hardware/device setups.

    Configuration can be passed directly as a dictionary or loaded from a YAML file.
    """

    def __init__(
        self,
        config_path: Union[str, Path] = None,
        config: Optional[Dict[str, Any]] = None,
        task_indices: Optional[List[int]] = None,
        seed: Optional[int] = None,
        experiment_type: Optional[ExperimentType] = None,
        encoding_mode: Optional[EncodingMode] = None,
        device: Optional[str] = None,
    ):
        """
        Initialize the data generator.

        Args:
            config_path: Path to the YAML configuration file (optional if config is given).
            config: Configuration dictionary (overrides config_path if provided).
            task_indices: List of task indices to use (for multitask setups).
            seed: Random seed for reproducibility.
            experiment_type: Override the experiment type from config (optional).
            encoding_mode: Override the input encoding mode from config (optional).
            device: Torch device string (e.g. 'cuda', 'cpu', 'mps').
        """
        self.config_path = Path(config_path) if config_path else None
        self.config = config
        if self.config is None:
            if self.config_path is None:
                raise ValueError("Either config or config_path must be provided.")
            self.config = self._load_config(self.config_path)

        # Reproducibility
        self.seed = seed if seed is not None else self.config.get('reproducibility', {}).get('seed')

        # Experiment type
        if experiment_type is None:
            exp_type_str = self.config.get('data', {}).get('experiment_type')
            self.experiment_type = ExperimentType[exp_type_str]
        else:
            self.experiment_type = experiment_type

        # Encoding mode
        if encoding_mode is None:
            encoding_str = self.config.get('data', {}).get('encoding_mode')
            self.encoding_mode = EncodingMode[encoding_str.upper()]
        else:
            self.encoding_mode = encoding_mode

        # Task indices
        self.task_indices = task_indices if task_indices is not None else self.config.get('data', {}).get('task_indices')
        self.classification_index = self.task_indices[0]

        if self.experiment_type == ExperimentType.continual_abstract:
            # Persistent scalar task ID mapping for all task indices seen across phases
            val_task_indices = self.config.get('data', {}).get('val_indices', {})
            task_ids = sorted(val_task_indices.keys())
            self.task_id_values = np.linspace(-1.0, 1.0, len(task_ids))
            self.task_id_map = {task: value for task, value in zip(task_ids, self.task_id_values)}

        
        # Device
        if device is None:
            device_str = self.config.get('hardware', {}).get('device')
            self.device = self._setup_device(device_str)
        else:
            self.device = torch.device(device)

        # Temporal structure
        self.temporal_params = TemporalParams(**self.config.get("temporal", {}))
        self._validate_config()

        # Data config
        self.n_trials = self.config.get('data', {}).get('n_trials')
        self.batch_size = self.config.get('data', {}).get('batch_size')
        self.input_noise_std = self.config.get('data', {}).get('input_noise_std')
        self.num_workers = self.config.get('data', {}).get('num_workers')

        # Abstract task label
        self.abstract_task_type = None
        if self.experiment_type == ExperimentType.abstract_binary and self.classification_index is not None:
            patterns = self._generate_abstract_binary_patterns()
            pattern = patterns[self.classification_index]
            self.abstract_task_type = self._get_abstract_task_type(pattern)


    @staticmethod
    def _load_config(config_path: Union[str, Path]) -> dict:
        """Load configuration from a YAML file."""
        path = Path(config_path)
        if not path.exists():
            raise FileNotFoundError(f"Config file not found: {path}")
        with open(path) as f:
            return yaml.safe_load(f)

    @staticmethod
    def _setup_device(device: Optional[str] = None) -> torch.device:
        """Select appropriate torch device."""
        if device is not None:
            return torch.device(device)
        if torch.cuda.is_available():
            return torch.device('cuda')
        elif hasattr(torch.backends, 'mps') and torch.backends.mps.is_available():
            return torch.device('mps')
        return torch.device('cpu')
    
    def set_seed(self, seed: Optional[int] = None) -> None:
        """Set random seeds for reproducibility."""
        if seed is None:
            seed = np.random.choice(2 ** 32)

        np.random.seed(seed)
        torch.manual_seed(seed)

        if self.device.type == 'cuda':
            torch.cuda.manual_seed_all(seed)
            torch.backends.cudnn.deterministic = True
            torch.backends.cudnn.benchmark = False
        elif self.device.type == 'mps':
            pass  # MPS doesn't need special handling for seeds
    
    def get_data_params(self) -> dict:
        """Get data parameters from config with defaults."""
        data_config = self.config.get('data', {})
        return {
            'n_trials': data_config.get('n_trials'),
            'input_noise_std': data_config.get('input_noise_std'),
            'batch_size': data_config.get('batch_size'),
            'num_workers': data_config.get('num_workers')
        }

    def _validate_config(self) -> None:
        """Validate core configuration parameters."""
        self.temporal_params.validate()
        data_cfg = self.config.get("data", {})
        if 'n_trials' in data_cfg and data_cfg['n_trials'] <= 0:
            raise DataValidationError("n_trials must be positive")
        if 'input_noise_std' in data_cfg and data_cfg['input_noise_std'] < 0:
            raise DataValidationError("input_noise_std must be non-negative")
        if 'batch_size' in data_cfg and data_cfg['batch_size'] <= 0:
            raise DataValidationError("batch_size must be positive")
        if self.experiment_type == ExperimentType.abstract_binary and self.classification_index is None:
            raise DataValidationError("classification_index must be set for abstract_binary experiment type")

    def _generate_abstract_binary_patterns(self) -> List[List[int]]:
        """
        Generate all valid 4-vs-4 binary classification patterns.

        This creates every unique way to split 8 binary input conditions into two classes 
        (rewarded vs unrewarded) such that each class contains exactly 4 conditions. 
        Duplicate splits (e.g. swapping class labels) are removed.

        Returns:
            List[List[int]]: Each list contains the indices (0–7) of the rewarded conditions 
            for one valid binary classification task.
        """
        
        n_conditions = 8  # Total binary input combinations (e.g. 3 binary features → 2^3 = 8)
        n_rewards = 4     # Number of rewarded combinations per task
        patterns = []
        seen = set()

        # Enumerate all combinations of 4 rewarded inputs
        for pattern in itertools.combinations(range(n_conditions), n_rewards):
            # Determine the complementary unrewarded set
            inverse = tuple(sorted(set(range(n_conditions)) - set(pattern)))
            # Create a symmetric key to avoid duplicates (e.g. [rewarded, unrewarded] same as [unrewarded, rewarded])
            pattern_key = tuple(sorted([pattern, inverse]))

            if pattern_key not in seen:
                patterns.append(list(pattern))
                seen.add(pattern_key)

        return patterns

    def _get_abstract_task_type(self, pattern: List[int]) -> str:
        """
        Return a human-readable task description for a given 4-rewarded-condition pattern.

        These known patterns correspond to semantically interpretable logical functions over the 3 binary features
        (Color, Shape, Width). Each pattern is defined by the set of 8 possible feature combinations (000 to 111),
        and the four rewarded conditions for that task.

        The mappings below associate these 4-rewarded-condition indices to human-readable logical task names,
        such as "Color", "Color XOR Shape", or a 3-way combination.
        """
        # Return label based on known abstract logic patterns
        task_types = {
            (0, 1, 2, 3): "Color",
            (0, 2, 4, 6): "Width",
            (0, 1, 4, 5): "Shape",
            (0, 1, 6, 7): "Color XOR Shape",
            (0, 2, 5, 7): "Color XOR Width",
            (0, 3, 4, 7): "Shape XOR Width",
            (0, 1, 2, 5): "Three-way: (NOT Color AND NOTShape) OR (NOT Color AND NOT Width) OR (NOT Shape AND Width)",
        }
        return task_types.get(tuple(sorted(pattern)), "Unknown pattern")
        
    def generate_sequence_events(self) -> Tuple[np.ndarray, int, np.ndarray]:
        """
        Generate a binary event matrix over time for features and reward presentations.

        Returns:
            events (np.ndarray): Array of shape (n_event_channels, T) with binary event indicators.
            T (int): Number of time steps in the trial.
            times (np.ndarray): Time vector of length T (ms).
        """
        # Determine number of time steps and create time vector
        T = self.temporal_params.num_timesteps
        times = np.linspace(self.temporal_params.t_min, self.temporal_params.t_max, T, endpoint=False)

        def _create_event_signal(onset: float, offset: float) -> np.ndarray:
            """Helper to create a binary vector with ones during the [onset, offset) interval."""
            signal = np.zeros(T)
            start_idx = np.searchsorted(times, onset, side='left')
            end_idx = np.searchsorted(times, offset, side='left')
            signal[start_idx:end_idx] = 1
            return signal

        # === Feature presentation event channels ===
        colour_on = _create_event_signal(self.temporal_params.colour_onset, self.temporal_params.colour_offset)
        shape_on = _create_event_signal(self.temporal_params.shape_onset, self.temporal_params.shape_offset)
        # Width uses same timing as shape for simplicity
        width_on = shape_on.copy()
        # Reward signal presentation
        reward_on = _create_event_signal(self.temporal_params.reward_onset, self.temporal_params.reward_offset)

        # === Task ID signals (only for multitask mode) ===
        if self.experiment_type == ExperimentType.abstract_binary_multitask:
            task_id_on = _create_event_signal(self.temporal_params.task_id_onset, self.temporal_params.task_id_offset)
            # Create a separate task ID signal for each task index (one-hot across task channels)
            task_signals = [task_id_on.copy() for _ in self.task_indices]
            # Stack all task ID channels followed by feature and reward signals
            events = np.vstack(task_signals + [colour_on, shape_on, width_on, reward_on])
        if self.experiment_type == ExperimentType.continual_abstract:
            task_id_on = _create_event_signal(self.temporal_params.task_id_onset, self.temporal_params.task_id_offset)
            events = np.vstack([task_id_on, colour_on, shape_on, width_on, reward_on])
        else:
            # Single-task setup: just feature and reward signals
            events = np.vstack([colour_on, shape_on, width_on, reward_on])

        return events, T, times
    
    def construct_design_matrix(self) -> np.ndarray:
        """
        Construct a design matrix defining trial-wise input/output combinations.

        This matrix specifies the static input features (color, shape, width) and
        reward targets for each trial type. Each row in the matrix represents one
        type of trial, with inputs encoded based on the selected logic task and
        the reward signal corresponding to whether that combination is correct
        for the current task.

        Returns:
            design_matrix (np.ndarray): shape (n_trial_types, n_features + 1)
        """
        use_orthogonal = self.encoding_mode == EncodingMode.ORTHOGONAL
        values = [-1, 1] if use_orthogonal else [0, 1]

        def _create_labels(pattern: List[bool], val1, val2) -> np.ndarray:
            return np.array([val1 if p else val2 for p in pattern])

        # Construct trial definitions for different logic tasks.
        # Each block below defines the logic and associated reward for 8 possible input combinations.
        if self.experiment_type == ExperimentType.xor_basic:
            colour = _create_labels([False]*4 + [True]*4, values[1], values[0])
            shape = _create_labels([False, False, True, True]*2, values[1], values[0])
            width = _create_labels([False, True]*4, values[1], values[0])
            reward = np.array([1, 1, 0, 0, 0, 0, 1, 1])
            return np.vstack([colour, shape, width, reward]).T

        elif self.experiment_type == ExperimentType.and_basic:
            colour = _create_labels([False]*4 + [True]*4, values[1], values[0])
            shape = _create_labels([False, False, True, True]*2, values[1], values[0])
            width = _create_labels([False, True]*4, values[1], values[0])
            reward = np.array([0, 0, 0, 0, 0, 0, 1, 1])
            return np.vstack([colour, shape, width, reward]).T

        elif self.experiment_type == ExperimentType.or_basic:
            colour = _create_labels([False]*4 + [True]*4, values[1], values[0])
            shape = _create_labels([False, False, True, True]*2, values[1], values[0])
            width = _create_labels([False, True]*4, values[1], values[0])
            reward = np.array([1, 1, 1, 1, 1, 1, 0, 0])
            return np.vstack([colour, shape, width, reward]).T

        elif self.experiment_type == ExperimentType.abstract_binary:
            colour = _create_labels([False]*4 + [True]*4, values[1], values[0])
            shape = _create_labels([False, False, True, True]*2, values[1], values[0])
            width = _create_labels([False, True]*4, values[1], values[0])
            patterns = self._generate_abstract_binary_patterns()
            reward_pattern = [1 if i in patterns[self.classification_index] else 0 for i in range(8)]
            reward = np.array(reward_pattern)
            return np.vstack([colour, shape, width, reward]).T

        elif self.experiment_type == ExperimentType.continual_abstract:
            colour = _create_labels([False]*4 + [True]*4, values[1], values[0])
            shape = _create_labels([False, False, True, True]*2, values[1], values[0])
            width = _create_labels([False, True]*4, values[1], values[0])
            task_id_value = self.task_id_map[self.classification_index]
            task_id = np.full(8, task_id_value)
            patterns = self._generate_abstract_binary_patterns()
            reward_pattern = [1 if i in patterns[self.classification_index] else 0 for i in range(8)]
            reward = np.array(reward_pattern)
            return np.vstack([task_id, colour, shape, width, reward]).T

        # Multitask setup: multiple abstract tasks with task ID channels added per trial.
        elif self.experiment_type == ExperimentType.abstract_binary_multitask:
            full_matrix = []
            patterns = self._generate_abstract_binary_patterns()
            for i, task_id in enumerate(self.task_indices):
                # Task ID one-hot encoding
                task_channels = []
                for j in range(len(self.task_indices)):
                    label = values[1] if i == j else values[0]
                    task_channels.append(np.full(8, label))
                colour = _create_labels([False]*4 + [True]*4, values[1], values[0])
                shape = _create_labels([False, False, True, True]*2, values[1], values[0])
                width = _create_labels([False, True]*4, values[1], values[0])
                reward = np.array([1 if k in patterns[task_id] else 0 for k in range(8)])
                trial_matrix = np.vstack(task_channels + [colour, shape, width, reward]).T
                full_matrix.append(trial_matrix)
            return np.vstack(full_matrix)

        else:
            raise ValueError(f"Unsupported experiment type: {self.experiment_type}")
        
    def generate_data(
        self,
        n_trials: Optional[int] = None,
        input_noise_std: Optional[float] = None,
        return_trial_types: bool = False,
        return_times: bool = False,
    ) -> Tuple[torch.Tensor, ...]:
        """
        Generate full input-output data tensors based on design matrix and event sequence.

        Args:
            n_trials (int): Total number of trials to generate.
            input_noise_std (float): Standard deviation of Gaussian input noise.
            return_trial_types (bool): Whether to return trial type indices.
            return_times (bool): Whether to return event times.

        Returns:
            Tuple of tensors and optionally trial types and times.
        """
        design_matrix = self.construct_design_matrix()
        events, T, times = self.generate_sequence_events()
        n_trial_types = design_matrix.shape[0]

        n_trials = n_trials if n_trials is not None else self.n_trials
        input_noise_std = input_noise_std if input_noise_std is not None else self.input_noise_std

        if n_trials % n_trial_types != 0:
            raise DataValidationError(f"n_trials must be divisible by number of trial types ({n_trial_types})")

        # --- Build prototype (base) trial patterns for each trial type ---
        # Each prototype trial is constructed by multiplying the event sequence (timing of inputs/reward)
        # by the corresponding input values from the design matrix for that trial type.
        # The result is a (n_trial_types, T, n_features) array for inputs, and (n_trial_types, T, 2) for outputs.
        prototype_inputs = np.zeros((n_trial_types, T, design_matrix.shape[1] - 1))  # Inputs for each trial type
        prototype_outputs = np.zeros((n_trial_types, T, 2))  # Output (reward) for each trial type

        for trial_type_idx in range(n_trial_types):
            # Construct the temporally structured input for this trial type.
            # Multiply each input event channel by its value for this trial type.
            prototype_inputs[trial_type_idx] = (events[:-1] * design_matrix[trial_type_idx, :-1, None]).T

            # Construct the output tensor (reward channels).
            # Channel 0: reward signal if correct, Channel 1: reward signal if incorrect (i.e., 1 - reward_val).
            reward_val = design_matrix[trial_type_idx, -1]
            prototype_outputs[trial_type_idx, :, 0] = events[-1] * reward_val
            prototype_outputs[trial_type_idx, :, 1] = events[-1] * (1 - reward_val)

        # --- Replicate prototype trials to fill the requested number of total trials ---
        # Each prototype trial type is repeated (n_trials // n_trial_types) times, concatenating along the batch axis.
        repeats = n_trials // n_trial_types
        input_tensor = np.tile(prototype_inputs, (repeats, 1, 1))
        output_tensor = np.tile(prototype_outputs, (repeats, 1, 1))
        trial_type_indices = np.tile(np.arange(n_trial_types), repeats)  # Track which trial type each trial is

        # --- Add optional Gaussian noise to the input tensor ---
        if input_noise_std > 0:
            input_tensor += np.random.randn(*input_tensor.shape) * input_noise_std

        # --- Convert numpy arrays to PyTorch tensors for model consumption ---
        input_tensor = torch.tensor(input_tensor, dtype=torch.float32, device=self.device)
        output_tensor = torch.tensor(output_tensor, dtype=torch.float32, device=self.device)

        # --- Prepare outputs, optionally including trial type indices and times ---
        outputs = [input_tensor, output_tensor]
        if return_trial_types:
            outputs.append(trial_type_indices)
        if return_times:
            outputs.append(times)

        return tuple(outputs)
    

    def prepare_dataloader(
        self,
        n_trials: Optional[int] = None,
        batch_size: Optional[int] = None,
        input_noise_std: Optional[float] = None,
        shuffle: bool = True,
        num_workers: Optional[int] = None,
        return_trial_types: bool = False,
        return_task_labels: bool = False,
    ) -> Union[torch.utils.data.DataLoader, Dict[str, Union[torch.utils.data.DataLoader, np.ndarray]]]:
        """
        Generate a PyTorch DataLoader using freshly created task data.

        Args:
            n_trials (int): Total number of trials to generate. Uses config default if None.
            batch_size (int): Batch size for DataLoader. Uses config default if None.
            input_noise_std (float): Noise level for input features. Uses config default if None.
            shuffle (bool): Whether to shuffle the dataset in the loader.
            num_workers (int): Number of worker threads. Uses config default if None.
            return_trial_types (bool): Whether to return numpy array of trial types used.
            return_task_labels (bool): Whether to return PyTorch tensor of task indices (for multitask setups).

        Returns:
            Either a plain DataLoader, or a dictionary containing the DataLoader and metadata
            such as trial types or task labels, depending on the flags provided.
        """
        # Pull defaults from config if not specified explicitly
        n_trials = n_trials if n_trials is not None else self.n_trials
        batch_size = batch_size if batch_size is not None else self.batch_size
        input_noise_std = input_noise_std if input_noise_std is not None else self.input_noise_std
        num_workers = num_workers if num_workers is not None else self.num_workers

        # Always get trial_types if we need to compute task_labels from them
        need_trial_types = return_trial_types or (
            self.experiment_type == ExperimentType.abstract_binary_multitask and return_task_labels)

        # === Generate input/output tensors ===
        if need_trial_types:
            X, y, trial_types = self.generate_data(
                n_trials=n_trials,
                input_noise_std=input_noise_std,
                return_trial_types=True,
                return_times=False,
            )
        else:
            X, y = self.generate_data(
                n_trials=n_trials,
                input_noise_std=input_noise_std,
                return_trial_types=False,
                return_times=False,
            )
            trial_types = None

        # === If multitask, convert trial_types to task labels ===
        if self.experiment_type == ExperimentType.abstract_binary_multitask and return_task_labels:
            # Each abstract task has 8 trial types — identify task for each trial
            task_positions = trial_types // 8
            task_values = np.array(self.task_indices)[task_positions]
            task_labels = torch.tensor(task_values, device=X.device)
            dataset = TensorDataset(X, y, task_labels)
        else:
            dataset = TensorDataset(X, y)

        # === Build DataLoader ===
        dataloader = DataLoader(
            dataset,
            batch_size=batch_size,
            shuffle=shuffle,
            drop_last=True,
            num_workers=num_workers,
        )

        # === Return dictionary of outputs if metadata is requested ===
        if need_trial_types or (self.experiment_type == ExperimentType.abstract_binary_multitask and return_task_labels):
            result = {'dataloader': dataloader}
            if return_trial_types:
                result['trial_types'] = trial_types
            if self.experiment_type == ExperimentType.abstract_binary_multitask and return_task_labels:
                result['task_labels'] = task_labels
            return result
        else:
            return dataloader
        

    def generate_mask(
        self,
        trial_type: int = 0,
        plot_mask: bool = False,
        mask_format: str = 'weights',
    ) -> torch.Tensor:
        """
        Generate a temporal mask over the output for loss weighting or selection.

        The mask identifies the timepoints during which the reward signal is active.
        This is typically used to compute the loss only when the target output is valid.
        Supports 'weights' (float-valued) or 'bool' (binary) format.

        Args:
            trial_type (int): Index of the trial type to use for the mask (default 0).
            plot_mask (bool): Whether to display a plot of the generated mask.
            mask_format (str): 'weights' returns full reward signal as weights,
                                'bool' returns binary mask (True/False).

        Returns:
            mask (torch.Tensor): Temporal mask of shape (batch_size, T, 2), matching output shape.
        """
        # Save and temporarily override the classification index if needed
        original_index = self.classification_index
        self.classification_index = self.task_indices[0]

        # Generate a small batch of data and extract reward signal
        X, y, trial_types, times = self.generate_data(
            n_trials=16,
            input_noise_std=0.0,
            return_trial_types=True,
            return_times=True,
        )

        # Restore original classification index
        self.classification_index = original_index

        # Identify a trial with a positive reward to construct the mask from
        trial_idx = np.where((y[:, :, 0] > 0).any(dim=1))[0][0]

        if mask_format == 'bool':
            mask = y[trial_idx, :, 0] > 0
        elif mask_format == 'weights':
            mask = y[trial_idx, :, 0]
        else:
            raise DataValidationError("Mask format must be either 'weights' or 'bool'.")

        if not mask.any():
            raise DataValidationError("Generated mask is empty — no reward signal present.")

        # Optionally visualize the temporal mask
        if plot_mask:
            plt.figure(figsize=(12, 3))
            plt.plot(times, mask.cpu().numpy().astype(float), 'k-', linewidth=2, label=f'Mask (Trial {trial_type})')
            plt.fill_between(times, 0, mask.cpu().numpy().astype(float), alpha=0.2, color='gray')
            plt.title('Temporal Mask over Reward Signal')
            plt.xlabel('Time (ms)')
            plt.ylabel('Mask Value')
            plt.grid(True, alpha=0.3)
            plt.legend()
            plt.ylim(-0.1, 1.1)
            plt.tight_layout()
            plt.show()

        # Convert to shape (batch_size, T, 2) for broadcasting across training batches
        if mask_format == 'weights':
            mask = mask.view(1, -1, 1).repeat(self.batch_size, 1, y.shape[-1])

        return mask
    
    def plot_design_matrices(self) -> None:
        """
        Visualize the static trial-wise design matrix for the current experiment.

        This method plots a heatmap showing the input features and reward values
        assigned to each trial type in the current design matrix. This helps visualize
        the structure of the input-output relationships across trial types, especially
        in logic tasks and multitask variants.
        """

        # Retrieve feature names and design matrix
        feature_names = self._get_feature_names()
        design_matrix = self.construct_design_matrix()

        fig, ax = plt.subplots(figsize=(8, 8))

        sns.heatmap(
            design_matrix,
            ax=ax,
            cmap='coolwarm',
            center=0,
            xticklabels=feature_names[:design_matrix.shape[1]],
            yticklabels=[f'Trial {i + 1}' for i in range(design_matrix.shape[0])],
            annot=True,
            fmt='.1f')
        ax.set_title(f'{self.encoding_mode.value.title()} Encoding\n{self.experiment_type.name}')
        ax.set_xlabel('Features')
        ax.set_ylabel('Trial Types')

        plt.tight_layout()
        plt.show()
    

    def plot_event_sequence(self) -> None:
        """
        Plot the temporal sequence of binary event signals used to structure input and reward delivery.

        This visualization shows when different feature and reward signals are active over time.
        For multitask experiments, includes task ID channels as well.
        """
        events, T, times = self.generate_sequence_events()

        # Determine channel names dynamically
        if self.experiment_type == ExperimentType.abstract_binary_multitask:
            task_channels = [f'Task {i}' for i in range(len(self.task_indices))]
            event_names = task_channels + ['Colour', 'Shape', 'Width', 'Reward']
        elif self.experiment_type == ExperimentType.continual_abstract:
            event_names = ['Task ID', 'Colour', 'Shape', 'Width', 'Reward']
        else:
            event_names = ['Colour', 'Shape', 'Width', 'Reward']

        # Set figure dimensions based on number of event channels
        width = 8
        height = max(6, len(event_names) * 0.8)
        fig, ax = plt.subplots(figsize=(width, height))

        # Plot each event channel vertically offset
        spacing = 1.5
        for i, (event, name) in enumerate(zip(events, event_names)):
            ax.plot(times, event + i * spacing, label=name, linewidth=5)

        # Set labels and title
        ax.set_xlabel('Time (ms)', labelpad=10, fontsize=15)
        ax.set_ylabel('Event Channel', labelpad=10, fontsize=15)
        ax.set_title(f'Temporal Event Structure – {self.experiment_type.name}', pad=20)

        # Customize y-axis to show channel names clearly
        ax.set_yticks([i * spacing for i in range(len(event_names))])
        ax.set_yticklabels(event_names, fontsize=12)

        ax.grid(False, alpha=0.3)
        #ax.legend(loc='upper right')
        plt.tight_layout()
        plt.show()


    def plot_trial_types(self, n_trials: Optional[int] = None) -> None:
        """
        Plot a representative set of trial types showing temporally structured inputs and reward signals.

        Args:
            n_trials (int): Total number of trials to generate. If None, uses default based on experiment type.
        """
        # Set number of trials based on experiment type if not provided
        if n_trials is None:
            if self.experiment_type == ExperimentType.xor_colour_gen:
                n_trials = 240
            elif self.experiment_type == ExperimentType.abstract_binary_multitask:
                n_trials = len(self.task_indices) * 8 * 10  # 10 repetitions per task/trial type
            else:
                n_trials = 480  # Default for simpler tasks

        # Generate data and extract trial types and event times
        X, y, trial_types, times = self.generate_data(
            n_trials=n_trials,
            input_noise_std=self.input_noise_std,
            return_trial_types=True,
            return_times=True,
        )

        # Determine grid size for subplots based on experiment type
        if self.experiment_type == ExperimentType.xor_colour_gen:
            n_rows, n_cols = 4, 4
        elif self.experiment_type == ExperimentType.abstract_binary_multitask:
            n_rows = len(self.task_indices)
            n_cols = 8  # 8 unique trial types per task
        else:
            n_rows, n_cols = 2, 4

        # Set overall figure dimensions
        width = max(30, n_cols * 4)
        height = min(30, n_rows * 6)
        fig = plt.figure(figsize=(width + 2, height))
        gs = fig.add_gridspec(n_rows, n_cols)

        unique_types = np.sort(np.unique(trial_types))
        input_names = self._get_input_names()
        n_tasks = len(self.task_indices) if self.experiment_type == ExperimentType.abstract_binary_multitask else 0

        # Skip task ID channels for multitask inputs
        if self.experiment_type == ExperimentType.abstract_binary_multitask:
            input_names = input_names[n_tasks:]

        # Color palette for input signals
        colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728',  "#ee00ff"][:len(input_names)]

        # Legend setup
        legend_ax = fig.add_axes([0.92, 0.1, 0.05, 0.8])
        legend_ax.axis('off')
        legend_lines = [plt.Line2D([0], [0], color=color, label=name)
                        for color, name in zip(colors, input_names)]
        legend_lines.append(plt.Line2D([0], [0], color='red', alpha=0.2, linewidth=10, label='Reward'))
        legend_ax.legend(handles=legend_lines, loc='center left')

        for trial_type in unique_types:
            trial_idx = np.where(trial_types == trial_type)[0][0]
            row = trial_type // n_cols
            col = trial_type % n_cols
            ax = fig.add_subplot(gs[row, col])

            # Plot inputs (skip task ID if multitask)
            X_plot = X[trial_idx, :, n_tasks:] if self.experiment_type == ExperimentType.abstract_binary_multitask else X[trial_idx]
            for i, (name, color) in enumerate(zip(input_names, colors)):
                ax.plot(times, X_plot[:, i].cpu().numpy(), color=color, linewidth=4, alpha=0.7)

            # Overlay reward signal
            reward = y[trial_idx, :, 0].cpu().numpy()
            ax.fill_between(times, 0, reward, alpha=0.2, color='red')

            # Set subplot title
            if self.experiment_type == ExperimentType.abstract_binary_multitask:
                task_idx = trial_type // 8
                ax.set_title(f'Task {self.task_indices[task_idx]}\nTrial {trial_type % 8}', fontsize=15)
            else:
                ax.set_title(f'Trial Type {trial_type}', fontsize=20)

            ax.grid(True, alpha=0.3)
            if trial_type >= (n_rows - 1) * n_cols:
                ax.set_xlabel('Time (ms)', fontsize=15)
            if trial_type % n_cols == 0:
                ax.set_ylabel('Input')
            ax.set_ylim(-1.5, 1.5)

        plt.suptitle(f'All Trial Types – {self.experiment_type.name}', fontsize=16, y=0.95)
        plt.subplots_adjust(right=0.9)
        plt.show()

        #self._print_trial_summary(X, y, trial_types, input_names)

    def _get_feature_names(self) -> List[str]:
        """
        Get the names of columns in the design matrix (inputs + reward),
        depending on the experiment type.

        Returns:
            List of feature names in order of columns in the design matrix.
        """
        if self.experiment_type == ExperimentType.abstract_binary_multitask:
            task_channels = [f'Task_{i}' for i in range(len(self.task_indices))]
            return task_channels + ['Color', 'Shape', 'Width', 'Reward']
        elif self.experiment_type in {ExperimentType.xor_colour_gen, ExperimentType.xor_inactive_feat}:
            return ['Color 1', 'Color 2', 'Shape', 'Width', 'Reward']
        else:
            return ['Color', 'Shape', 'Width', 'Reward']
        
    def _get_event_names(self) -> List[str]:
        """
        Get the names of temporal event channels in the event sequence matrix.

        Returns:
            List of names corresponding to each channel in the event sequence.
        """
        if self.experiment_type == ExperimentType.abstract_binary_multitask:
            task_channels = [f'Task_{i}' for i in range(len(self.task_indices))]
            return task_channels + ['Color', 'Shape', 'Width', 'Reward']
        else:
            return ['Color', 'Shape', 'Width', 'Reward']
    
    def _get_input_names(self) -> List[str]:
        """
        Get the names of input channels (excluding reward).

        Used mainly for plotting trial inputs.

        Returns:
            List of input feature names (not including reward).
        """
        if self.experiment_type == ExperimentType.abstract_binary_multitask:
            task_channels = [f'Task_{i}' for i in range(len(self.task_indices))]
            return task_channels + ['Color', 'Shape', 'Width']
        if self.experiment_type == ExperimentType.continual_abstract:
            return ['task_id', 'Color', 'Shape', 'Width']
        elif self.experiment_type in {ExperimentType.xor_colour_gen, ExperimentType.xor_inactive_feat}:
            return ['Color 1', 'Color 2', 'Shape', 'Width']
        else:
            return ['Color', 'Shape', 'Width']
        
    def _print_trial_summary(self, X: torch.Tensor, y: torch.Tensor, trial_types: np.ndarray, input_names: List[str]) -> None:
        """
        Print a diagnostic summary of what each trial type looks like.

        Args:
            X (torch.Tensor): Input tensor of shape (n_trials, T, input_dim).
            y (torch.Tensor): Output tensor of shape (n_trials, T, 2).
            trial_types (np.ndarray): Trial type index for each trial.
            input_names (List[str]): Names of input channels (same order as in X).
        """
        unique_types = np.sort(np.unique(trial_types))

        print(f"\n{self.experiment_type.name} Data Summary")
        print(f"Input shape: {X.shape}")
        print(f"Output shape: {y.shape}")
        print(f"Number of unique trial types: {len(unique_types)}")

        for trial_type in unique_types:
            trial_idx = np.where(trial_types == trial_type)[0][0]
            max_activations = np.max(np.abs(X[trial_idx].cpu().numpy()), axis=0)

            # Identify which inputs are non-zero
            active_inputs = [name for name, max_val in zip(input_names, max_activations) if max_val > 0.5]
            has_reward = (y[trial_idx, :, 0] > 0.5).any().item()

            print(f"\nTrial Type {trial_type}:")
            print(f"  Active Inputs: {', '.join(active_inputs)}")
            print(f"  Reward Present: {'Yes' if has_reward else 'No'}")

    def plot_experiment_summary(self) -> None:
        """
        Visual diagnostic wrapper that plots all core components of a logic experiment.

        This convenience function visualizes the trial design matrix, temporal event structure,
        and the full set of input/output trials. Useful for debugging or understanding 
        task configurations at a glance.
        """
        print(f"\n{'=' * 50}\nAnalyzing {self.experiment_type.name} – {self.abstract_task_type}\n{'=' * 50}")

        print("\nDesign Matrix:")
        self.plot_design_matrices()

        print("\nEvent Sequence:")
        self.plot_event_sequence()

        print("\nTrial Types:")
        self.plot_trial_types()

    # Could remove following methods, but kept for completeness
    def _get_plot_grid_size(self) -> Tuple[int, int]:
        """
        Return the number of rows and columns for plotting trial grids.

        Grid size is chosen based on experiment type to ensure clean subplot layouts.
        """
        if self.experiment_type == ExperimentType.xor_colour_gen:
            return 4, 4
        elif self.experiment_type == ExperimentType.abstract_binary_multitask:
            return len(self.task_indices), 8  # 8 trial types per task
        else:
            return 2, 4

    def _plot_trial_grid(
        self,
        fig,
        gs,
        X: torch.Tensor,
        y: torch.Tensor,
        times: np.ndarray,
        trial_types: np.ndarray,
        unique_types: np.ndarray,
        input_names: List[str],
        n_rows: int,
        n_cols: int
    ) -> None:
        """
        Helper method to draw a grid of input/reward plots for each trial type.

        Args:
            fig: Matplotlib figure object.
            gs: GridSpec object for subplot placement.
            X: Input tensor.
            y: Output tensor.
            times: Time vector.
            trial_types: Array of trial type indices.
            unique_types: Unique trial types to plot.
            input_names: List of input channel names.
            n_rows: Number of subplot rows.
            n_cols: Number of subplot columns.
        """
        colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728'][:len(input_names)]

        for trial_type in unique_types:
            trial_idx = np.where(trial_types == trial_type)[0][0]
            ax = fig.add_subplot(gs[trial_type // n_cols, trial_type % n_cols])

            for i, (name, color) in enumerate(zip(input_names, colors)):
                ax.plot(times, X[trial_idx, :, i].cpu().numpy(),
                        label=name, color=color, linewidth=2)

            reward = y[trial_idx, :, 0].cpu().numpy()
            ax.fill_between(times, 0, reward, alpha=0.2, color='gray', label='Reward')

            ax.set_title(f'Trial Type {trial_type}')
            ax.grid(True, alpha=0.3)

            if trial_type == 0:
                ax.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
            if trial_type >= (n_rows - 1) * n_cols:
                ax.set_xlabel('Time (ms)')
            if trial_type % n_cols == 0:
                ax.set_ylabel('Input/Output')