"""
visualisation.py

Visualization utilities for plotting training dynamics, decoding scores, 
and neural representations in meta-learning experiments.

This module provides a variety of tools for visualizing model performance, 
such as accuracy over time, weight/gradient dynamics, decoding heatmaps, 
and task-specific metrics. These plots support both debugging and 
publication-quality figures.
"""

import warnings
import torch
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import gaussian_kde
from matplotlib.colors import LinearSegmentedColormap
import matplotlib.gridspec as gridspec



def plot_trial_type_comparison(data_generator, model, device='cpu'):
    """
    Create a grid of plots comparing inputs, targets, and model outputs for each trial type.
    Modified to handle abstract multitask experiment.

    Args:
        data_generator: Instance of DataGenerator
        model: Trained model (e.g., ExperimentNetwork)
        device: Torch device
    """
    # Determine number of tasks
    n_tasks = len(data_generator.task_indices)

    # Generate data across all trial types
    X, y, trial_types, times = data_generator.generate_data(
        n_trials=8 * n_tasks * 10,
        input_noise_std=0.0,
        return_trial_types=True,
        return_times=True
    )

    # Run model to get outputs
    model.eval()
    with torch.no_grad():
        X_input = X.transpose(0, 1).to(device)
        if model.model.controller_enabled:
            outputs, _, _ = model(X_input)
        else:
            outputs, _ = model(X_input)

    # Convert tensors to numpy
    X = X.cpu().numpy()
    y = y.cpu().numpy()
    outputs = outputs.transpose(0, 1).cpu().numpy()

    # Get input and output labels
    input_names = data_generator._get_input_names()
    unique_types = np.sort(np.unique(trial_types))
    n_types = len(unique_types)

    # Define colors
    n_task_channels = len(data_generator.task_indices)
    task_colors = ['#e41a1c', '#377eb8'][:n_task_channels]
    feature_colors = ['#4daf4a', '#984ea3', '#ff7f00']
    input_colors = task_colors + feature_colors
    output_colors = ['#9467bd', '#8c564b']  # Reward, No reward

    # Setup figure layout
    fig_height = 3 * n_types + 1
    fig = plt.figure(figsize=(15, fig_height))
    gs = fig.add_gridspec(n_types, 3, height_ratios=[1]*n_types, width_ratios=[1, 1, 1], hspace=0.5, wspace=0.4)

    # Legends
    legend_ax1 = fig.add_axes([0.92, 0.6, 0.08, 0.3])
    legend_ax2 = fig.add_axes([0.92, 0.2, 0.08, 0.3])
    legend_ax1.axis('off')
    legend_ax2.axis('off')
    input_lines = [plt.Line2D([0], [0], color=color, label=name)
                   for color, name in zip(input_colors, input_names)]
    output_lines = [plt.Line2D([0], [0], color=color, label=name)
                    for color, name in zip(output_colors, ['Reward', 'No Reward'])]
    legend_ax1.legend(handles=input_lines, loc='center', title='Input Signals', title_fontsize=10, fontsize=9)
    legend_ax2.legend(handles=output_lines, loc='center', title='Output Signals', title_fontsize=10, fontsize=9)

    # Plot for each trial type
    for i, trial_type in enumerate(unique_types):
        trial_idx = np.where(trial_types == trial_type)[0][0]
        task_idx = trial_type // 8
        trial_within_task = trial_type % 8

        # Plot inputs
        ax1 = fig.add_subplot(gs[i, 0])
        for j, (name, color) in enumerate(zip(input_names, input_colors)):
            ax1.plot(times, X[trial_idx, :, j], color=color, linewidth=2)
        ax1.set_title(f'Task {data_generator.task_indices[task_idx]}\nTrial {trial_within_task}\nInputs', pad=10)
        ax1.set_xlabel('Time (ms)')
        ax1.set_ylabel('Input Value')
        ax1.set_ylim(-1.1, 1.1)
        ax1.grid(True, alpha=0.3)

        # Plot target outputs
        ax2 = fig.add_subplot(gs[i, 1])
        for j, color in enumerate(output_colors):
            ax2.plot(times, y[trial_idx, :, j], color=color, linewidth=2)
        ax2.set_title('Target Outputs', pad=10)
        ax2.set_xlabel('Time (ms)')
        ax2.set_ylabel('Target Value')
        ax2.set_ylim(-1.1, 1.1)
        ax2.grid(True, alpha=0.3)

        # Plot model outputs
        ax3 = fig.add_subplot(gs[i, 2])
        for j, color in enumerate(output_colors):
            ax3.plot(times, outputs[trial_idx, :, j], color=color, linewidth=2)
        ax3.set_title('Model Outputs', pad=10)
        ax3.set_xlabel('Time (ms)')
        ax3.set_ylabel('Model Output')
        ax3.grid(True, alpha=0.3)

    # Super title
    plt.suptitle('Trial Type Comparison: Inputs, Targets, and Model Outputs\n'
                 f'Tasks: {data_generator.task_indices}', fontsize=16, y=0.98)
    plt.subplots_adjust(left=0.08, right=0.9, top=0.95, bottom=0.05)

    # Output summary statistics
    print("\nModel Output Analysis:")
    for task_idx in range(n_tasks):
        task_id = data_generator.task_indices[task_idx]
        print(f"\nTask {task_id}:")
        task_type = data_generator._get_abstract_task_type(
            data_generator._generate_abstract_binary_patterns()[task_id])
        print(f"Task type: {task_type}")

        task_correct = 0
        for trial_within_task in range(8):
            trial_type = task_idx * 8 + trial_within_task
            trial_idx = np.where(trial_types == trial_type)[0][0]
            reward_start = np.where(times >= data_generator.temporal_params.reward_onset)[0][0]
            reward_end = np.where(times >= data_generator.temporal_params.reward_offset)[0][0]
            true_label = np.argmax(y[trial_idx, reward_start:reward_end].mean(axis=0))
            pred_label = np.argmax(outputs[trial_idx, reward_start:reward_end].mean(axis=0))
            confidence = np.abs(np.diff(outputs[trial_idx, reward_start:reward_end].mean(axis=0)))[0]

            print(f"\n  Trial {trial_within_task}:")
            print(f"  True label: {'Reward' if true_label == 0 else 'No Reward'}")
            print(f"  Predicted: {'Reward' if pred_label == 0 else 'No Reward'}")
            print(f"  Confidence: {confidence:.3f}")
            print(f"  Correct: {'Yes' if true_label == pred_label else 'No'}")

            if true_label == pred_label:
                task_correct += 1

        print(f"\n  Task Accuracy: {(task_correct / 8) * 100:.1f}%")


def plot_training_analysis(results_list):
    """
    Plot training analysis for one or more models across multiple epochs.

    This function visualizes:
    - Loss and accuracy curves with SEM
    - Gradient norms over time
    - Firing rates
    - Initial vs final weight matrices
    - Weight norm evolution
    - Weight distribution histograms with KDE overlays

    Args:
        results_list (list or dict): List of result dicts (or a single dict) from model training.
    """
    if not isinstance(results_list, list):
        results_list = [results_list]

    # We assume results_list contains dicts with keys:
    # 'initial_weights', 'final_weights', 'train_losses', 'train_accuracies',
    # 'gradient_history', 'firing_rates', 'weight_changes'.
    # Each dict corresponds to a trained model's recorded data over epochs.

    results = results_list[0]
    n_weights = len(results['initial_weights'])  # Number of weight matrices to analyze

    # Setup figure with subplots arranged in a grid:
    # One row for summary stats (loss, accuracy, gradients, firing rates)
    # Followed by one row per weight matrix for weight visualizations
    fig_height = 4 * (n_weights + 1)
    fig = plt.figure(figsize=(20, fig_height))
    gs = fig.add_gridspec(
        n_weights + 1, 4,
        height_ratios=[1] + [1.2] * n_weights,
        width_ratios=[1, 1, 1, 1.5],
        hspace=0.5,
        wspace=0.4
    )

    # Create axes for legends separately to keep main plots clean
    legend_ax1 = fig.add_axes([0.9, 0.7, 0.1, 0.25])
    legend_ax2 = fig.add_axes([0.9, 0.4, 0.1, 0.25])
    legend_ax1.axis('off')
    legend_ax2.axis('off')

    def get_mean_sem(data_list):
        # Compute mean and standard error of mean (SEM) across multiple runs
        data_array = np.array(data_list)
        mean = np.mean(data_array, axis=0)
        sem = np.std(data_array, axis=0) / np.sqrt(len(data_list))
        return mean, sem

    # Determine global min/max weight values across all models and weight matrices
    # This is to ensure consistent color scaling in heatmaps
    global_weight_min = float('inf')
    global_weight_max = float('-inf')

    for results in results_list:
        for name in results['initial_weights'].keys():
            init_w = results['initial_weights'][name].numpy()
            final_w = results['final_weights'][name].numpy()
            global_weight_min = min(global_weight_min, init_w.min(), final_w.min())
            global_weight_max = max(global_weight_max, init_w.max(), final_w.max())

    # Determine maximum density for KDE plots to scale y-axis consistently
    global_density_max = 0
    for results in results_list:
        for name in results['initial_weights'].keys():
            # Aggregate all initial and final weights from all models for KDE
            init_weights_all = np.concatenate([r['initial_weights'][name].numpy().flatten() for r in results_list])
            final_weights_all = np.concatenate([r['final_weights'][name].numpy().flatten() for r in results_list])
            try:
                init_kde = gaussian_kde(init_weights_all)
                final_kde = gaussian_kde(final_weights_all)
                x_range = np.linspace(global_weight_min, global_weight_max, 200)
                # Update global max density for plotting limits
                global_density_max = max(global_density_max, np.max(init_kde(x_range)), np.max(final_kde(x_range)))
            except np.linalg.LinAlgError:
                warnings.warn(f"KDE failed for layer '{name}' due to singular covariance. Skipping KDE plot.")

    # Extract training loss and accuracy arrays across models for averaging
    losses_list = [r['train_losses'] for r in results_list]
    accs_list = [r['train_accuracies'] for r in results_list]
    mean_loss, sem_loss = get_mean_sem(losses_list)
    mean_acc, sem_acc = get_mean_sem(accs_list)

    # Plot mean training loss with SEM shaded region
    ax_loss = fig.add_subplot(gs[0, 0])
    epochs = np.arange(len(mean_loss))
    ax_loss.plot(epochs, mean_loss, 'b-')
    ax_loss.fill_between(epochs, mean_loss - sem_loss, mean_loss + sem_loss, alpha=0.2, color='b')
    ax_loss.set_xlabel('Epoch')
    ax_loss.set_ylabel('Loss')
    ax_loss.set_title('Mean Training Loss')
    ax_loss.grid(True)

    # Plot mean training accuracy with SEM shaded region
    ax_acc = fig.add_subplot(gs[0, 1])
    ax_acc.plot(epochs, mean_acc, 'r-')
    ax_acc.fill_between(epochs, mean_acc - sem_acc, mean_acc + sem_acc, alpha=0.2, color='r')
    ax_acc.set_xlabel('Epoch')
    ax_acc.set_ylabel('Accuracy')
    ax_acc.set_title('Mean Training Accuracy')
    ax_acc.grid(True)

    # Plot gradient norms evolution normalized by initial gradient norm for each layer
    ax_grad = fig.add_subplot(gs[0, 2])
    for name in results['gradient_history'].keys():
        grads_list = [r['gradient_history'][name] for r in results_list]
        mean_grads, sem_grads = get_mean_sem(grads_list)
        if mean_grads[0] == 0:
            # Warn if initial gradient is zero (likely frozen layer), skip normalization
            warnings.warn(f"Zero initial gradient in layer {name}. Likely frozen.", RuntimeWarning)
            normalized_mean = mean_grads
            normalized_sem = sem_grads
        else:
            # Normalize gradient norms relative to initial value for comparability
            normalized_mean = mean_grads / mean_grads[0]
            normalized_sem = sem_grads / mean_grads[0]
        ax_grad.plot(normalized_mean, label=f'{name} (rel.)')
        ax_grad.fill_between(epochs, normalized_mean - normalized_sem,
                             normalized_mean + normalized_sem, alpha=0.2)
    ax_grad.set_xlabel('Epoch')
    ax_grad.set_ylabel('Relative Gradient Norm')
    ax_grad.set_title('Mean Gradient Evolution')
    ax_grad.legend()
    ax_grad.grid(True)
    # Place legend on separate axis to avoid clutter
    legend_ax1.legend(*ax_grad.get_legend_handles_labels(), title='Gradient Evolution')
    ax_grad.get_legend().remove()

    # Plot mean firing rate evolution with SEM
    ax_frate = fig.add_subplot(gs[0, 3])
    # Use raw firing rates as arrays (no mean over last two dims)
    firing_rates_list = [r['firing_rates'].mean(axis=(1, 2)) for r in results_list]
    mean_rates, sem_rates = get_mean_sem(firing_rates_list)
    ax_frate.plot(epochs, mean_rates, 'g-', label='Mean')
    ax_frate.fill_between(epochs, mean_rates - sem_rates, mean_rates + sem_rates, color='g', alpha=0.2)
    ax_frate.set_xlabel('Epoch')
    ax_frate.set_ylabel('Firing Rate')
    ax_frate.set_title('Mean Firing Rate')
    ax_frate.legend()
    ax_frate.grid(True)
    # Place legend on separate axis to avoid clutter
    legend_ax2.legend(*ax_frate.get_legend_handles_labels(), title='Firing Rates')
    ax_frate.get_legend().remove()

    # Initialize min/max for weight and norm plots to scale axes properly
    weight_min = float('inf')
    weight_max = float('-inf')
    norm_min = float('inf')
    norm_max = float('-inf')

    # Compute min/max weight values and norm changes across models for each weight matrix
    for name in results['initial_weights'].keys():
        init_w = results['initial_weights'][name].numpy()
        final_w = results['final_weights'][name].numpy()
        weight_min = min(weight_min, init_w.min(), final_w.min())
        weight_max = max(weight_max, init_w.max(), final_w.max())
        # Compute mean weight change norm across models
        weight_changes_list = [r['weight_changes'][name] for r in results_list]
        mean_changes, _ = get_mean_sem(weight_changes_list)
        # Normalize by number of weights to get average per weight
        mean_changes = mean_changes / final_w.flatten().shape[0]
        # Adjust by subtracting initial value to focus on change over epochs
        mean_changes -= mean_changes[0]
        norm_min = min(norm_min, mean_changes.min())
        norm_max = max(norm_max, mean_changes.max())

    # Set symmetric color scale limits centered at zero for heatmaps
    abs_max = max(abs(weight_min), abs(weight_max))
    vmin, vmax = -abs_max, abs_max

    # Plot weight matrices and related statistics for each weight matrix
    for i, (name, init_w) in enumerate(results['initial_weights'].items(), 1):
        final_w = results['final_weights'][name]

        # Heatmap of initial weights for example model
        ax1 = fig.add_subplot(gs[i, 0])
        sns.heatmap(init_w.numpy(), cmap='coolwarm', center=0, vmin=vmin, vmax=vmax, ax=ax1)
        ax1.set_title(f'{name} Initial Weights\n(Example Model)')

        # Heatmap of final weights for example model
        ax2 = fig.add_subplot(gs[i, 1])
        sns.heatmap(final_w.numpy(), cmap='coolwarm', center=0, vmin=vmin, vmax=vmax, ax=ax2)
        ax2.set_title(f'{name} Final Weights\n(Example Model)')

        # Plot mean weight norm evolution over epochs with SEM
        ax3 = fig.add_subplot(gs[i, 2])
        weight_changes_list = [r['weight_changes'][name] for r in results_list]
        mean_changes, sem_changes = get_mean_sem(weight_changes_list)
        mean_changes = mean_changes / final_w.flatten().shape[0]  # Normalize by number of weights
        mean_changes -= mean_changes[0]  # Center at zero for initial epoch
        epochs_weights = np.arange(len(mean_changes))
        ax3.plot(epochs_weights, mean_changes, 'g-')
        ax3.fill_between(epochs_weights, mean_changes - sem_changes,
                         mean_changes + sem_changes, color='g', alpha=0.2)
        ax3.set_xlabel('Epoch')
        ax3.set_ylabel('Weight Norm')
        ax3.set_title(f'{name} Mean Weight Norm Evolution')
        ax3.grid(True)
        
        # Plot histograms and KDE overlays of initial and final weight distributions
        ax4 = fig.add_subplot(gs[i, 3])
        ax4_twin = ax4.twinx()
        # Aggregate all initial and final weights from all models for KDE and histogram
        init_weights_all = np.concatenate([r['initial_weights'][name].numpy().flatten() for r in results_list])
        final_weights_all = np.concatenate([r['final_weights'][name].numpy().flatten() for r in results_list])
        try:
            init_kde = gaussian_kde(init_weights_all)
            final_kde = gaussian_kde(final_weights_all)
            kde_success = True
        except np.linalg.LinAlgError:
            warnings.warn(f"KDE failed for layer '{name}' due to singular covariance. Skipping KDE plot.")
            kde_success = False
        x_range = np.linspace(global_weight_min, global_weight_max, 200)
        # Histogram of initial weights (blue, left y-axis)
        ax4.hist(init_weights_all, bins=50, density=True, alpha=0.3, color='blue',
                 range=(global_weight_min, global_weight_max))
        # KDE curve for initial weights
        if kde_success:
            ax4.plot(x_range, init_kde(x_range), 'b--', linewidth=2)
        # Histogram of final weights (red, right y-axis)
        ax4_twin.hist(final_weights_all, bins=50, density=True, alpha=0.3, color='red',
                      range=(global_weight_min, global_weight_max))
        # KDE curve for final weights
        if kde_success:
            ax4_twin.plot(x_range, final_kde(x_range), 'r--', linewidth=2)
        # Set x-axis limits consistent across plots
        ax4.set_xlim(global_weight_min, global_weight_max)
        # Set y-axis limits to max density with padding for clarity
        ax4.set_ylim(0, global_density_max * 1.1)
        ax4_twin.set_ylim(0, global_density_max * 1.1)
        ax4.set_xlabel('W')
        ax4.set_ylabel('Density')
        ax4.set_title(f'{name} Weight Distribution\n(All Models)')
        # Add text labels for initial and final weight histograms
        ax4.text(0.05, 0.95, 'Initial', color='blue', transform=ax4.transAxes, verticalalignment='top')
        ax4.text(0.05, 0.85, 'Final', color='red', transform=ax4.transAxes, verticalalignment='top')
        ax4.grid(True, alpha=0.2)

    plt.suptitle('Network Analysis (Mean across Models)', fontsize=16, y=0.98)
    plt.subplots_adjust(left=0.08, right=0.95, top=0.96, bottom=0.05)
    plt.show()

    # Print summary statistics
    print("\nWeight Norm Summary (Mean ± SEM across models):")
    for name in results['initial_weights'].keys():
        init_norms = [torch.norm(r['initial_weights'][name]).item() for r in results_list]
        final_norms = [torch.norm(r['final_weights'][name]).item() for r in results_list]
        norm_changes = [f - i for f, i in zip(final_norms, init_norms)]
        rel_changes = [(f - i) / i * 100 if i != 0 else 0.0 for f, i in zip(final_norms, init_norms)]

        mean_init, sem_init = np.mean(init_norms), np.std(init_norms) / np.sqrt(len(init_norms))
        mean_final, sem_final = np.mean(final_norms), np.std(final_norms) / np.sqrt(len(final_norms))
        mean_change, sem_change = np.mean(norm_changes), np.std(norm_changes) / np.sqrt(len(norm_changes))
        mean_rel, sem_rel = np.mean(rel_changes), np.std(rel_changes) / np.sqrt(len(rel_changes))

        print(f"\n{name}:")
        print(f"Initial Norm: {mean_init:.4f} ± {sem_init:.4f}")
        print(f"Final Norm: {mean_final:.4f} ± {sem_final:.4f}")
        print(f"Norm Change: {mean_change:.4f} ± {sem_change:.4f}")
        print(f"Relative Change: {mean_rel:.2f}% ± {sem_rel:.2f}%")

    print("\nFiring Rate Summary (Mean ± SEM across models):")
    firing_rates_list = [r['firing_rates'].mean((-1, -2)) for r in results_list]
    mean_rates, sem_rates = np.mean(firing_rates_list, axis=0), np.std(firing_rates_list, axis=0) / np.sqrt(len(firing_rates_list))
    print(f"Initial Mean Rate: {mean_rates[0]:.4f} ± {sem_rates[0]:.4f}")
    print(f"Final Mean Rate: {mean_rates[-1]:.4f} ± {sem_rates[-1]:.4f}")
    print(f"Mean Rate Change: {(mean_rates[-1] - mean_rates[0]):.4f} ± {(sem_rates[-1] + sem_rates[0]):.4f}")

    rate_mins = [r['firing_rates'].mean((-1, -2)).min().item() for r in results_list]
    rate_maxs = [r['firing_rates'].mean((-1, -2)).max().item() for r in results_list]
    mean_min, sem_min = np.mean(rate_mins), np.std(rate_mins) / np.sqrt(len(rate_mins))
    mean_max, sem_max = np.mean(rate_maxs), np.std(rate_maxs) / np.sqrt(len(rate_maxs))
    print(f"Rate Range: [{mean_min:.4f} ± {sem_min:.4f}, {mean_max:.4f} ± {sem_max:.4f}]")


def plot_task_accuracies(combined_results, task_descriptions, task_sequence=None, figsize=(12, 6)):
    """
    Plot task-specific training accuracies across epochs, annotated with training periods.

    This function shows how the model's performance on each task evolves over time.
    Vertical dashed lines separate training days, and annotated labels indicate
    which tasks were trained on each day.

    Args:
        combined_results (dict): Combined output from training phases, must include
            'train_accuracies_per_task' and 'train_accuracies'.
        task_descriptions (dict): Mapping from task ID to human-readable name.
        task_sequence (list of lists): Ordered task IDs used during each training phase/day.
        figsize (tuple): Figure size for the plot.
    """
    fig, ax = plt.subplots(figsize=figsize)

    # Determine how many epochs were spent per training period
    epochs_per_day = len(combined_results['train_accuracies']) // len(task_sequence)
    total_epochs = epochs_per_day * len(task_sequence)
    epochs = np.arange(total_epochs)

    # Define task-specific color mapping
    colors = {
        0: '#ff7f0e', 1: '#ff1493', 2: '#ff4500', 3: '#ff6347', 4: '#ff8c00', 5: '#ffd700',
        6: '#ffff00', 7: '#9acd32', 8: '#32cd32', 9: '#d62728', 10: '#00ff00', 11: '#00fa9a',
        12: '#00ffff', 13: '#00bfff', 14: '#1f77b4', 15: '#0000ff', 16: '#8a2be2', 17: '#9370db',
        18: '#9932cc', 19: '#9400d3', 20: '#800080', 21: '#8b008b', 22: '#ff00ff', 23: '#ff69b4',
        24: '#dc143c', 25: '#b22222', 26: '#8b4513', 27: '#2ca02c', 28: '#556b2f', 29: '#006400',
        30: '#483d8b', 31: '#4b0082', 32: '#8b0000', 33: '#800000', 34: '#4a4a4a',
    }

    # Plot accuracy for each task
    for task_id, accuracies in combined_results['train_accuracies_per_task'].items():
        label = f'Task {task_id}: {task_descriptions.get(task_id, str(task_id))}'
        ax.plot(epochs, accuracies, label=label,
                color=colors.get(task_id, 'black'), linewidth=2)

    # Add vertical dashed lines between days
    for day in range(1, len(task_sequence)):
        ax.axvline(x=day * epochs_per_day, color='gray', linestyle='--', alpha=0.5)

    # Axes labels and formatting
    ax.set_xlabel('Epochs', fontsize=12)
    ax.set_ylabel('Accuracy', fontsize=12)
    ax.set_title('Task Accuracies During Training', fontsize=14, pad=15)
    ax.grid(True, alpha=0.3)
    ax.set_ylim(0.4, 1.05)
    ax.axhline(0.5, color='gray', linestyle='--', alpha=0.5)

    # Add annotations for each day
    for day, tasks in enumerate(task_sequence):
        start_x = day * epochs_per_day
        y_pos = 1.05
        task_text = f'Day {day + 1}: ' + ' & '.join(task_descriptions.get(t, str(t)) for t in tasks)
        ax.text(start_x + epochs_per_day / 2, y_pos,
                task_text, ha='center', va='bottom', fontsize=10)

    # Adjust legend and layout
    ax.legend(fontsize=10, bbox_to_anchor=(1.05, 1), loc='upper left')
    plt.subplots_adjust(right=0.85, top=0.85)
    return

def plot_mean_decoding_scores(scores, std_error=True, figsize=(8, 4)):
    """
    Plot the average decoding scores across all patterns for each epoch.

    This function visualizes how well neural representations support decoding
    of different trial-type patterns over training epochs. Optionally includes
    standard error bands.

    Args:
        scores (np.ndarray): Array of shape (n_epochs, n_patterns) containing
            decoding scores for each pattern at each epoch.
        std_error (bool): Whether to include standard error shading.
        figsize (tuple): Figure size for the plot.

    Returns:
        fig, ax: Matplotlib figure and axis objects.
    """
    fig, ax = plt.subplots(figsize=figsize)

    # Compute mean decoding score across all patterns
    mean_scores = np.mean(scores, axis=1)

    # Optionally compute standard error across patterns
    if std_error:
        se = np.std(scores, axis=1) / np.sqrt(scores.shape[1])

    # Plot mean decoding score over epochs
    epochs = np.arange(len(mean_scores))
    ax.plot(epochs, mean_scores, 'b-', linewidth=2)

    # Plot shaded standard error band
    if std_error:
        ax.fill_between(epochs,
                        mean_scores - se,
                        mean_scores + se,
                        alpha=0.2,
                        color='b')

    # Reference lines to mark key epochs and baseline decoding level
    ax.axvline(x=20, color='gray', linestyle=':', alpha=0.7)
    ax.axvline(x=40, color='gray', linestyle=':', alpha=0.7)
    ax.axhline(y=0.5, color='gray', linestyle=':', alpha=0.7)

    # Configure axis labels and title
    ax.set_xlabel('Epoch')
    ax.set_ylabel('Mean Decoding Score')
    ax.set_title('Neural Dimensionality (Decoding Across Patterns)')
    ax.grid(True, alpha=0.3)

    # Set vertical axis limits
    ax.set_ylim(0.6, 1.0)

    plt.tight_layout()
    return fig, ax


def plot_decoding_scores(scores_learning, scores_time, task_descriptions, figsize_multiplier=(6, 4),
                         y_lim=(0.4, 1.0), fig_title=None, training_days=None):
    """
    Plot decoding performance across epochs and timepoints for each task.

    This function visualizes:
    - Top row: decoding accuracy over training epochs for each task
    - Bottom row: time-resolved decoding within selected epochs (learning stages)

    Args:
        scores_learning (np.ndarray): Array of shape (n_epochs, n_tasks), learning curve per task.
        scores_time (np.ndarray): Array of shape (n_stages, n_timepoints, n_tasks), time-resolved decoding.
        task_descriptions (dict): Mapping of task ID to task name/description.
        figsize_multiplier (tuple): Width and height scale for figure size.
        y_lim (tuple): y-axis limits for decoding score plots.
        fig_title (str): Optional title string for the entire figure.
        training_days (int): Number of training phases (used to draw day separators and spans).
    """
    # Get ordered list of task IDs and number of tasks
    tasks = list(task_descriptions.keys())
    n_tasks = len(tasks)
    n_epochs = scores_learning.shape[0]

    # Compute how many epochs per training period (if provided)
    if training_days is not None:
        epochs_per_day = n_epochs // training_days

    # Setup figure and subplot grid: 2 rows (learning curve, time-resolved), n_tasks columns
    fig = plt.figure(figsize=(figsize_multiplier[0]*n_tasks, figsize_multiplier[1]*2))
    if fig_title:
        plt.suptitle(fig_title, y=0.95, fontsize=14)

    # Create a 2-row x n_tasks grid for subplots
    gs = fig.add_gridspec(2, n_tasks, hspace=0.3, wspace=0.3)

    # Define a colormap from black to blue for training stage/time curves
    blues = LinearSegmentedColormap.from_list('custom_blues', ['#000000', '#1F77B4'], N=256)

    for task_idx, task in enumerate(tasks):
        task_desc = task_descriptions[task]

        # --- TOP ROW: Plot decoding accuracy over training epochs for this task ---
        ax1 = fig.add_subplot(gs[0, task_idx])
        # Plot decoding accuracy curve for this task
        ax1.plot(np.arange(n_epochs), scores_learning[:, task], color='navy')
        # Draw chance-level line (0.5)
        ax1.axhline(y=0.5, color='gray', linestyle='--', alpha=0.5)

        # If training_days provided, draw vertical day separators and highlight training span
        if training_days is not None:
            # Draw vertical lines to separate days
            for day in range(1, training_days):
                ax1.axvline(x=day * epochs_per_day, color='gray', linestyle='-', alpha=0.3)
            # Highlight gold training span: task 0 is trained on all days, others only one day
            if task_idx == 0:
                # For task 0, highlight the entire training period
                ax1.axvspan(0, n_epochs, color='gold', alpha=0.2)
            else:
                # For other tasks, highlight the single day they are trained on
                day = task_idx - 1
                start_epoch = day * epochs_per_day
                end_epoch = (day + 1) * epochs_per_day
                ax1.axvspan(start_epoch, end_epoch, color='gold', alpha=0.2)

        # Set labels, limits, and grid for clarity
        ax1.set_title(f'{task_desc}\nLearning Curve')
        ax1.set_xlabel('Epochs')
        ax1.set_ylabel('Decoding Score')
        ax1.set_ylim(y_lim)
        ax1.grid(True, alpha=0.3)

        # --- BOTTOM ROW: Plot time-resolved decoding across learning stages (blue gradient) ---
        ax2 = fig.add_subplot(gs[1, task_idx])
        # Plot decoding score at each timepoint for each training stage
        for stage_idx in range(scores_time.shape[0]):
            # Use blue gradient for each stage (earliest=black, latest=blue)
            color = blues(stage_idx / (scores_time.shape[0] - 1)) if scores_time.shape[0] > 1 else blues(0.0)
            ax2.plot(np.arange(scores_time.shape[1]), scores_time[stage_idx, :, task], color=color)

        # Draw chance-level line (0.5)
        ax2.axhline(y=0.5, color='gray', linestyle='--', alpha=0.5)
        # Set labels, limits, and grid for clarity
        ax2.set_title('Time-resolved Decoding')
        ax2.set_xlabel('Time Points')
        ax2.set_ylabel('Decoding Score')
        ax2.set_ylim(y_lim)
        ax2.grid(True, alpha=0.3)

        # Add colorbar to indicate training stage progression (blue gradient)
        sm = plt.cm.ScalarMappable(cmap=blues)
        sm.set_array([])
        cbar = plt.colorbar(sm, ax=ax2)
        cbar.set_label('Training Progress')

    # Adjust layout to leave space for figure title if present
    if fig_title:
        plt.tight_layout(rect=[0, 0, 1, 0.95])
    else:
        plt.tight_layout()


def plot_decoding_learning(scores_learning_list, task_descriptions, figsize_multiplier=(6, 4),
                           y_lim=(0.4, 1.1), fig_title=None, training_days=None, return_fig=False):
    """
    Plot decoding scores across learning epochs for multiple tasks, showing mean and SEM across seeds.

    This function aggregates decoding performance across multiple random seeds,
    computes the average learning curve and variability (SEM), and visualizes
    each task's progression over time.

    Args:
        scores_learning_list (list of np.ndarray): Each array has shape (n_epochs, n_tasks), one per seed.
        task_descriptions (dict): Mapping of task ID to descriptive label.
        figsize_multiplier (tuple): Scaling factors for figure width and height.
        y_lim (tuple): Tuple indicating y-axis limits.
        fig_title (str): Optional title for the figure.
        training_days (int or None): Number of training phases/days (if known).
        return_fig (bool): If True, return the matplotlib Figure object instead of showing.
    """
    

    # Validate input
    if not scores_learning_list:
        raise ValueError("scores_learning_list cannot be empty")

    # Extract task IDs and setup dimensions
    first_scores = scores_learning_list[0]
    tasks = list(task_descriptions.keys())
    n_tasks = len(tasks)
    n_epochs = first_scores.shape[0]

    # Compute epochs per day if number of training days is given
    if training_days is not None:
        epochs_per_day = n_epochs // training_days

    # Stack list into array of shape (n_seeds, n_epochs, n_tasks)
    scores_array = np.array(scores_learning_list)

    # Mean and SEM across seeds (axis=0)
    mean_scores = np.mean(scores_array, axis=0)
    sem_scores = np.std(scores_array, axis=0) / np.sqrt(len(scores_learning_list))

    # Set up figure and grid layout
    fig = plt.figure(figsize=(figsize_multiplier[0] * n_tasks, figsize_multiplier[1]))
    if fig_title:
        plt.suptitle(fig_title, y=0.95, fontsize=14)
    gs = fig.add_gridspec(1, n_tasks, wspace=0.3)

    # Loop through tasks to generate subplots
    for task_idx, task in enumerate(tasks):
        task_desc = task_descriptions[task]
        ax = fig.add_subplot(gs[0, task_idx])

        # X-axis range
        epochs_range = range(n_epochs)

        # Plot mean decoding curve
        ax.plot(epochs_range, mean_scores[:, task], color='navy', linewidth=2, label='Mean')

        # Plot SEM shading
        ax.fill_between(
            epochs_range,
            mean_scores[:, task] - sem_scores[:, task],
            mean_scores[:, task] + sem_scores[:, task],
            color='navy', alpha=0.2, label='±1 SEM'
        )

        # Reference line for chance level
        ax.axhline(y=0.5, color='gray', linestyle='--', alpha=0.5, label='Chance')

        # Training day markers and highlighting
        if training_days is not None:
            for day in range(1, training_days):
                ax.axvline(x=day * epochs_per_day, color='gray', linestyle='-', alpha=0.3)

            # Highlight task training periods
            if task_idx == 0:
                ax.axvspan(0, n_epochs, color='gold', alpha=0.2)
            else:
                day = task_idx - 1
                start_epoch = day * epochs_per_day
                end_epoch = (day + 1) * epochs_per_day
                ax.axvspan(start_epoch, end_epoch, color='gold', alpha=0.2)

        # Only show legend on first subplot
        if task_idx == 0:
            ax.legend(loc='lower right', fontsize=9)

        # Axis formatting
        ax.set_title(f'{task_desc}\nover learning')
        ax.set_xlabel('Epochs')
        ax.set_ylabel('Decoding Score')
        ax.set_ylim(y_lim)
        ax.grid(True, alpha=0.3)

    # Adjust layout
    if fig_title:
        plt.tight_layout(rect=[0, 0, 1, 0.95])
    else:
        plt.tight_layout()

    # Optionally return figure object
    if return_fig:
        return fig
    plt.show()


def plot_decoding_time(scores_time, task_descriptions, figsize_multiplier=(6, 4),
                       y_lim=(0.4, 1.0), fig_title=None, return_fig=False):
    """
    Plot time-resolved decoding scores for multiple tasks.

    This function visualizes decoding performance at each time point across different 
    training stages (e.g., early, middle, late), for each task. Curves are plotted in 
    a blue gradient to indicate learning progression.

    Args:
        scores_time (np.ndarray): Shape (n_stages, n_timepoints, n_tasks), time-resolved scores.
        task_descriptions (dict): Mapping of task ID to descriptive label.
        figsize_multiplier (tuple): Width and height scaling factors.
        y_lim (tuple): y-axis limits for plots.
        fig_title (str): Optional title for the figure.
        return_fig (bool): If True, return the matplotlib figure object.
    """

    tasks = list(task_descriptions.keys())
    n_tasks = len(tasks)

    # Set up figure
    fig = plt.figure(figsize=(figsize_multiplier[0] * n_tasks, figsize_multiplier[1]))
    if fig_title:
        plt.suptitle(fig_title, y=0.95, fontsize=14)

    # Custom black-to-blue gradient for training stages
    blues = LinearSegmentedColormap.from_list('custom_blues', ['#000000', '#1F77B4'], N=256)

    # Set up 1-row grid for task subplots
    gs = fig.add_gridspec(1, n_tasks, wspace=0.3)

    for task_idx, task in enumerate(tasks):
        task_desc = task_descriptions[task]
        ax = fig.add_subplot(gs[0, task_idx])

        # Plot decoding curves for each training stage
        for stage_idx in range(scores_time.shape[0]):
            color = blues(stage_idx / (scores_time.shape[0] - 1))
            ax.plot(np.arange(scores_time.shape[1]), scores_time[stage_idx, :, task], color=color)

        # Reference line for chance level
        ax.axhline(y=0.5, color='gray', linestyle='--', alpha=0.5)

        # Formatting
        ax.set_title(f'{task_desc}\nTime-resolved Decoding')
        ax.set_xlabel('Time Points')
        ax.set_ylabel('Decoding Score')
        ax.set_ylim(y_lim)
        ax.grid(True, alpha=0.3)

        # Add colorbar for training stage gradient
        sm = plt.cm.ScalarMappable(cmap=blues)
        sm.set_array([])
        cbar = plt.colorbar(sm, ax=ax)
        cbar.set_label('Training Progress')

    # Adjust layout for tight fit
    if fig_title:
        plt.tight_layout(rect=[0, 0, 1, 0.95])
    else:
        plt.tight_layout()

    if return_fig:
        return fig


def plot_continual_validation_traces(results, task_sequence, task_descriptions, figsize=(24, 6)):

    val_accs_all = [seed['val_acc_per_epoch'] for seed in results['training_results']]
    val_losses_all = [seed['val_loss_per_epoch'] for seed in results['training_results']]

    task_ids = sorted(set(t for phase in task_sequence for t in phase))
    n_tasks = len(task_ids)
    n_phases = len(task_sequence)
    n_epochs = len(val_accs_all[0])

    acc_dict = {t: np.array([[e.get(t, np.nan) for e in seed] for seed in val_accs_all]) for t in task_ids}
    loss_dict = {t: np.array([[e.get(t, np.nan) for e in seed] for seed in val_losses_all]) for t in task_ids}

    fig = plt.figure(figsize=figsize)
    gs = gridspec.GridSpec(1, 3, width_ratios=[1.5, 1.5, 1])

    epochs = np.arange(n_epochs)

    # --- Validation Accuracy traces ---
    ax0 = fig.add_subplot(gs[0, 0])
    for t in task_ids:
        mean = np.nanmean(acc_dict[t], axis=0)
        sem = np.nanstd(acc_dict[t], axis=0) / np.sqrt(acc_dict[t].shape[0])
        ax0.plot(epochs, mean, label=task_descriptions.get(t, f'Task {t}'), linewidth=3)
        ax0.fill_between(epochs, mean - sem, mean + sem, alpha=0.2)
    # Add vertical lines and background shading for each phase
    phase_boundaries = [int((p + 1) * n_epochs / n_phases) for p in range(n_phases - 1)]
    colors = ["#4300fc", "#f77438", "#00fb00"]  # Light pastel colors for backgrounds
    for p in range(n_phases):
        start = int(p * n_epochs / n_phases) - 0.5
        end = int((p + 1) * n_epochs / n_phases) - 0.5
        ax0.axvspan(start, end, color=colors[p % len(colors)], alpha=0.05)
    for boundary in phase_boundaries:
        ax0.axvline(boundary, color='gray', linestyle='--', alpha=0.5)
    ax0.set_xlabel("Epochs")
    ax0.set_ylabel("Validation Accuracy")
    ax0.set_title("Validation Accuracy Across Epochs")
    ax0.grid(True, alpha=0.3)
    # ax0.legend(loc='upper right', fontsize=9)  # Remove legend here

    # --- Validation Loss traces ---
    ax1 = fig.add_subplot(gs[0, 1])
    for t in task_ids:
        mean = np.nanmean(loss_dict[t], axis=0)
        sem = np.nanstd(loss_dict[t], axis=0) / np.sqrt(loss_dict[t].shape[0])
        ax1.plot(epochs, mean, label=task_descriptions.get(t, f'Task {t}'), linewidth=3)
        ax1.fill_between(epochs, mean - sem, mean + sem, alpha=0.2)
    # Add vertical lines and background shading for each phase (same as ax0)
    for p in range(n_phases):
        start = int(p * n_epochs / n_phases) - 0.5
        end = int((p + 1) * n_epochs / n_phases) - 0.5
        ax1.axvspan(start, end, color=colors[p % len(colors)], alpha=0.1)
    for boundary in phase_boundaries:
        ax1.axvline(boundary, color='gray', linestyle='--', alpha=0.1)
    ax1.set_xlabel("Epochs")
    ax1.set_ylabel("Validation Loss")
    ax1.set_title("Validation Loss Across Epochs")
    ax1.grid(True, alpha=0.3)
    # ax1.legend(loc='upper right', fontsize=9)  # Remove legend here

    # --- Bar chart of final validation accuracy after each phase with SEM error bars ---
    ax2 = fig.add_subplot(gs[0, 2])
    width = 0.15
    for i, t in enumerate(task_ids):
        bar_means = []
        bar_sems = []
        for p in range(n_phases):
            epoch_idx = int((p + 1) * n_epochs / n_phases) - 1
            vals = acc_dict[t][:, epoch_idx]
            mean_val = np.nanmean(vals)
            sem_val = np.nanstd(vals) / np.sqrt(len(vals))
            bar_means.append(mean_val)
            bar_sems.append(sem_val)
        x = np.arange(n_phases) + i * width - (width * n_tasks / 2)
        ax2.bar(x, bar_means, width, yerr=bar_sems, capsize=4,
                label=task_descriptions.get(t, f'Task {t}'))
    # Background shaded regions for each phase, matching the trace plots
    for p in range(n_phases):
        start = p - 0.5
        end = p + 0.5
        ax2.axvspan(start, end, color=colors[p % len(colors)], alpha=0.05)
    ax2.set_xticks(np.arange(n_phases))
    ax2.set_xticklabels([f'Phase {i+1}' for i in range(n_phases)])
    ax2.set_ylabel("Final Accuracy")
    ax2.set_title("Validation Accuracy After Each Phase")
    ax2.grid(True, alpha=0.3)
    # ax2.legend(loc='upper right', fontsize=9)  # Remove legend here

    plt.suptitle("Continual Learning Validation Traces", fontsize=16)
    # Create a single legend for all plots
    handles, labels = ax0.get_legend_handles_labels()
    fig.legend(handles, labels, loc='upper right', ncol=len(task_ids), fontsize=10)
    plt.tight_layout()


def plot_forgetting_matrix(forgetting, task_ids, task_descriptions=None, cmap="RdBu_r", figsize=(10, 6)):
    """
    Plot the forgetting matrix as a heatmap with annotations.

    Args:
        forgetting (np.ndarray): Matrix of forgetting values (n_tasks, n_phases).
        task_ids (list): List of task IDs in the order of matrix rows.
        task_descriptions (dict, optional): Mapping from task ID to descriptive label.
        cmap (str): Colormap for the heatmap.
        figsize (tuple): Size of the plot.
    """

    n_tasks, n_phases = forgetting.shape

    # Prepare row labels using task descriptions if available
    if task_descriptions is not None:
        row_labels = [task_descriptions.get(t, f'Task {t}') for t in task_ids]
    else:
        row_labels = [f'Task {t}' for t in task_ids]

    # Phase labels for columns
    col_labels = [f'Phase {p}' for p in range(n_phases)]

    plt.figure(figsize=figsize)
    ax = sns.heatmap(-1*forgetting, annot=True, fmt=".2f", cmap=cmap,
                     xticklabels=col_labels, yticklabels=row_labels,
                     linewidths=0.5, linecolor='gray', center=0, cbar_kws={'label': 'Forgetting (Δ Accuracy)'})
    ax.set_title("Forgetting Matrix")
    ax.set_xlabel("Training Phase")
    ax.set_ylabel("Task")
    plt.tight_layout()
    plt.show()


def plot_transfer_onset_latencies(latencies, task_descriptions=None, color_map=None, threshold=100):
    """
    Plot a bar chart of transfer onset latencies per task.

    Args:
        latencies (dict): Mapping from task ID to latency (in epochs).
        task_descriptions (dict, optional): Mapping from task ID to string label.
        color_map (dict, optional): Mapping from task ID to bar color.
    """
    task_ids = sorted(latencies.keys())
    values = [latencies[t][0] for t in task_ids]
    sems = [latencies[t][1] for t in task_ids]


    # Use string labels if provided
    if task_descriptions:
        labels = [f"Phase {i+1}:\n{task_descriptions.get(t, str(t))}" for i, t in enumerate(task_ids)]
    else:
        labels = [f"Phase {i+1}:\n{str(t)}" for i, t in enumerate(task_ids)]

    # Bar colors
    if color_map:
        colors = [color_map.get(t, 'gray') for t in task_ids]
    else:
        colors = ["#4300fc", "#f77438", "#00fb00"]

    plt.figure(figsize=(8, 4))
    # Plot bar chart of mean trials required for each task to reach 90% validation accuracy
    bars = plt.bar(labels, values, yerr=sems, capsize=5, color=colors)
    plt.xlabel("Task")
    plt.ylabel(f"Sessions to {threshold}% Accuracy")
    plt.title("Task Switching Onset Latencies")
    plt.tight_layout()
    plt.show()

    
def plot_orthogonality_loss(results_list, figsize=(8, 4)):
    """
    Plot LoRA orthogonality loss over training epochs.

    This function visualizes the orthogonality regularization loss
    across training epochs, averaged over multiple seeds if provided.

    Args:
        results_list (list or dict): One or more training result dicts from model runs.
        figsize (tuple): Size of the matplotlib figure.
    """
    if not isinstance(results_list, list):
        results_list = [results_list]

    # Collect orthogonality losses from all runs
    orth_losses_all = [r['orthogonality_losses'] for r in results_list]
    n_epochs = len(orth_losses_all[0])
    epochs = np.arange(n_epochs)

    # Compute mean and SEM across seeds
    orth_losses_array = np.array(orth_losses_all)
    mean_orth = np.mean(orth_losses_array, axis=0)
    sem_orth = np.std(orth_losses_array, axis=0) / np.sqrt(len(orth_losses_array))

    # Plot
    plt.figure(figsize=figsize)
    plt.plot(epochs, mean_orth, color='purple', label='Mean Orthogonality Loss')
    plt.fill_between(epochs, mean_orth - sem_orth, mean_orth + sem_orth, color='purple', alpha=0.2)
    plt.xlabel('Epoch')
    plt.ylabel('Orthogonality Loss')
    plt.title('LoRA Orthogonality Loss Over Training')
    plt.grid(True, alpha=0.3)
    plt.legend()
    plt.tight_layout()
    plt.show()