"""
analysis/utils.py

Analysis utilities for extracting activations and evaluating model performance.

This module provides helper functions used during analysis of trained models, including:
- Extracting hidden state activations across models
- Computing task-specific accuracies
- Plotting or debugging task-specific performance

These tools are used by higher-level decoding or representational similarity analysis functions.
"""

import torch
import numpy as np
from typing import List, Tuple, Optional


def debug_task_accuracies(results: dict) -> None:
    """
    Debug function to examine task accuracies in training results.

    Args:
        results (dict): Dictionary of training results, expected to contain
                        'train_accuracies_per_task' as a key.
    """
    print("\n===== DEBUG TASK ACCURACIES =====")
    if 'train_accuracies_per_task' not in results:
        print("ERROR: 'train_accuracies_per_task' NOT FOUND in results!")
        return

    accs = results['train_accuracies_per_task']
    if isinstance(accs, list):
        print(f"Format: LIST with {len(accs)} tasks")
        for i, task_accs in enumerate(accs):
            print(f"Task {i}: {len(task_accs)} values")
            if len(task_accs) > 0:
                print(f"  Sample values: {task_accs[:5]}")
                print(f"  Mean: {np.mean(task_accs):.4f}")
                print(f"  Contains NaN: {np.isnan(np.array(task_accs)).any()}")
            else:
                print("  EMPTY ARRAY - NO DATA")
    elif isinstance(accs, dict):
        print(f"Format: DICT with {len(accs)} tasks")
        for task_id, task_accs in accs.items():
            print(f"Task {task_id}: {len(task_accs)} values")
            if len(task_accs) > 0:
                print(f"  Sample values: {task_accs[:5]}")
                print(f"  Mean: {np.mean(task_accs):.4f}")
                print(f"  Contains NaN: {np.isnan(np.array(task_accs)).any()}")
            else:
                print("  EMPTY ARRAY - NO DATA")
    else:
        print(f"Unknown format: {type(accs)}")
    print("==================================\n")

def concatenate_training_results(results_list, task_list):
    """
    Concatenate training results with proper handling of task training periods.

    Args:
        results_list: List of dictionaries containing training results from each day
        task_list: List of task pairs for each day, e.g. [[27, 14], [0, 14], [9, 14]]

    Returns:
        dict: Combined results with concatenated metrics and task-specific accuracies
    """
    # Debug individual training results before combining
    print("Debugging each result before concatenation:")
    for i, res in enumerate(results_list):
        print(f"\nResult {i+1}:")
        debug_task_accuracies(res)

    # Initialize structure for combined results
    combined_results = {
        'initial_weights': results_list[0]['initial_weights'],
        'final_weights': results_list[-1]['final_weights'],
        'train_losses': [],
        'train_accuracies': [],
        'train_accuracies_per_task': {},
        'firing_rates': [],
        'gradient_history': {k: [] for k in results_list[0]['gradient_history'].keys()},
        'weight_changes': {k: [] for k in results_list[0]['weight_changes'].keys()}
    }

    # Gather all unique task IDs seen across all days
    all_tasks = set([t for day in task_list for t in day])
    print(f"All unique tasks: {all_tasks}")

    # Ensure all result entries contain task accuracy data
    for i, res in enumerate(results_list):
        if 'train_accuracies_per_task' not in res:
            print(f"Warning: Missing train_accuracies_per_task in results_list[{i}]")
            res['train_accuracies_per_task'] = [[] for _ in range(len(task_list[i]))]

    # Compute size of time axis across days
    epochs_per_day = len(results_list[0]['train_accuracies'])
    total_epochs = epochs_per_day * len(results_list)
    print(f"Epochs per day: {epochs_per_day}, Total epochs: {total_epochs}")

    # Initialize a time-aligned vector for each unique task
    for task in all_tasks:
        combined_results['train_accuracies_per_task'][task] = np.zeros(total_epochs)

    # Loop over each day's results and insert data into combined arrays
    for day_idx, (day_results, day_tasks) in enumerate(zip(results_list, task_list)):
        start_idx = day_idx * epochs_per_day
        end_idx = start_idx + epochs_per_day
        print(f"\nProcessing day {day_idx+1} with tasks {day_tasks}")

        # Append scalar metrics
        combined_results['train_losses'].extend(day_results['train_losses'])
        combined_results['train_accuracies'].extend(day_results['train_accuracies'])
        combined_results['firing_rates'].extend(day_results['firing_rates'])

        # Insert per-task accuracy values
        for task_idx, task_id in enumerate(day_tasks):
            print(f"  - Processing task {task_id} (idx {task_idx})")
            if isinstance(day_results['train_accuracies_per_task'], list):
                if task_idx < len(day_results['train_accuracies_per_task']):
                    task_accs = day_results['train_accuracies_per_task'][task_idx]
                    print(f"    Found task data in list format, {len(task_accs)} values")
                else:
                    print(f"    Task index {task_idx} out of range")
                    task_accs = []
            elif isinstance(day_results['train_accuracies_per_task'], dict):
                if task_id in day_results['train_accuracies_per_task']:
                    task_accs = day_results['train_accuracies_per_task'][task_id]
                    print(f"    Found task data in dict format, {len(task_accs)} values")
                else:
                    print(f"    Task ID {task_id} not found in dict keys")
                    task_accs = []
            else:
                print(f"    Unknown format for train_accuracies_per_task")
                task_accs = []

            # Copy over accuracy values, avoiding NaNs
            if len(task_accs) > 0:
                length_to_fill = min(len(task_accs), end_idx - start_idx)
                print(f"    Filling slots {start_idx} to {start_idx+length_to_fill} with task accuracy data")
                task_accs_array = np.array(task_accs[:length_to_fill])
                task_accs_array = np.nan_to_num(task_accs_array, nan=0.0)
                combined_results['train_accuracies_per_task'][task_id][start_idx:start_idx+length_to_fill] = task_accs_array
            else:
                print(f"    No data for task {task_id}, leaving as zeros")

        # Append layer-wise history
        for layer_name in day_results['gradient_history']:
            combined_results['gradient_history'][layer_name].extend(day_results['gradient_history'][layer_name])
            combined_results['weight_changes'][layer_name].extend(day_results['weight_changes'][layer_name])

    # Convert lists to arrays for convenience
    combined_results['train_losses'] = np.array(combined_results['train_losses'])
    combined_results['train_accuracies'] = np.array(combined_results['train_accuracies'])
    combined_results['firing_rates'] = np.array(combined_results['firing_rates'])

    for layer_name in combined_results['gradient_history']:
        combined_results['gradient_history'][layer_name] = np.array(combined_results['gradient_history'][layer_name])
        combined_results['weight_changes'][layer_name] = np.array(combined_results['weight_changes'][layer_name])

    return combined_results


def get_models_activations(
    models: List[torch.nn.Module],
    X: torch.Tensor,
    y: torch.Tensor,
    mask: torch.Tensor,
) -> Tuple[np.ndarray, List[float]]:
    """
    Extract hidden activations and accuracies from a list of trained models.

    For each model in the provided list, this function runs the model on the
    input data and retrieves its hidden state activations as well as overall
    accuracy. It returns a stacked array of activations and a list of accuracy
    values, useful for analyzing learning dynamics over epochs.

    Args:
        models (List[torch.nn.Module]): List of trained ExperimentNetwork models.
        X (torch.Tensor): Input tensor of shape (n_trials, timesteps, input_dim).
        y (torch.Tensor): Target tensor of shape (n_trials, timesteps, output_dim).
        mask (torch.Tensor): Boolean mask tensor indicating which outputs to score.

    Returns:
        Tuple:
            - np.ndarray of shape (n_models, n_trials, n_units, n_timesteps): Hidden activations.
            - List[float]: Accuracy scores for each model.
    """
    n_models = len(models)
    n_trials = X.shape[0]

    # Use first model to infer hidden size and sequence length
    first_activations, _ = models[0].get_activations(X, y, mask)
    n_units = first_activations.shape[1]
    n_timesteps = first_activations.shape[2]

    # Allocate storage for all activations and accuracies
    all_activations = np.zeros((n_models, n_trials, n_units, n_timesteps))
    all_accuracies = []

    print(f"Extracting activations for {n_models} models...")

    # Loop through each model and evaluate
    for idx, model in enumerate(models):
        activations, accuracy = model.get_activations(X, y, mask)
        all_activations[idx] = activations
        all_accuracies.append(accuracy)

        print(f"Model {idx + 1}/{n_models} processed - Accuracy: {accuracy:.3f}")

    print(f"Finished extraction. Final shape: {all_activations.shape}")
    print(f"Average accuracy: {np.mean(all_accuracies):.3f} ± {np.std(all_accuracies):.3f}")

    return all_activations, all_accuracies

def identify_trial_types(X: torch.Tensor, t_min: int = -500, dt: int = 20) -> np.ndarray:
    """
    Identify discrete trial types from the input tensor by detecting input patterns
    in a specific time window (500–1000 ms). Assumes the first 3 input channels
    encode task-defining features (e.g., color, shape, width).

    Args:
        X (torch.Tensor): Input tensor of shape (n_trials, n_timesteps, n_inputs)
        t_min (int): Start time of simulation in ms (default: -500)
        dt (int): Time step in ms (default: 20)

    Returns:
        np.ndarray: Integer array of shape (n_trials,) with trial type codes (0–7)
    """
    # Compute index range corresponding to the 500–1000ms window
    start_idx = int((500 - t_min) / dt)
    end_idx = int((1000 - t_min) / dt)

    # Average over time within this window for first 3 input dimensions
    avg_inputs = X[:, start_idx:end_idx, :3].mean(dim=1)

    # Round and sign the inputs to obtain binary (-1 or 1) patterns
    rounded = torch.round(avg_inputs * 2) / 2
    rounded = torch.sign(rounded)

    # Define pattern-to-type mapping
    pattern_to_type = {
        (-1, -1, -1): 0,
        (-1, -1, 1): 1,
        (-1, 1, -1): 2,
        (-1, 1, 1): 3,
        (1, -1, -1): 4,
        (1, -1, 1): 5,
        (1, 1, -1): 6,
        (1, 1, 1): 7
    }

    # Convert rounded patterns to numpy and look up trial types
    patterns = rounded.cpu().numpy()
    trial_types = np.zeros(len(patterns), dtype=np.int32)
    for i, pattern in enumerate(patterns):
        pattern_tuple = tuple(pattern)
        trial_types[i] = pattern_to_type[pattern_tuple]

    return trial_types

def get_percentile_indices(arr):
    n = arr.shape[0]
    indices = [
        0,                  # First
        int(n * 0.25),     # 25th percentile
        int(n * 0.50),     # 50th percentile
        int(n * 0.75),     # 75th percentile
        n - 1              # Last
    ]
    return indices

def combine_phase_results(results_phase1, results_phase2):
    """
    Combine training results and metrics from two separate experimental phases.

    Args:
        results_phase1 (dict): Results dictionary from phase 1
        results_phase2 (dict): Results dictionary from phase 2

    Returns:
        dict: Combined results with per-variant metrics, phase boundaries,
              and decoding scores (if present)
    """
    combined_results = {}

    # Determine variants shared across both phases
    common_variants = set(results_phase1.keys()).intersection(set(results_phase2.keys()))

    for variant_name in common_variants:
        print(f"Combining results for variant: {variant_name}")

        # Prepare container for this variant
        combined_results[variant_name] = {
            'training_results': [],
            'decoding_scores': [],
            'xgen_decoding_scores': [],
            'phase_boundaries': []  # index for transition between phase1 and phase2
        }

        # Ensure equal number of seeds or fallback to min
        n_seeds_p1 = len(results_phase1[variant_name]['training_results'])
        n_seeds_p2 = len(results_phase2[variant_name]['training_results'])
        n_seeds = min(n_seeds_p1, n_seeds_p2)

        if n_seeds_p1 != n_seeds_p2:
            print(f"Warning: Mismatched seeds (P1: {n_seeds_p1}, P2: {n_seeds_p2}) for {variant_name}")

        # Combine each seed individually
        for seed_idx in range(n_seeds):
            p1 = results_phase1[variant_name]['training_results'][seed_idx]
            p2 = results_phase2[variant_name]['training_results'][seed_idx]

            combined_tr = {}

            # Combine scalar metrics
            for key in ['train_losses', 'train_accuracies', 'firing_rates']:
                if key in p1 and key in p2:
                    combined_tr[key] = np.concatenate([p1[key], p2[key]])
                elif key in p1:
                    combined_tr[key] = p1[key]
                elif key in p2:
                    combined_tr[key] = p2[key]

            # Mark where phase transition occurs
            combined_results[variant_name]['phase_boundaries'].append(len(p1['train_losses']))

            # Combine layer-wise histories
            for key in ['gradient_history', 'weight_changes']:
                if key in p1 and key in p2:
                    combined_tr[key] = {}
                    common_layers = set(p1[key]).intersection(p2[key])
                    for layer in common_layers:
                        combined_tr[key][layer] = np.concatenate([p1[key][layer], p2[key][layer]])

            # Combine task accuracy formats (list or dict)
            if 'train_accuracies_per_task' in p1 and 'train_accuracies_per_task' in p2:
                if isinstance(p1['train_accuracies_per_task'], list) and isinstance(p2['train_accuracies_per_task'], list):
                    combined_tr['train_accuracies_per_task'] = [
                        np.concatenate([p1['train_accuracies_per_task'][i], p2['train_accuracies_per_task'][i]])
                        for i in range(min(len(p1['train_accuracies_per_task']), len(p2['train_accuracies_per_task'])))
                    ]
                elif isinstance(p1['train_accuracies_per_task'], dict) and isinstance(p2['train_accuracies_per_task'], dict):
                    combined_tr['train_accuracies_per_task'] = {
                        task: np.concatenate([p1['train_accuracies_per_task'][task], p2['train_accuracies_per_task'][task]])
                        for task in set(p1['train_accuracies_per_task']).intersection(p2['train_accuracies_per_task'])
                    }
                else:
                    print(f"Warning: Mismatched accuracy formats for {variant_name}, seed {seed_idx}")

            # Combine validation accuracies and losses per epoch
            if 'val_acc_per_epoch' in p1 and 'val_acc_per_epoch' in p2:
                combined_tr['val_acc_per_epoch'] = p1['val_acc_per_epoch'] + p2['val_acc_per_epoch']
            if 'val_loss_per_epoch' in p1 and 'val_loss_per_epoch' in p2:
                combined_tr['val_loss_per_epoch'] = p1['val_loss_per_epoch'] + p2['val_loss_per_epoch']

            # Preserve initial/final weights
            combined_tr['initial_weights'] = p1['initial_weights']
            combined_tr['final_weights'] = p2['final_weights']

            combined_results[variant_name]['training_results'].append(combined_tr)

            # Combine decoding scores if available
            try:
                if 'decoding_scores' in results_phase1[variant_name] and 'decoding_scores' in results_phase2[variant_name]:
                    combined_results[variant_name]['decoding_scores'].append(
                        np.concatenate([
                            results_phase1[variant_name]['decoding_scores'][seed_idx],
                            results_phase2[variant_name]['decoding_scores'][seed_idx]
                        ])
                    )
                if 'xgen_decoding_scores' in results_phase1[variant_name] and 'xgen_decoding_scores' in results_phase2[variant_name]:
                    combined_results[variant_name]['xgen_decoding_scores'].append(
                        np.concatenate([
                            results_phase1[variant_name]['xgen_decoding_scores'][seed_idx],
                            results_phase2[variant_name]['xgen_decoding_scores'][seed_idx]
                        ])
                    )
            except Exception as e:
                print(f"Warning: Failed to combine decoding scores for {variant_name}, seed {seed_idx}: {e}")

    return combined_results

def combine_multiple_phase_results(results_list):
    combined = results_list[0]
    for r in results_list[1:]:
        combined = combine_phase_results(combined, r)
    return combined
