"""
representations.py
Representation analysis utilities for decoding and geometry-based evaluation.

This module includes tools to:
- Equalize trials across trial types for decoding fairness
- Perform SVM/LDA-based decoding
- Compute shattering combinations and cross-generalization
- Analyze decoding accuracy across time and training epochs
"""

import itertools
import random
import numpy as np
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as LDA
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import LinearSVC as SVM
from tqdm import tqdm
from collections import Counter

def equalize_trials(activations, trial_types, random_state=None):
    """
    Equalizes trial counts across trial types by downsampling to the size of the smallest group.

    This is useful for decoding tasks where class balance is required.
    For each unique trial type, randomly sample 'min_trials' trials (the number of trials
    in the smallest group). This ensures each class contributes equally.

    Args:
        activations (np.ndarray): Neural activations of shape (n_epochs, n_trials, n_timepoints, n_features)
        trial_types (np.ndarray): Integer labels of shape (n_trials,) indicating trial type
        random_state (int, optional): Seed for reproducible sampling

    Returns:
        Tuple[np.ndarray, np.ndarray, dict]:
            - Balanced activations: (n_epochs, n_trials_balanced, n_timepoints, n_features)
            - Balanced trial types: (n_trials_balanced,)
            - Summary of original and final trial counts
    """
    # Set RNG seed if provided for reproducibility
    if random_state is not None:
        np.random.seed(random_state)

    # Count trials per type
    type_counts = Counter(trial_types)
    # Find the minimum number of trials across types
    min_trials = min(type_counts.values())
    original_counts = dict(type_counts)

    # Initialize lists to store balanced outputs
    balanced_activations = []
    balanced_trial_types = []

    # Loop over each trial type and sample trials
    for trial_type in np.unique(trial_types):
        # Get all indices of current trial type
        type_indices = np.where(trial_types == trial_type)[0]

        # Downsample if necessary
        if len(type_indices) > min_trials:
            selected_indices = np.random.choice(type_indices, size=min_trials, replace=False)
        else:
            selected_indices = type_indices

        # Append sampled trials
        balanced_activations.append(activations[:, selected_indices, :, :])
        balanced_trial_types.extend([trial_type] * len(selected_indices))

    # Combine all balanced trials into one array
    balanced_activations = np.concatenate(balanced_activations, axis=1)
    balanced_trial_types = np.array(balanced_trial_types)

    # Build summary of trial count changes
    final_counts = Counter(balanced_trial_types)
    summary = {
        'original_counts': original_counts,
        'final_counts': dict(final_counts)
    }

    return balanced_activations, balanced_trial_types, summary

def assign_labels(labels, factor):
    """
    Assign group labels based on condition values.

    Useful for assigning superordinate labels (e.g., color or shape group) based on fine-grained trial types.

    Args:
        labels (list or array-like): Condition labels (e.g. [0, 1, 2])
        factor (list or array-like): Mapping to assign to each label (must be same length as unique(labels))

    Returns:
        list: New labels assigned according to factor map
    """
    conditions = np.unique(labels)
    mapping = dict(zip(conditions, factor))
    return list(map(mapping.get, labels))

def decode(X, y, method='svm', n_inter=1, return_inter=False, n_jobs=None):
    """
    Perform decoding using SVM or LDA with optional repeated cross-validation.

    Splits the data into two halves, trains on one and tests on the other,
    and repeats this process n_inter times for robustness.

    Args:
        X (np.ndarray): Input data of shape (n_trials, ...) — can be (n_trials, n_features) or (n_trials, n_timepoints, n_features)
        y (np.ndarray): Labels of shape (n_trials,)
        method (str): Decoding method — 'svm' or 'lda'
        n_inter (int): Number of repeated cross-validation iterations
        return_inter (bool): If True, return list of individual scores; else return mean
        n_jobs (int or None): If not None, assumes time-series format and uses multi-time decoding

    Returns:
        float or list of float: Decoding accuracy (mean or per iteration)
    """
    y = np.array(y)
    scores_all = []

    for n in range(n_inter):
        # Choose classifier and pipeline
        if method == 'svm':
            clf1 = make_pipeline(StandardScaler(), SVM(C=5e-4, dual=False))
            clf2 = make_pipeline(StandardScaler(), SVM(C=5e-4, dual=False))
        elif method == 'lda':
            clf1 = make_pipeline(StandardScaler(), LDA())
            clf2 = make_pipeline(StandardScaler(), LDA())
        else:
            raise ValueError(f"Unsupported method: {method}")

        # Create a shuffled index array to split trials
        n_trls = X.shape[0]
        idx_rnd = np.concatenate([np.zeros(n_trls // 2), np.ones(n_trls // 2)])
        if (n_trls % 2) > 0:
            idx_rnd = np.concatenate([idx_rnd, [1.0]])
        random.shuffle(idx_rnd)

        # Split into train/test sets
        if n_jobs is not None:  # Assume time-series decoding (multi-timepoint)
            X1 = X[idx_rnd < 1, :, :]
            y1 = y[idx_rnd < 1]
            X2 = X[idx_rnd > 0, :, :]
            y2 = y[idx_rnd > 0]
        else:  # Assume flattened or single-timepoint input
            X1 = X[idx_rnd < 1, :]
            y1 = y[idx_rnd < 1]
            X2 = X[idx_rnd > 0, :]
            y2 = y[idx_rnd > 0]

        # Train/test split 1
        clf1.fit(X1, y1)
        score1 = clf1.score(X2, y2)

        # Train/test split 2 (swap roles)
        clf2.fit(X2, y2)
        score2 = clf2.score(X1, y1)

        # Average score for this iteration
        scores_all.append(np.mean([score1, score2]))

    return scores_all if return_inter else np.mean(scores_all)

def get_shattering_ids(
    cue=np.array([0, 0, 0, 0, 1, 1, 1, 1]),
    target=np.array([0, 0, 1, 1, 0, 0, 1, 1]),
    width=np.array([0, 1, 0, 1, 0, 1, 0, 1]),
    reward=np.array([1, 1, 0, 0, 0, 0, 1, 1])
):
    """
    Generate all balanced binary labelings (shatterings) over 8 trial types
    and identify those that match key task dimensions (cue, target, width, reward).

    This also prepares disjoint train/test splits for cross-generalization decoding.

    Args:
        cue, target, width, reward (np.ndarray): Binary label vectors (length 8) specifying 
            known trial groupings (e.g., cue A/B, reward vs no reward)

    Returns:
        decoding_targets (np.ndarray): All possible balanced binary splits of 8 trials (35 x 8)
        cue_tgt_width_reward_ids (np.ndarray): Index of each known rule in the shattering list
        cross_gen_decoding_train_ids (list): Disjoint train trial indices for each shattering
        cross_gen_decoding_test_ids (list): Corresponding disjoint test trial indices
    """
    n_condi = len(cue)  # Should be 8 for all 2x2x2 trial combinations

    # Generate all balanced 4-vs-4 groupings out of 8 trials
    all_combos = list(itertools.combinations(range(n_condi), n_condi // 2))
    n_combos = len(all_combos) // 2  # Only take half to avoid duplicates

    decoding_targets = np.zeros((n_combos, n_condi))  # Stores each binary split
    cue_tgt_width_reward_ids = np.zeros(4)  # Indices of the known rule-based splits

    # Populate decoding_targets and find which ones match known task rules
    for i in range(n_combos):
        decoding_targets[i, list(all_combos[i])] = 1

        if np.allclose(decoding_targets[i], cue) or np.allclose(decoding_targets[i], 1 - cue):
            cue_tgt_width_reward_ids[0] = i
        if np.allclose(decoding_targets[i], target) or np.allclose(decoding_targets[i], 1 - target):
            cue_tgt_width_reward_ids[1] = i
        if np.allclose(decoding_targets[i], width) or np.allclose(decoding_targets[i], 1 - width):
            cue_tgt_width_reward_ids[2] = i
        if np.allclose(decoding_targets[i], reward) or np.allclose(decoding_targets[i], 1 - reward):
            cue_tgt_width_reward_ids[3] = i

    # Create train/test subsets for cross-generalization decoding
    cross_gen_decoding_train_ids = []
    cross_gen_decoding_test_ids = []

    for i in range(n_combos):
        zeros = np.where(decoding_targets[i] == 0)[0]
        ones = np.where(decoding_targets[i] == 1)[0]
        combs_zeros = list(itertools.combinations(zeros, 2))
        combs_ones = list(itertools.combinations(ones, 2))

        current_train = []
        current_test = []

        for cz in combs_zeros:
            for co in combs_ones:
                current_train.append([cz, co])
                test_zeros = list(set(zeros) - set(cz))
                test_ones = list(set(ones) - set(co))
                current_test.append([test_zeros, test_ones])

        cross_gen_decoding_train_ids.append(current_train)
        cross_gen_decoding_test_ids.append(current_test)

    return decoding_targets, cue_tgt_width_reward_ids, cross_gen_decoding_train_ids, cross_gen_decoding_test_ids

def get_decoding(X, labels):
    """
    Compute decoding accuracy for all possible binary shatterings of trial types.

    For each of the 35 possible 4-vs-4 binary labelings (shatterings) of the 8 trial types,
    assign the appropriate labels and evaluate decoding performance using a classifier.

    Args:
        X (np.ndarray): Neural activation data of shape (n_trials, ...) 
        labels (np.ndarray): Integer labels indicating trial type (length 8)

    Returns:
        np.ndarray: Decoding accuracy scores for each shattering (length 35)
    """
    decoding_targets, _, _, _ = get_shattering_ids()
    n_combos = decoding_targets.shape[0]
    scores = []

    for combo in range(n_combos):
        # Create binary labels for this shattering
        y = assign_labels(labels, decoding_targets[combo, :])
        # Compute decoding accuracy for this split
        scores.append(decode(X, y))

    return np.array(scores)

def decode_xgen(X1, X2, y1, y2, method='svm'):
    """
    Perform cross-generalization decoding between two datasets.

    Trains a classifier on one dataset and tests on the other,
    then repeats in the opposite direction and averages the scores.

    This is useful for evaluating whether the learned representation generalizes
    across different task contexts or stimulus conditions.

    Args:
        X1 (np.ndarray): Training data for first context (n_trials, n_features)
        X2 (np.ndarray): Test data for second context (n_trials, n_features)
        y1 (np.ndarray): Labels for X1
        y2 (np.ndarray): Labels for X2
        method (str): Decoding method — 'svm' or 'lda'

    Returns:
        float: Average cross-generalization decoding accuracy
    """
    # Select classifier pipeline
    if method == 'svm':
        clf1 = make_pipeline(StandardScaler(), SVM(C=5e-4))
        clf2 = make_pipeline(StandardScaler(), SVM(C=5e-4))
    elif method == 'lda':
        clf1 = make_pipeline(StandardScaler(), LDA())
        clf2 = make_pipeline(StandardScaler(), LDA())
    else:
        raise ValueError(f"Unsupported method: {method}")

    # Train on X1, test on X2
    clf1.fit(X1, y1)
    score1 = clf1.score(X2, y2)

    # Train on X2, test on X1
    clf2.fit(X2, y2)
    score2 = clf2.score(X1, y1)

    # Return average accuracy
    return np.mean([score1, score2])

def get_xgen(X, labels, variables=None, mode='full'):
    """
    Compute cross-generalization decoding accuracy across all shatterings or a subset.

    This function evaluates whether neural representations generalize across distinct
    subsets of trial types. For each shattering (i.e. balanced binary partition of 8 conditions),
    it trains a decoder on one half and tests it on the complementary half. Results are averaged
    across multiple train/test splits.

    Args:
        X (np.ndarray): Neural data of shape (n_trials, n_features)
        labels (np.ndarray): Trial type labels (ints from 0 to 7), shape (n_trials,)
        variables (list[np.ndarray], optional): Predefined condition groupings (e.g., cue, target)
        mode (str): If 'only_rel', test only cue/target/width/reward; if 'full', test all 35 shatterings

    Returns:
        np.ndarray: Cross-generalization decoding scores (length depends on mode)
    """
    # Default condition groupings: cue, target, width, reward
    if variables is None:
        variables = [
            np.array([0, 0, 0, 0, 1, 1, 1, 1]),  # Cue
            np.array([0, 0, 1, 1, 0, 0, 1, 1]),  # Target
            np.array([0, 1, 0, 1, 0, 1, 0, 1]),  # Width
            np.array([1, 1, 0, 0, 0, 0, 1, 1])   # Reward
        ]

    # Compute shattering combinations and train/test splits
    decoding_targets, cue_tgt_width_reward_ids, train_ids, test_ids = get_shattering_ids(
        variables[0], variables[1], variables[2], variables[3]
    )

    # Convert relevant rule indices to integer list (for indexing)
    var_ids = [int(i) for i in cue_tgt_width_reward_ids]
    n_combos = len(train_ids)

    # Choose which shatterings to evaluate
    combo_list = var_ids if mode == 'only_rel' else list(range(n_combos))

    scores = []
    for combo in combo_list:
        # Get train and test trial indices for this shattering
        xgen_train = train_ids[combo]
        xgen_test = test_ids[combo]

        scores_axes = []
        for axis in range(len(xgen_train)):
            # Get trial indices for current train set (flatten pairs of indices)
            y1 = np.array(xgen_train[axis]).flatten()
            # Collect all matching trial data
            X1 = np.concatenate([X[labels == idx] for idx in y1], axis=0)

            # Same for test trials
            y2 = np.array(xgen_test[axis]).flatten()
            X2 = np.concatenate([X[labels == idx] for idx in y2], axis=0)

            # Assign binary labels for classifier training
            y1_labels = np.concatenate([np.zeros(X1.shape[0] // 2), np.ones(X1.shape[0] // 2)])
            y2_labels = np.concatenate([np.zeros(X2.shape[0] // 2), np.ones(X2.shape[0] // 2)])

            # Compute cross-generalization decoding accuracy
            score = decode_xgen(X1, X2, y1_labels, y2_labels)
            scores_axes.append(score)

        # Average across train/test axes
        scores.append(np.mean(scores_axes))

    return np.array(scores)

def decode_across_time(activations, trial_types):
    """
    Compute decoding and cross-generalization accuracy across all timepoints for a given epoch.

    This function analyzes the evolution of representational structure over time by
    decoding trial identity and assessing generalization ability at each time step.

    Args:
        activations (np.ndarray): Neural activations of shape 
            (n_trials, n_timepoints, n_neurons) for a single epoch.
        trial_types (np.ndarray): Trial type labels of shape (n_trials,)

    Returns:
        Tuple[np.ndarray, np.ndarray]:
            - scores_dec: Decoding accuracies across time (n_timepoints, n_patterns)
            - scores_xgen: Cross-generalization accuracies (n_timepoints, n_patterns)
    """
    n_timepoints = activations.shape[1]

    # Store decoding results for each timepoint
    dec_scores_all = []
    xgen_scores_all = []

    # Iterate through each timepoint to evaluate decoding performance
    for t in range(n_timepoints):
        # Slice activation data at this timepoint (n_trials, n_neurons)
        current_activations = activations[:, t, :]

        # Compute decoding accuracy for each shattering
        timepoint_dec_scores = get_decoding(current_activations, trial_types)

        # Compute cross-generalization accuracy for each shattering
        timepoint_xgen_scores = get_xgen(current_activations, trial_types)

        dec_scores_all.append(timepoint_dec_scores)
        xgen_scores_all.append(timepoint_xgen_scores)

    # Stack results into arrays of shape (n_timepoints, n_shatterings)
    scores_dec = np.array(dec_scores_all)
    scores_xgen = np.array(xgen_scores_all)

    return scores_dec, scores_xgen

def decode_across_epochs_and_time(activations, trial_types):
    """
    Perform decoding and cross-generalization analysis across all epochs and timepoints.

    For each training epoch, this function computes decoding accuracy for each timepoint
    using both standard and cross-generalization decoding. It returns both sets of scores.

    Args:
        activations (np.ndarray): Activation data of shape (n_epochs, n_trials, n_timepoints, n_neurons)
        trial_types (np.ndarray): Integer labels of shape (n_trials,) indicating trial type

    Returns:
        np.ndarray: Array of shape (2, n_epochs, n_timepoints, n_patterns), where:
            - scores[0, ...] contains decoding scores
            - scores[1, ...] contains cross-generalization scores
    """
    # Equalize trial counts across types to avoid class imbalance in decoding
    activations, trial_types, _ = equalize_trials(activations, trial_types)

    n_epochs = activations.shape[0]
    scores_all = []
    xgen_scores_all = []

    # Loop over each epoch and decode across timepoints
    for epoch in tqdm(range(n_epochs), desc='Decoding epochs'):
        # Use decoding function for a single epoch
        epoch_dec_scores, epoch_xgen_scores = decode_across_time(activations[epoch], trial_types)
        scores_all.append(epoch_dec_scores)
        xgen_scores_all.append(epoch_xgen_scores)

    # Stack results into unified score array
    scores = np.array([scores_all, xgen_scores_all])  # Shape: (2, n_epochs, n_timepoints, n_patterns)

    return scores



# --- Continual Learning Analysis ---
# Plot forgetting score matrix
def compute_forgetting_matrix(results: dict, task_sequence):
    """
    Compute a forgetting matrix based on validation accuracy at the end of each phase.

    Forgetting is defined as the drop in validation accuracy for each task 
    from the end of one phase to the end of the next. This helps measure 
    how much a model forgets previously learned tasks during continual learning.

    Args:
        results (dict): Results dictionary containing training_results, each with val_acc_per_epoch.
        task_sequence (list of lists): List of task IDs trained in each phase.

    Returns:
        forgetting (np.ndarray): Matrix of shape (n_tasks, n_phases), where each entry [i, p]
                                 is the forgetting amount for task i from phase p-1 to p.
        task_ids (list): Ordered list of all task IDs.
    """
    import numpy as np
    # Extract val_acc_per_epoch for all seeds from results dict
    val_acc_per_epoch_seeds = [r['val_acc_per_epoch'] for r in results['training_results']]
    n_seeds = len(val_acc_per_epoch_seeds)
    n_epochs = len(val_acc_per_epoch_seeds[0])
    n_phases = len(task_sequence)
    epochs_per_phase = n_epochs // n_phases  # Assume equal epochs per phase

    # Collect all unique task IDs across phases
    task_ids = sorted(set(t for phase in task_sequence for t in phase))
    n_tasks = len(task_ids)
    task_to_idx = {task: i for i, task in enumerate(task_ids)}

    # Initialize forgetting matrix with NaNs (so uncomputed values are clear)
    forgetting = np.full((n_tasks, n_phases), np.nan)

    # Collect validation accuracy at end of each phase for each task
    phase_end_accs = np.zeros((n_tasks, n_phases))
    for p in range(n_phases):
        # Index of the last epoch in this phase
        epoch_idx = (p + 1) * epochs_per_phase - 1  # Last epoch of this phase
        # Average validation accuracy across seeds at this epoch
        task_accs = {}
        for seed_acc in val_acc_per_epoch_seeds:
            for task_id, acc in seed_acc[epoch_idx].items():
                task_accs.setdefault(task_id, []).append(acc)
        avg_epoch_data = {task_id: np.mean(accs) for task_id, accs in task_accs.items()}
        # For every task with accuracy in this epoch, record its value
        for t in avg_epoch_data:
            task_idx = task_to_idx[t]
            phase_end_accs[task_idx, p] = avg_epoch_data[t]

    # Compute forgetting as the drop in accuracy from previous to current phase
    # (Skip first phase since there's no prior comparison)
    for p in range(1, n_phases):
        for t_idx in range(n_tasks):
            prev = phase_end_accs[t_idx, p - 1]
            curr = phase_end_accs[t_idx, p]
            # Only compute forgetting if both previous and current values are available
            if not np.isnan(prev) and not np.isnan(curr):
                forgetting[t_idx, p] = prev - curr

    return forgetting, task_ids


# --- Transfer Onset Latency ---
def compute_transfer_onset_latency(results: dict, task_sequence: list, threshold: float = 0.75):
    """
    Compute transfer onset latency: how many epochs it takes after task introduction
    for validation accuracy to exceed a given threshold.

    Args:
        results (dict): A model results dictionary from ExperimentRunner.
        task_sequence (list of lists): Task indices introduced in each phase.
        threshold (float): Accuracy threshold to define onset.

    Returns:
        dict: Mapping from task index to (mean_latency, sem_latency) in epochs.
    """
    val_acc_per_epoch_seeds = [r['val_acc_per_epoch'] for r in results['training_results']]
    n_epochs = len(val_acc_per_epoch_seeds[0])
    n_phases = len(task_sequence)
    epochs_per_phase = n_epochs // n_phases

    task_latencies = {}

    for seed_data in val_acc_per_epoch_seeds:
        for phase_idx, phase_tasks in enumerate(task_sequence):
            # Epochs where these tasks were introduced
            phase_start = phase_idx * epochs_per_phase
            phase_end = (phase_idx + 1) * epochs_per_phase

            for task_id in phase_tasks:
                if task_id not in task_latencies:
                    task_latencies[task_id] = []

                for e in range(phase_start, phase_end):
                    acc = seed_data[e].get(task_id, None)
                    if acc is not None and acc >= threshold:
                        latency = e - phase_start
                        task_latencies[task_id].append(latency)
                        break
                else:
                    # If threshold never reached in phase, assign max
                    task_latencies[task_id].append(epochs_per_phase)

    # Compute mean and SEM across seeds for each task
    mean_latencies = {task: np.mean(vals) for task, vals in task_latencies.items()}
    sem_latencies = {task: np.std(vals) / np.sqrt(len(vals)) for task, vals in task_latencies.items()}
    return {task: (mean_latencies[task], sem_latencies[task]) for task in task_latencies}