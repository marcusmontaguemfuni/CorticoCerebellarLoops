
"""
FixedPlasticity.py

Defines a baseline plasticity mode for CCtRNN models that performs standard recurrent updates
without any within-trial plasticity or online weight modification. This mode is intended to
serve as a control condition where learning occurs only via gradient descent applied between trials.
"""

import torch
from src.models.base_models import BasePlasticityMode
from typing import Optional, Tuple, Union, Dict, List


class FixedPlasticity(BasePlasticityMode):
    """
    Implements the fixed plasticity mode:
    A passive, baseline update rule where the RNN performs a simple forward step
    with no online weight changes within a trial. Suitable for outer-loop training methods
    like backpropagation or MAML where plasticity occurs across episodes, not within them.
    """

    def step(self, model, input_t: torch.Tensor, hidden_t: torch.Tensor):
        """
        Compute the next hidden state and output without applying any plasticity updates.

        Args:
            model: The CCtRNN model instance (provides parameters and network components).
            input_t (torch.Tensor): Input at current timestep (shape: [B, input_dim]).
            hidden_t (torch.Tensor): Hidden state at current timestep (shape: [B, hidden_dim]).

        Returns:
            If controller is enabled:
                Tuple[h_new, controller_out, output]
            Else:
                Tuple[h_new, output]
        """
        noise = model.add_noise(hidden_t)

        # Randomized input preprocessing
        if model.rnd_layer_enabled:
            input_t = model.nonlinearity(model.input2rnd(input_t))

        # With controller
        if model.controller_enabled:
            controller_out = model.controller(hidden_t)
            h_pre = (
                model.input2h(input_t) +
                model.h2h(hidden_t) +
                model.controller2h(controller_out) +
                noise
            )
            h_new = (1 - model.alpha) * hidden_t + model.alpha * model.nonlinearity(h_pre)
            output = model.output_layer(h_new)
            return h_new, controller_out, output

        # Without controller
        h_pre = model.input2h(input_t) + model.h2h(hidden_t) + noise
        h_new = (1 - model.alpha) * hidden_t + model.alpha * model.nonlinearity(h_pre)
        output = model.output_layer(h_new)
        return h_new, output
    
    