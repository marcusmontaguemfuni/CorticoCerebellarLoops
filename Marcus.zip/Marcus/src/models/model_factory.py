"""
model_factory.py

Provides utility functions to create model instances from YAML configuration files
or configuration dictionaries. Acts as the central dispatch for model instantiation
and checkpoint recovery, allowing for plug-and-play architecture variants.

Main functionalities:
- `create_model_from_config`: Create a new model from a config file or dict.
- `_create_experiment_network`: Internal method to initialize an ExperimentNetwork from config.
- `load_checkpoint_models`: Load one or more ExperimentNetwork instances from saved checkpoints.
"""

from typing import Dict, Any, Union, List
from pathlib import Path
import torch
import torch.nn as nn
import re

from src.models.experiment_network import ExperimentNetwork
from src.utils.config_handling import load_config


class ModelCreationError(Exception):
    """Raised when there's an error in model creation."""
    pass


def create_model_from_config(
        config: Union[Dict[str, Any], str, Path],
        **override_kwargs
) -> nn.Module:
    """
    Create a model instance from a configuration dictionary or YAML file.
    Supports dispatching to different model architectures.

    Args:
        config (Union[Dict[str, Any], str, Path]): Configuration dict or path to YAML file.
        override_kwargs (dict): Optional overrides to inject into the model config section.

    Returns:
        nn.Module: A model instance, typically an ExperimentNetwork.
    """
    if isinstance(config, (str, Path)):
        config = load_config(config)

    if override_kwargs:
        from src.utils.config_handling import deep_update
        config = deep_update(config, {'model': override_kwargs})

    model_type = config['model'].get('type', 'ExperimentNetwork')

    if model_type == 'ExperimentNetwork':
        return _create_experiment_network(config)

    # Add more model types here as needed
    raise ModelCreationError(f"Unsupported model type: {model_type}")


def _create_experiment_network(config: Dict[str, Any]) -> ExperimentNetwork:
    """
    Instantiate an ExperimentNetwork model from config.

    Args:
        config: Full config dictionary with separate sections for:
            - 'plasticity' (layer trainability)
            - 'model' (network architecture and learning rule)

    Returns:
        Initialized ExperimentNetwork instance.
    """
    try:
        model = ExperimentNetwork(
            # Separate plasticity controls: whether layers are trainable
            plasticity_params=config['plasticity'],
            # Architectural/algorithmic model options
            controller_params=config['model']['controller'],
            rnd_input_params=config['model']['random_input'],
            learning_rule=config['model']['learning_rule'],
            learning_rule_params=config['model'].get('learning_rule_params', {}),
            # Core architecture
            **config['model']['network']
        )
        return model

    except Exception as e:
        raise ModelCreationError(f"Failed to create ExperimentNetwork: {str(e)}")


def load_checkpoint_models(checkpoint_path: str) -> List[ExperimentNetwork]:
    """
    Load one or more models from a checkpoint file that stores multiple epochs.

    Args:
        checkpoint_path: Path to the saved checkpoint (.pt or .ckpt file)

    Returns:
        List of ExperimentNetwork models loaded from file, sorted by epoch.
    """
    checkpoint_path = Path(checkpoint_path)
    if not checkpoint_path.exists():
        raise FileNotFoundError(f"Checkpoint file not found: {checkpoint_path}")

    try:
        # Load checkpoint data
        checkpoint_data = torch.load(checkpoint_path)
        config = checkpoint_data['config']
        checkpoints = checkpoint_data['checkpoints']

        # Print number of checkpoints
        n_checkpoints = len(checkpoints)
        print(f"Loading {n_checkpoints} checkpoints from {checkpoint_path}")

        # Sort checkpoints by epoch number
        def extract_epoch(key: str) -> int:
            match = re.search(r'epoch_(\d+)', key)
            return int(match.group(1)) if match else 0

        sorted_checkpoints = sorted(checkpoints.items(), key=lambda x: extract_epoch(x[0]))

        # Load each checkpoint into a new model
        models = []
        for i, (name, state) in enumerate(sorted_checkpoints, 1):
            model = create_model_from_config(config)
            model.load_state_dict(state['model_state'])
            model.eval()
            models.append(model)
            print(f"Loaded checkpoint {i}: {name}")
            
        print(f"Successfully loaded all {n_checkpoints} checkpoints")
        return models

    except Exception as e:
        raise RuntimeError(f"Failed to load checkpoint models: {str(e)}")