"""
simple_controller.py

Defines the least biologically plausible, 'simple', feedforward cerebellar controller module for use within cortico-cerebellar 
network models. The SimpleController class, a concrete subclass of BaseCerebellarController, has configurable hidden layers 
and plasticity (trainability) for those layers. This module integrates into the overall model via the 
standard controller interface: update_controller_state and compute_control_signal methods used for computing control signals
based on the current state of the main network at each time step.
"""

import torch
import torch.nn as nn
import numpy as np
from abc import ABC
from typing import List, Dict, Union, Optional
from src.models.base_models import ActivationManager, BaseCerebellarController


class SimpleController(BaseCerebellarController):
    """
    Feedforward controller implementation with configurable plasticity, hidden layers,
    and biologically inspired features (e.g., time constants, activation functions).
    """

    def __init__(self,
                 in_dim: int,
                 out_dim: int,
                 hidden_dims: List[int] = [],
                 use_bias: bool = True,
                 nonlinearity: str = 'relu',
                 output_activation: str = 'relu',
                 input_plastic: bool = True,
                 controller_init_method: str = 'kaiming',
                 controller_init_g: float = 1.0,
                 controller_hidden_plastic: bool = True,
                 tau: float = 50.0,
                 dt: Optional[float] = None,
                 noise_std: float = 0.1, 
                 learning_rule: Optional[str] = None):
        """
        Initialize the SimpleController module.

        Args:
            in_dim (int): Input dimension size.
            out_dim (int): Output dimension size.
            hidden_dims (List[int]): List of hidden layer sizes.
            use_bias (bool): Whether to include biases in layers.
            nonlinearity (str): Activation function to use in hidden layers.
            output_activation (str): Activation function for the output layer.
            input_plastic (bool): Whether the input layer weights are trainable.
            controller_init_method (str): Weight initialization method ('kaiming', 'normal', etc).
            controller_init_g (float): Gain parameter for initialization.
            controller_hidden_plastic (bool): Whether hidden and output layer weights are trainable.
            tau (float): Optional time constant for temporal dynamics or noise shaping. Currently unused in this controller.
            dt (Optional[float]): Optional simulation timestep for temporal dynamics. Currently unused in this controller.
            noise_std (float): Standard deviation of Gaussian noise added to outputs.
        """
        plasticity_params = {
            'input_layer': input_plastic,
            'hidden_layers': controller_hidden_plastic,
            'output_layer': controller_hidden_plastic
        }

        super().__init__(
            input_size=in_dim,
            output_size=out_dim,
            hidden_dims=hidden_dims,
            tau=tau,
            dt=dt,
            noise_std=noise_std,
            nonlinearity=nonlinearity,
            init_method=controller_init_method,
            init_g=controller_init_g,
            plasticity_params=plasticity_params, 
            learning_rule=learning_rule
        )

        self.use_bias = use_bias
        self.output_activation_function = ActivationManager.get(output_activation)

        self._build_layers()
        self._setup_plasticity()

    def _build_layers(self):
        """
        Construct the feedforward network architecture for the controller.
        Creates input, (optional) hidden, and output layers, and assembles them into nn.Sequential.
        """
        layers = []
        
        if self.hidden_dims:
            # Input layer: input_size -> first hidden dim
            self.input_layer = nn.Linear(self.input_size, self.hidden_dims[0], bias=self.use_bias)
            layers.append(self.input_layer)
            layers.append(self.nonlinearity)

            # Hidden layers: hidden_dims[i] -> hidden_dims[i+1]
            self.hidden_layers = nn.ModuleList()
            for i in range(len(self.hidden_dims) - 1):
                layer = nn.Linear(self.hidden_dims[i], self.hidden_dims[i + 1], bias=self.use_bias)
                self.hidden_layers.append(layer)
                layers.append(layer)
                layers.append(self.nonlinearity)

            # Output layer: last hidden dim -> output_size
            self.output_layer = nn.Linear(self.hidden_dims[-1], self.output_size, bias=self.use_bias)
            layers.append(self.output_layer)
        else:
            # No hidden layers: input_size -> output_size
            self.input_layer = nn.Linear(self.input_size, self.output_size, bias=self.use_bias)
            layers.append(self.input_layer)

        self.main = nn.Sequential(*layers)
        
    def _get_layer_mapping(self) -> Dict[str, Union[nn.Linear, List[nn.Linear]]]:
        """
        Create a mapping from logical layer names to actual nn.Linear layers in the controller.

        Returns:
            dict: mapping with keys 'input_layer', 'output_layer', and optionally 'hidden_layers'.
        """
        mapping = {
            'input_layer': self.main[0],
            'output_layer': self.main[-1]
        }

        # Hidden layers are every second element in main, starting at index 2
        hidden_layers = [self.main[i] for i in range(2, len(self.main), 2)]
        if hidden_layers:
            mapping['hidden_layers'] = hidden_layers

        return mapping

    def _setup_plasticity(self):
        """
        Set the requires_grad property for each layer according to plasticity parameters.
        This determines which layers are trainable (plastic) during learning.
        """
        if len(self.main) >1:
            layer_map = self._get_layer_mapping()
            # Set input layer plasticity
            layer_map['input_layer'].requires_grad_(self.plasticity_params['input_layer'])

            # Set hidden layer plasticity if present
            if 'hidden_layers' in layer_map:
                for layer in layer_map['hidden_layers']:
                    layer.requires_grad_(self.plasticity_params['hidden_layers'])

            # Set output layer plasticity
            layer_map['output_layer'].requires_grad_(self.plasticity_params['output_layer'])
        else: 
            layer_map = self._get_layer_mapping()
            # Set input layer plasticity
            layer_map['input_layer'].requires_grad_(self.plasticity_params['input_layer'])

    def _initialize_weights(self):
        """
        Initialize the weights of all controller layers using the configured initialization scheme.
        """
        layer_map = self._get_layer_mapping()

        # Initialize input layer
        self.initialize_weights(layer_map['input_layer'], layer_map['input_layer'].in_features)

        # Initialize hidden layers if present
        if 'hidden_layers' in layer_map:
            for layer in layer_map['hidden_layers']:
                self.initialize_weights(layer, layer.in_features)

        # Initialize output layer
        self.initialize_weights(layer_map['output_layer'], layer_map['output_layer'].in_features)

    def update_controller_state(self, rnn_state: torch.Tensor) -> torch.Tensor:
        """
        Compute the controller's internal state given the input state.
        For a feedforward controller, this is simply a forward pass through the network.

        Args:
            rnn_state (torch.Tensor): Input state (e.g., from the RNN).
        Returns:
            torch.Tensor: Controller's internal state before output activation.
        """
        controller_state = self.main(rnn_state)
        return controller_state

    def compute_control_signal(self, controller_state: torch.Tensor) -> torch.Tensor:
        """
        Compute the final control signal from the controller's internal state.
        Applies the configured output activation function.

        Args:
            controller_state (torch.Tensor): Controller's internal state.
        Returns:
            torch.Tensor: Final control signal after output activation.
        """
        control_signal = self.output_activation_function(controller_state)
        return control_signal
    