"""
lora_controller.py

This module defines a wrapper around an existing controller (e.g., a feedforward or RNN module)
that enables task-specific low-rank adaptation using LoRA (Low-Rank Adaptation) updates.

The controller maintains:
- A frozen base controller which processes the RNN hidden state.
- A set of accumulated task-specific low-rank matrices (A), built from orthogonal basis vectors of prior tasks.
- A trainable low-rank update (B) for the current task, enforced to be orthogonal to A.

After each task, the current task basis vectors are frozen into A, and a new B is initialized.
This structure supports continual learning by preserving task-specific modulation via orthogonal subspaces.

Forward pass output = base_controller_output + (A + B) @ rnn_state
"""
import copy
import torch
import torch.nn as nn
import numpy as np
from typing import Optional, Tuple, Union, Dict, List

class LoRAController(nn.Module):
    def __init__(self, 
                 base_controller: nn.Module, 
                 input_dim: int, 
                 output_dim: int, 
                 rank: int = 1, 
                 strength: float = 1.0, 
                 init_g: float = 0.1, 
                 penalty_types: Dict[str, bool] = None):
        super().__init__()
        self.base_controller = base_controller
        self.output_dim = output_dim
        self.input_dim = input_dim
        self.rank = rank
        self.lora_strength = strength/rank
        self.lora_init_g = init_g
        self.num_tasks_seen = 0
        self.penalty_types = penalty_types if penalty_types is not None else {'basis_overlap': True, 'weight_overlap': False, 'signal_overlap': False}

        # Instantiate persistent memory for previous task representations (initialized to 0s)
        self.LoRACtrl_prev_inpt_basis = nn.Parameter(torch.zeros(self.input_dim, self.rank), requires_grad=False)
        self.LoRACtrl_prev_outpt_basis = nn.Parameter(torch.zeros(self.output_dim, self.rank), requires_grad=False)

        # Instantiate trainable LoRA basis vectors for first task
        self.LoRACtrl_curr_inpt_basis = nn.Parameter(torch.empty(self.input_dim, self.rank))
        self.LoRACtrl_curr_outpt_basis = nn.Parameter(torch.empty(self.output_dim, self.rank))


    def _initialize_weights(self):
        """
        Initializes the base controller weights and the LoRA basis vectors.
        """
        # Initialise the base controller weights
        self.base_controller._initialize_weights()

        # LoRA A matrix (input basis) → normal init
        f_in = self.input_dim
        std = self.lora_init_g / np.sqrt(f_in)
        std2 = 0.1/ np.sqrt(f_in)
        self.LoRACtrl_curr_inpt_basis.data = torch.nn.init.normal_(torch.empty((self.input_dim, self.rank)), mean=0.0, std=std)

        # LoRA B matrix (output basis) → zero init
        self.LoRACtrl_curr_outpt_basis.data = torch.nn.init.normal_(torch.empty((self.output_dim, self.rank)), mean=0.0, std=std2)

    def forward(self, rnn_state: torch.Tensor) -> torch.Tensor:
        """
        Forward pass through the LoRA controller.
        """

        # Compute the current tasks LoRA effective weight matrix
        W_current = self.LoRACtrl_curr_inpt_basis @ self.LoRACtrl_curr_outpt_basis.T 

        # Compute the past effective weight matrix (if any have been stored)
        if self.LoRACtrl_prev_inpt_basis.numel() > 0:

            W_previous = self.LoRACtrl_prev_inpt_basis @ self.LoRACtrl_prev_outpt_basis.T 
        else:
            # Zeros if no previous tasks yet
            W_previous = torch.zeros_like(W_current)

        # DEBUG CODE: Used to track weight norms in progress bar of previous and current LoRA contributions
        if self.LoRACtrl_prev_inpt_basis.numel() > 0:
            self.W_previous_contrib = torch.norm(W_previous).item()
        else:
            self.W_previous_contrib = 0.0
        self.W_current_contrib = torch.norm(W_current).item()
        
        # Combine past and current LoRA contributions
        W_LoRA_effective =  W_previous + W_current 

        # Compute the LoRA output                     
        lora_output = rnn_state @ W_LoRA_effective  
        
        # Apply activation function if specified in the base controller
        control_signal = self.base_controller.output_activation_function(lora_output)     
        
        # Add noise if specified in the base controller
        noisy_control_signal = self.base_controller.add_control_noise(control_signal)
        
        # Return the combined full controller output with LoRA contribution
        return noisy_control_signal

    def orthogonality_penalty(self, rnn_state: Optional[torch.Tensor] = None):
        
        # Initialize the orthogonality penalty to zero
        controller_orthogonality_penalty = torch.tensor(0.0, device=self.LoRACtrl_curr_inpt_basis.device)
        
        # If no previous task bases, return zero penalty
        if self.LoRACtrl_prev_inpt_basis.numel() == 0:
            return controller_orthogonality_penalty

        # ORTH METHOD 1 (default): Frobenius norm of the inner product between current and previous task basis vectors
        # This computes the overlap between the current and previous task basis vectors
        input_basis_overlap = torch.norm(self.LoRACtrl_prev_inpt_basis.T @ self.LoRACtrl_curr_inpt_basis, p='fro') ** 2
        output_basis_overlap = torch.norm(self.LoRACtrl_prev_outpt_basis.T @ self.LoRACtrl_curr_outpt_basis, p='fro') ** 2
        basis_overlap = input_basis_overlap + output_basis_overlap
        if self.penalty_types['basis_overlap']:
            controller_orthogonality_penalty += basis_overlap

        # ORTH METHOD 2: Frobenius norm between current and previous task full rank weight matrices
        # This computes the overlap between the full rank weight matrices of current and previous tasks
        W_prev = self.LoRACtrl_prev_inpt_basis @ self.LoRACtrl_prev_outpt_basis.T  # [H, O]
        W_curr = self.LoRACtrl_curr_inpt_basis @ self.LoRACtrl_curr_outpt_basis.T    # [H, O]
        weight_overlap = torch.norm(W_prev.T @ W_curr, p='fro') ** 2
        if self.penalty_types['weight_overlap']:
            controller_orthogonality_penalty += weight_overlap
        
        # ORTH METHOD 4: Intra-basis orthogonality
        # Include an intra-basis orthogonality penalty
        def intra_basis_orthogonality_penalty(B: torch.Tensor) -> torch.Tensor:
            if B.numel() == 0:
                return torch.tensor(0.0, device=B.device)
            I = torch.eye(B.shape[1], device=B.device)
            return torch.norm(B.T @ B - I, p='fro')**2
        
        intra_input = intra_basis_orthogonality_penalty(self.LoRACtrl_curr_inpt_basis)
        intra_output = intra_basis_orthogonality_penalty(self.LoRACtrl_curr_outpt_basis)
        if self.penalty_types['intra_basis_overlap']:
            controller_orthogonality_penalty += 0.05*(intra_input + intra_output)

        # ORTH METHOD 3: Cosine similarity between current and previous lora task output signals
        # This computes the overlap between the output signals generated by current and previous tasks
        signal_overlap=0
        if rnn_state is not None:
            
            # Reshape rnn_state to [T*B, H] for batch processing
            T, B, H = rnn_state.shape
            rnn_seq = rnn_state.reshape(T * B, H)

            # Compute the output signals for previous and current LoRA contributions
            W_previous_out = rnn_seq @ W_prev  
            W_current_out = rnn_seq @ W_curr 
            
            # Mean center the outputs
            W_previous_out = W_previous_out - W_previous_out.mean(dim=0, keepdim=True)
            W_current_out = W_current_out - W_current_out.mean(dim=0, keepdim=True)

            signal_overlap = nn.functional.cosine_similarity(W_previous_out, W_current_out, dim=1).mean() **2
            if self.penalty_types['signal_overlap']:
                controller_orthogonality_penalty += signal_overlap
        
        return controller_orthogonality_penalty
    
    
    def accumulate_task(self):
        """
        Accumulates the current task's LoRA basis vectors into the persistent memory of previous tasks 
        and reinitializes the current task basis vectors. This is called after each task to ensure
        that the LoRA controller retains the information from previous tasks.
        """
        # Add new basis into existing (or initialize if first)
        self.num_tasks_seen +=1
        if self.LoRACtrl_prev_inpt_basis.numel() == 0:
            self.LoRACtrl_prev_inpt_basis = nn.Parameter(self.LoRACtrl_curr_inpt_basis.detach(), requires_grad=False)
            self.LoRACtrl_prev_outpt_basis = nn.Parameter(self.LoRACtrl_curr_outpt_basis.detach(), requires_grad=False)
        else:
            # Add current bases into persistent memory
            self.LoRACtrl_prev_inpt_basis.data += (self.LoRACtrl_curr_inpt_basis.detach())
            self.LoRACtrl_prev_outpt_basis.data += (self.LoRACtrl_curr_outpt_basis.detach())

        # Initialize the new LoRACtrl basis vectors

        # LoRA Input matrix (input basis) → normal init
        f_in = self.input_dim
        std = self.lora_init_g / np.sqrt(f_in)
        std2 = 0.1/ np.sqrt(f_in)
        self.LoRACtrl_curr_inpt_basis.data = torch.nn.init.normal_(torch.empty((self.input_dim, self.rank)), mean=0.0, std=std)

        # LoRA Output matrix (output basis) → zero init
        self.LoRACtrl_curr_outpt_basis.data = torch.nn.init.normal_(torch.empty((self.output_dim, self.rank)), mean=0.0, std=std2)


    def _get_layer_mapping(self):
        """
        Extend the base controller's layer mapping to include LoRA basis vectors for metric tracking.

        Returns:
            dict: mapping with additional LoRA layers.
        """
        layer_map = self.base_controller._get_layer_mapping()
        layer_map.update({
            'LoRACtrl_curr_inpt_basis': self.LoRACtrl_curr_inpt_basis,
            'LoRACtrl_curr_outpt_basis': self.LoRACtrl_curr_outpt_basis,
            'LoRACtrl_prev_inpt_basis': self.LoRACtrl_prev_inpt_basis,
            'LoRACtrl_prev_outpt_basis': self.LoRACtrl_prev_outpt_basis
        })
        return layer_map
    
    # def expand_past_basis(self, phase_number: int):
    #     """
    #     Ensures past basis tensors are correctly shaped in a newly initialised model at the
    #     beginning of new phase, before loading previous weights/states a checkpoint.
    #     """
    #     n_tasks = phase_number-1
    #     self.LoRACtrl_prev_inpt_basis = nn.Parameter(torch.empty(self.input_dim, n_tasks * self.rank), requires_grad=False)
    #     self.LoRACtrl_prev_outpt_basis = nn.Parameter(torch.empty(self.output_dim, n_tasks * self.rank), requires_grad=False)






# IGNORE THE OUTPUT LAYER WE DO NOT USE
class LoRAOutputLayer(nn.Module):
    """
    A lora wrapper around the RNN Output readout layer that applies LoRA updates to the output.
    This is used to adapt the output of the controller to the task-specific output size.
    """
    def __init__(self, 
                 base_layer: nn.Linear, 
                 input_dim: int, output_dim: 
                 int, rank: int = 1, 
                 strength: float = 1.0, 
                 init_g: float = 0.1, 
                 penalty_types: Dict[str, bool] = None):
        super().__init__()
        self.base_layer = base_layer
        self.input_dim = input_dim
        self.output_dim = output_dim
        self.rank = rank    
        self.lora_strength = strength/rank
        self.lora_init_g = init_g
        self.penalty_types = penalty_types if penalty_types is not None else {'basis_overlap': True, 'weight_overlap': False, 'signal_overlap': False}

        # Instantiate persistent memory for previous task representations (initialized to 0s)
        self.LoRAOut_prev_inpt_basis = nn.Parameter(torch.empty(self.input_dim, 0), requires_grad=False)
        self.LoRAOut_prev_outpt_basis = nn.Parameter(torch.empty(self.output_dim, 0), requires_grad=False)

        # Instantiate trainable LoRA basis vectors for first task
        self.LoRAOut_curr_inpt_basis = nn.Parameter(torch.empty(self.input_dim, self.rank))
        self.LoRAOut_curr_outpt_basis = nn.Parameter(torch.empty(self.output_dim, self.rank))

    # def _initialize_weights(self):
    #         """
    #         Initializes the base output layer weights and the LoRA basis vectors.
    #         This method is called during the model initialization to set up the controller.
    #         """
    #         # LoRA A matrix (input basis) → normal init
    #         f_in = self.input_dim
    #         std = self.lora_init_g / np.sqrt(f_in)
    #         self.LoRAOut_curr_inpt_basis.data = torch.nn.init.normal_(torch.empty((self.input_dim, self.rank)), mean=0.0, std=std)

    #         # LoRA B matrix (output basis) → zero init
    #         self.LoRAOut_curr_outpt_basis.data = torch.zeros((self.output_dim, self.rank))
            
    
    # # DO NOT READ THIS OUTPUT LAYER CODE STOP
    # def forward(self, rnn_state: torch.Tensor) -> torch.Tensor:
    #     """
    #         Forward pass through the LoRA output layer.
    #     """
    #     # Compute the base (frozen) output layer output
    #     base_output = self.base_layer(rnn_state)

    #     # Compute the current tasks LoRA effective weight matrix
    #     W_current = self.LoRAOut_curr_inpt_basis @ self.LoRAOut_curr_outpt_basis.T    
        
    #     # Compute the past effective weight matrix (if any have been stored)
    #     if self.LoRAOut_curr_outpt_basis.numel() > 0:
    #         W_previous = self.LoRAOut_prev_inpt_basis @ self.LoRAOut_prev_outpt_basis.T 
    #     else:
    #         # Zeros if no previous tasks yet
    #         W_previous = torch.zeros_like(W_current) 

    #     # Combine past and current LoRA contributions
    #     W_LoRA_effective = W_previous + W_current  

    #     # Compute the LoRA output                     
    #     lora_output = rnn_state @ W_LoRA_effective  

    #     # Return the combined full controller output with LoRA contribution
    #     return base_output + self.lora_strength*lora_output
    
    # def orthogonality_penalty(self, rnn_state: Optional[torch.Tensor] = None):
        
    #     # Initialize the orthogonality penalty to zero
    #     output_orthogonality_penalty = torch.tensor(0.0, device=self.LoRAOut_curr_inpt_basis.device)
        
    #     # If no previous task bases, return zero penalty
    #     if self.LoRAOut_prev_inpt_basis.numel() == 0:
    #         return output_orthogonality_penalty

    #     # ORTH METHOD 1: Frobenius norm of the inner product between current and previous task basis vectors
    #     # This computes the overlap between the current and previous task basis vectors
    #     input_basis_overlap = torch.norm(self.LoRAOut_prev_inpt_basis.T @ self.LoRAOut_curr_inpt_basis, p='fro') ** 2
    #     output_basis_overlap = torch.norm(self.LoRAOut_prev_outpt_basis.T @ self.LoRAOut_curr_outpt_basis, p='fro') ** 2
    #     basis_overlap = input_basis_overlap + output_basis_overlap
    #     if self.penalty_types['basis_overlap']:
    #         output_orthogonality_penalty += basis_overlap

    #     # ORTH METHOD 2: Frobenius norm between current and previous task full rank weight matrices
    #     # This computes the overlap between the full rank weight matrices of current and previous tasks
    #     W_prev = self.LoRAOut_prev_inpt_basis @ self.LoRAOut_prev_outpt_basis.T  
    #     W_curr = self.LoRAOut_curr_inpt_basis @ self.LoRAOut_curr_outpt_basis.T    
    #     weight_overlap = torch.norm(W_prev.T @ W_curr, p='fro') ** 2
    #     if self.penalty_types['weight_overlap']:
    #         output_orthogonality_penalty += weight_overlap

    #     # ORTH METHOD 3: Cosine similarity between current and previous lora task output signals
    #     # This computes the overlap between the output signals generated by current and previous tasks
    #     signal_overlap=0
    #     if rnn_state is not None:
            
    #         # Reshape rnn_state to [T*B, H] for batch processing
    #         T, B, H = rnn_state.shape
    #         rnn_seq = rnn_state.reshape(T * B, H)

    #         # Compute the output signals for previous and current LoRA contributions
    #         W_previous_out = rnn_seq @ W_prev  
    #         W_current_out = rnn_seq @ W_curr 
            
    #         # Mean center the outputs
    #         W_previous_out = W_previous_out - W_previous_out.mean(dim=0, keepdim=True)
    #         W_current_out = W_current_out - W_current_out.mean(dim=0, keepdim=True)

    #         signal_overlap = nn.functional.cosine_similarity(W_previous_out, W_current_out, dim=1).mean() **2
    #         if self.penalty_types['signal_overlap']:
    #             output_orthogonality_penalty += signal_overlap

    #     # Optional ORTH METHOD 4: Intra-basis orthogonality
    #     # Include an intra-basis orthogonality penalty
    #     def intra_basis_orthogonality_penalty(B: torch.Tensor) -> torch.Tensor:
    #         if B.numel() == 0:
    #             return torch.tensor(0.0, device=B.device)
    #         I = torch.eye(B.shape[1], device=B.device)
    #         return torch.norm(B.T @ B - I, p='fro')**2
    #     # Compute intra-basis orthogonality penalties 
    #     intra_input = intra_basis_orthogonality_penalty(self.LoRAOut_curr_inpt_basis)
    #     intra_output = intra_basis_orthogonality_penalty(self.LoRAOut_curr_outpt_basis)
    #     # Add to the penalty if intra-basis overlap is enabled
    #     if self.penalty_types.get('intra_basis_overlap', False):
    #         output_orthogonality_penalty += intra_input + intra_output
            
            
    #     return output_orthogonality_penalty

    # def accumulate_task(self):
    #     """
    #     Accumulates the current task's LoRA basis vectors into the persistent memory of previous tasks 
    #     and reinitializes the current task basis vectors. This is called after each task to ensure
    #     that the LoRA controller retains the information from previous tasks.
    #     """
    #     # Accumulate current task bases into past memory
    #     self.LoRAOut_prev_inpt_basis = nn.Parameter(torch.cat([self.LoRAOut_prev_inpt_basis, self.LoRAOut_curr_inpt_basis.detach()], dim=1), requires_grad=False)
    #     self.LoRAOut_prev_outpt_basis = nn.Parameter(torch.cat([self.LoRAOut_prev_outpt_basis, self.LoRAOut_curr_outpt_basis.detach()], dim=1), requires_grad=False)

    #     f_in = self.input_dim
    #     std = self.lora_init_g / np.sqrt(f_in)
    #     self.LoRAOut_curr_inpt_basis.data = torch.nn.init.normal_(torch.empty((self.input_dim, self.rank)), mean=0.0, std=std)

    #     # LoRA B matrix (output basis) → zero init
    #     self.LoRAOut_curr_outpt_basis.data = torch.zeros((self.output_dim, self.rank))
    
    # def expand_past_basis(self, phase_number: int):
    #     """
    #     Ensures past basis tensors are correctly shaped in a newly initialised model at the
    #     beginning of new phase, before loading previous weights/states a checkpoint.
    #     """
    #     n_tasks = phase_number-1
    #     self.LoRAOut_prev_inpt_basis = nn.Parameter(torch.empty(self.input_dim, n_tasks * self.rank), requires_grad=False)
    #     self.LoRAOut_prev_outpt_basis = nn.Parameter(torch.empty(self.output_dim, n_tasks * self.rank), requires_grad=False)
        