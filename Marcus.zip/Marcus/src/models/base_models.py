# base_models.py

"""
This file contains the base classes for the main components of the cortico-cerebellar network models.
It provides reusable, abstract scaffolding for building cortical networks, cerebellar controllers, 
and plasticity modes. These base classes define common initialization, activations, noise handling, 
and weight initialization, allowing easy extension and customization elsewhere in the codebase.
"""

import torch
import torch.nn as nn
import numpy as np
from abc import ABC, abstractmethod
from typing import Optional, Tuple, Dict, Union, List

# ======= Activation Manager =======
"""Manages activation functions across models."""
class ActivationManager:
    FUNCTIONS = {
        'relu': nn.ReLU,
        'tanh': nn.Tanh,
        'sigmoid': nn.Sigmoid,
        'leaky_relu': nn.LeakyReLU,
        'elu': nn.ELU,
    }

    @classmethod
    def get(cls, name: str) -> nn.Module:
        """Returns the activation function given its name."""
        if name not in cls.FUNCTIONS:
            raise ValueError(f"Invalid activation '{name}'. Valid options: {list(cls.FUNCTIONS.keys())}")
        return cls.FUNCTIONS[name]()


# ======= Base Cortical Network Class =======
class BaseCorticalNetwork(nn.Module, ABC):
    """
    Defines common features of cortical RNNs: dynamics, noise, activations, and weight initialization.
    """

    def __init__(self,
                 input_size: int,
                 hidden_size: int,
                 output_size: int,
                 noise_std: float,
                 dt: float,
                 tau: float,
                 nonlinearity: str,
                 init_method: str, 
                 init_g: float):
        super().__init__()

        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size
        self.noise_std = noise_std
        self.tau = tau
        self.dt = dt
        self.alpha = dt / tau
        self.activation = ActivationManager.get(nonlinearity)
        self.init_method = init_method
        self.init_g = init_g

    @abstractmethod
    def forward(self, x: torch.Tensor, hidden: torch.Tensor = None) -> torch.Tensor:
        """Subclasses must implement the forward pass."""
        pass

    def add_noise(self, hidden: torch.Tensor) -> torch.Tensor:
        """Adds scaled Gaussian noise to the hidden state."""
        if self.noise_std > 0:
            return np.sqrt(self.alpha) * self.noise_std * torch.randn_like(hidden)
        return torch.zeros_like(hidden)

    def init_hidden(self, batch_size: int, device: torch.device = torch.device('cpu')) -> torch.Tensor:
        """Returns a zero-initialized hidden state."""
        return torch.zeros(batch_size, self.hidden_size, device=device)
    
    def initialize_weights(self, module: nn.Module, in_features: int) -> None:
        """Initializes weights of a linear layer using the chosen initialization scheme."""
        if isinstance(module, nn.Linear):
            if self.init_method == 'kaiming':
                nn.init.kaiming_normal_(module.weight, nonlinearity=self.nonlinearity)
            elif self.init_method == 'normal':
                nn.init.normal_(module.weight, mean=0.0,
                                std=self.init_g / np.sqrt(in_features))
            elif self.init_method == 'xavier':
                nn.init.xavier_uniform_(module.weight, gain=self.init_g)
            else:
                raise ValueError(f"Invalid init_method '{self.init_method}'")

            if module.bias is not None:
                nn.init.zeros_(module.bias)


# ======= Base Controller Class =======
class BaseCerebellarController(nn.Module, ABC):
    """
    Defines common features of cerebellar controllers.
    """

    def __init__(self,
                 input_size: int,
                 output_size: int,
                 hidden_dims: List[int],
                 tau: float,
                 dt: Optional[float],
                 noise_std: float,
                 nonlinearity: str,
                 init_method: str = 'normal',
                 init_g: float = 1.0, 
                 plasticity_params: Optional[Dict] = None, 
                 learning_rule: Optional[str] = None):
        super().__init__()

        self.input_size = input_size
        self.output_size = output_size
        self.hidden_dims = hidden_dims
        self.noise_std = noise_std
        self.tau = tau
        self.alpha = 1.0 if dt is None else dt / tau
        self.init_method = init_method
        self.init_g = init_g
        self.nonlinearity = self.nonlinearity = nonlinearity if callable(nonlinearity) else ActivationManager.get(nonlinearity)
        self.plasticity_params = plasticity_params or {}
        self.learning_rule = learning_rule
    
    @abstractmethod
    def update_controller_state(self, network_state: torch.Tensor) -> None:
        """Subclasses must implement updates to the controller's internal state based on cortical network state."""
        pass

    @abstractmethod
    def compute_control_signal(self, network_state: torch.Tensor) -> torch.Tensor:
        """Subclasses must implement computing the controller's final output signal."""
        pass
    
    @abstractmethod
    def _get_layer_mapping(self) -> Dict[str, Union[nn.Linear, List[nn.Linear]]]:
        """Subclasses must implement returning a dict mapping layer names to layer modules."""
        pass

    def add_control_noise(self, control_signal: torch.Tensor) -> torch.Tensor:
        """Adds noise to the controller's output signal."""
        if self.noise_std > 0:
            noise = torch.randn_like(control_signal) * self.noise_std * np.sqrt(self.alpha)
            return control_signal + noise
        return control_signal

    def initialize_weights(self, module: Union[nn.Module, nn.Parameter], in_features: int) -> None:
        """
        Initializes weights of a linear layer or parameter using the configured scheme.
        """
        if isinstance(module, nn.Linear):
            weight = module.weight
        elif isinstance(module, nn.Parameter):
            weight = module
        else:
            raise TypeError("initialize_weights only supports nn.Linear or nn.Parameter")

        if self.init_method == 'kaiming':
            nn.init.kaiming_normal_(weight, nonlinearity=self.nonlinearity)
        elif self.init_method == 'normal':
            nn.init.normal_(weight, mean=0.0, std=self.init_g / np.sqrt(in_features))
        elif self.init_method == 'xavier':
            nn.init.xavier_uniform_(weight, gain=self.init_g)
        else:
            raise ValueError(f"Invalid init_method '{self.init_method}'")

        # If it's a Linear, also zero its bias
        if isinstance(module, nn.Linear) and module.bias is not None:
            nn.init.zeros_(module.bias)

    def forward(self, network_state: torch.Tensor) -> torch.Tensor:
        """Run controller state update, compute control signal, and add noise."""
        controller_state = self.update_controller_state(network_state)
        if self.learning_rule =='lora':
            return controller_state
        control_signal = self.compute_control_signal(controller_state)
        noisy_control_signal = self.add_control_noise(control_signal)
        return noisy_control_signal
    
    
# ======= Base Plasticity Mode Class =======
class BasePlasticityMode(ABC):
    """
    Defines the interface for online plasticity modes that control how weights or state update over time through a trial.
    """

    @abstractmethod
    def step(self, model: nn.Module, input_t: torch.Tensor, hidden_t: torch.Tensor):
        """Compute the next hidden state and optionally apply plasticity."""
        pass

    def reset(self):
        """Optional: Reset any plasticity-related state."""
        pass

    def update_weights(self):
        """Optional: Apply weight updates at the end of an episode."""
        pass
    
    def get_layer_mapping(self) -> Dict[str, Tuple[nn.Module, str]]:
        """
        Optional: Return dictionary mapping names to (layer, param) tuples
        for plasticity-related parameters.
        """
        return {}

    def get_weights(self) -> Dict[str, torch.Tensor]:
        """
        Optional: Return internal learnable parameters (e.g., modulatory weights).
        """
        return {}
    
    def get_gradients(self) -> Dict[str, Optional[torch.Tensor]]:
        """
        Optional: Return dictionary of gradient-like quantities for internal plasticity parameters.
        """
        return {}