"""
experiment_network.py

Defines the ExperimentNetwork wrapper class, which wraps a CCtRNN model, 
layer access utilities, and activation/gradient inspection methods. This 
class serves as the experimental interface for training and evaluating 
modular controlled-RNN models with different plasticity modes and controllers.
"""

import torch
import torch.nn as nn
import numpy as np
from typing import Dict, Tuple, Optional, List, Union

from src.models.controller_networks import CCtRNN


class ExperimentNetwork(nn.Module):
    """
    Wrapper class for running experiments with a CCtRNN model.
    Adds output layer, initialization tools, weight/gradient access,
    and hidden state readouts for use in training and analysis.
    """
    @staticmethod
    def set_seed(seed: int) -> None:
        """
        Set seeds for reproducible weight initialization.

        Args:
            seed (int): Random seed value.
        """
        torch.manual_seed(seed)
        np.random.seed(seed)

        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
            torch.backends.cudnn.deterministic = True
            torch.backends.cudnn.benchmark = False
            
    def __init__(self,
             plasticity_params: Dict,
             controller_params: Dict,
             rnd_input_params: Dict,
             learning_rule: str,
             learning_rule_params: Dict,
             tau: float,
             dt: float,
             nonlinearity: str,
             init_method: str,
             init_g: float,
             input_size: int,
             hidden_size: int,
             output_size: int,
             noise_std: float,
             **kwargs):
        super().__init__()

        self.learning_rule = learning_rule
        self.learning_rule_params = learning_rule_params
        self.hidden_size = hidden_size
        self.output_size = output_size
        self.nonlinearity = nonlinearity
        self.init_method = init_method
        self.init_g = init_g

        # Set defaults for controller controller hidden layer structure (e.g., [30, 30] for 2 layers)
        if not controller_params.get('enabled', False):
            controller_hidden_dims = []
        else:
            controller_hidden_dims = [controller_params.get("controller_hidden_size", 30)] * controller_params.get("controller_hidden_n", 1)

        # Initialize specified CCtRNN
        self.model = CCtRNN(
            # Cortical RNN params
            input_size=input_size,
            input_plastic=plasticity_params['input_plastic'],
            hidden_size=hidden_size,
            hidden_plastic=plasticity_params['hidden_plastic'],
            output_size=output_size,
            output_plastic=plasticity_params['output_plastic'],
            rnd_layer_enabled=rnd_input_params['enabled'],
            rnd_size=rnd_input_params['size'],
            noise_std=noise_std,
            dt=dt,
            tau=tau,
            nonlinearity=nonlinearity,
            init_method=init_method,
            init_g=init_g,
            # Cerebellar controller params
            controller_enabled=controller_params['enabled'],
            controller_type=controller_params['type'],
            h2controller_plastic=plasticity_params['h2controller_plastic'],
            controller_hidden_plastic=plasticity_params['controller_hidden_plastic'],
            controller_hidden_dims=controller_hidden_dims,
            controller2h_plastic=plasticity_params['controller2h_plastic'],
            controller_output_size=controller_params['output_size'],
            controller_init_method=controller_params['controller_init_method'],
            controller_init_g=controller_params['controller_init_g'],
            controller_output_activation=controller_params['output_activation'],
            # Learning rule params
            learning_rule=learning_rule,
            learning_rule_params=learning_rule_params,
            **kwargs
        )

        self.model._initialize_weights()


    def forward(self, input_trial: torch.Tensor) -> Union[
    Tuple[torch.Tensor, torch.Tensor, torch.Tensor],
    Tuple[torch.Tensor, torch.Tensor]]:
        """
        Forward pass through the wrapped CCtRNN model.

        Args:
            input_trial (torch.Tensor): Input tensor of shape (T, B, input_dim)

        Returns:
            Tuple of (output sequence, hidden state sequence [, controller sequence])
        """
        if self.model.controller_enabled:
            hidden_seq, output_seq, controller_seq = self.model(input_trial)
            return output_seq, hidden_seq, controller_seq
        else:
            hidden_seq, output_seq = self.model(input_trial)
            return output_seq, hidden_seq
        
    def _get_layer_mapping(self) -> Dict[str, Tuple[nn.Module, str]]:
        """
        Create a mapping of named layers to their modules and parameter names (e.g. 'weight').
        This is used for consistent weight and gradient access across RNN and controller layers.

        Returns:
            Dict mapping string layer names to tuples of (layer_module, parameter_name)
        """
        # RNN layer mapping
        mapping = {
            "input2h": (self.model.input2h, "weight"),
            "h2h": (self.model.h2h, "weight")
        }

        if self.learning_rule == 'lora' and self.learning_rule_params['output_layer'] == True:
            mapping["base_output"] = (self.model.output_layer.base_layer, "weight")
            mapping["LoRAOut_curr_inpt_basis"] = (self.model.output_layer.LoRAOut_curr_inpt_basis, "data")
            mapping["LoRAOut_curr_outpt_basis"] = (self.model.output_layer.LoRAOut_curr_outpt_basis, "data")
        else:
            mapping["output"] = (self.model.output_layer, "weight")

        # Controller layer mapping
        if self.model.controller_enabled:
            controller_layers = self.model.controller._get_layer_mapping()
            # Input and output layers
            mapping["h2controller"] = (controller_layers["input_layer"], "weight")
            mapping["controller2h"] = (self.model.controller2h, "weight")
            # Hidden layers (if any)
            if "hidden_layers" in controller_layers:
                for idx, layer in enumerate(controller_layers["hidden_layers"]):
                    mapping[f"controller_hidden_{idx}"] = (layer, "weight")

            # LoRA basis vectors for current task (if present)
            if "LoRACtrl_curr_inpt_basis" in controller_layers:
                mapping["LoRACtrl_curr_inpt_basis"] = (controller_layers["LoRACtrl_curr_inpt_basis"], "data")
            if "LoRACtrl_curr_outpt_basis" in controller_layers:
                mapping["LoRACtrl_curr_outpt_basis"] = (controller_layers["LoRACtrl_curr_outpt_basis"], "data")

        # Plasticity mode layer mappings
        plasticity_layers = self.model.plasticity_mode.get_layer_mapping()
        for name, (layer, param) in plasticity_layers.items():
            # Include 'plasticity.' to distinguish from regular layers
            mapping[f"plasticity.{name}"] = (layer, param)

        return mapping

    def get_weights(self) -> Dict[str, torch.Tensor]:
        """
        Retrieve all model weights as a dictionary, using consistent naming and CPU-cloned values.

        Returns:
            Dictionary mapping layer names to CPU-cloned weight tensors.
        """
        mapping = self._get_layer_mapping()
        weights = {}

        for name, (layer, param_name) in mapping.items():
            param = getattr(layer, param_name, None)
            if param is not None:
                weights[name] = param.data.clone().cpu()
        return weights
    
    def get_gradient(self, layer_name: str) -> Optional[torch.Tensor]:
        """
        Retrieve gradient for a specific layer. For plasticity-specific layers,
        use the plasticity mode's internal gradient dictionary.

        Args:
            layer_name (str): Name of the layer, e.g., 'h2h' or 'plasticity.eligibility_traces'.
        Returns:
            torch.Tensor or None: Gradient tensor on CPU, or None if unavailable
        """
        mapping = self._get_layer_mapping()

        # Check if requested layer_name is in the mapping
        if layer_name not in mapping:
            raise ValueError(f"Layer '{layer_name}' not found. Use get_available_layers() to check valid names.")
        
        # Check if it's a plasticity_mode-specific layer
        if layer_name.startswith("plasticity."):
            # Strip 'plasticity.' prefix to match keys in get_gradients()
            plasticity_key = layer_name[len("plasticity."):]
            grad_dict = self.model.plasticity_mode.get_gradients()
            grad = grad_dict.get(plasticity_key, None)
            return grad.detach().clone().cpu() if grad is not None else None

        # Otherwise: standard layer gradient
        layer, param_name = mapping[layer_name]
        param = getattr(layer, param_name, None)
        grad = param.grad if param is not None else None

        return grad.detach().clone().cpu() if grad is not None else None
    
    def get_available_layers(self):
        """
        Get list of available layer names for weight/gradient access.

        Returns:
            list: Names of available layers
        """
        return list(self._get_layer_mapping().keys())
    
    def validate_plasticity_config(self, plasticity_params: Dict) -> None:
        """
        Validate that the model's plasticity flags match the expected config values.

        Args:
            plasticity_params (Dict): Dictionary of expected plasticity settings.
        
        Raises:
            ValueError: If any plasticity setting does not match the model's actual config.
        """
        model_plasticity = {
            'input_plastic': self.model.input2h.weight.requires_grad,
            'hidden_plastic': self.model.h2h.weight.requires_grad,
            'output_plastic': self.model.output_layer.weight.requires_grad
        }

        controller_keys = ['h2controller_plastic', 'controller2h_plastic', 'controller_hidden_plastic']
        if self.model.controller_enabled:
            model_plasticity.update({
                'h2controller_plastic': self.model.controller.main[0].weight.requires_grad,
                'controller2h_plastic': self.model.controller2h.weight.requires_grad,
                'controller_hidden_plastic': all(layer.weight.requires_grad
                                                for layer in self.model.controller.main[2::2])
            })
        else:
            # Exclude controller-related keys from validation
            plasticity_params = {k: v for k, v in plasticity_params.items() if k not in controller_keys}

        mismatches = [f"{k}: expected {v}, got {model_plasticity.get(k)}"
                    for k, v in plasticity_params.items()
                    if model_plasticity.get(k) != v]

        if mismatches:
            raise ValueError("Plasticity config mismatch:\n" + "\n".join(mismatches))

    def get_activations(
        self,
        X: torch.Tensor,
        y: torch.Tensor,
        mask: torch.Tensor
    ) -> Tuple[np.ndarray, float]:
        """
        Run the model on a batch of trials and return hidden activations and classification accuracy.

        Args:
            X (torch.Tensor): Input tensor of shape (batch_size, timesteps, input_dim)
            y (torch.Tensor): Target tensor of shape (batch_size, timesteps, output_dim)
            mask (torch.Tensor): Boolean tensor of same shape as y indicating valid timesteps

        Returns:
            Tuple:
                - hidden state activations as NumPy array (batch, hidden_units, timesteps)
                - float accuracy score over masked positions
        """
        self.eval()
        with torch.no_grad():
            if self.model.controller_enabled:
                outputs, hidden_states, _ = self(X.transpose(0, 1))
            else:
                outputs, hidden_states = self(X.transpose(0, 1))

            outputs_masked = outputs[mask]
            targets_masked = y.transpose(0, 1)[mask]

            outputs_flat = outputs_masked.reshape(-1, outputs_masked.shape[-1])
            targets_flat = targets_masked.reshape(-1, targets_masked.shape[-1])

            accuracy = (outputs_flat.argmax(1) == targets_flat.argmax(1)).float().mean().item()
            activations = hidden_states.transpose(0, 1).cpu().numpy()

        return activations, accuracy