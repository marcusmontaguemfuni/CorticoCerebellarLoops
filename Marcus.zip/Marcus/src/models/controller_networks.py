"""
controller_networks.py

Defines the core CCtRNN model class — a modular recurrent network that integrates optional 
controller architectures and different online plasticity modes. This model is designed for 
use in meta-learning and biologically inspired learning experiments.

The CCtRNN class handles:
- Construction of an RNN with optional randomized input preprocessing
- Integration of swappable external cerebellar controller subclasses
- Support for swappable online plasticity rules for hidden state updates 
  via delegation of single-timestep logic to a plasticity_mode class
"""

import torch
import torch.nn as nn
from typing import Optional, Tuple, Union, Dict, List

from src.models.base_models import BaseCorticalNetwork
from src.models.base_models import ActivationManager
from src.models.controllers.simple_controller import SimpleController
from src.models.controllers.lora_controller import LoRAController, LoRAOutputLayer
from src.models.cortical_plasticity_modes.FixedPlasticity import FixedPlasticity


class CCtRNN(BaseCorticalNetwork):
    """
    Controlled Continuous-time RNN Model.

    A recurrent neural network with optional cerebellar-like controller and modular 
    plasticity rule system. Designed for use in online learning and meta-learning experiments.
    """
    def __init__(self,
                 # Cortical RNN params
                 input_size: int,
                 input_plastic: bool, 
                 hidden_size: int,
                 hidden_plastic: bool,
                 output_size: int,
                 output_plastic: bool,
                 rnd_layer_enabled: bool, 
                 rnd_size: int,
                 noise_std: float,
                 dt: Optional[float],
                 tau: float,
                 nonlinearity: str,
                 init_method: str,
                 init_g: float,
                 # Cerebllar controller params
                 controller_enabled: bool,
                 controller_type: str, 
                 h2controller_plastic: bool, 
                 controller_hidden_plastic: bool,
                 controller_hidden_dims: List[int],
                 controller2h_plastic: bool,
                 controller_output_size: int,
                 controller_init_method: str, 
                 controller_init_g: float,
                 controller_output_activation: str,
                 # Learning rule params
                 learning_rule: str,
                 learning_rule_params: Optional[Dict]):
        
        # Pass base parameters to the BaseCorticalNetwork class and store others
        super().__init__(input_size, hidden_size, output_size, noise_std, dt, tau,
                         nonlinearity, init_method, init_g)
        self.input_plastic = input_plastic
        self.hidden_plastic = hidden_plastic
        self.output_plastic = output_plastic
        self.rnd_layer_enabled = rnd_layer_enabled
        self.rnd_size = rnd_size
        self.controller_enabled = controller_enabled
        self.controller_type = controller_type
        self.controller2h_plastic = controller2h_plastic
        self.h2controller_plastic = h2controller_plastic
        self.controller_hidden_plastic = controller_hidden_plastic
        self.controller_hidden_dims = controller_hidden_dims
        self.controller_output_size = controller_output_size
        self.controller_init_method = controller_init_method
        self.controller_init_g = controller_init_g
        self.controller_output_activation = controller_output_activation
        self.learning_rule = learning_rule
        self.learning_rule_params = learning_rule_params or {}
        self.nonlinearity = ActivationManager.get(nonlinearity)

        # Initialize plasticity mode used for online updates
        self.plasticity_mode = self.PlasticityMode()

        # Initialize controller if enabled
        if self.controller_enabled:
            self.controller = self.Controller()
            # Check if using LoRA for task-specific adaptation
            if learning_rule == 'lora':
                # Wrap the controller in a LoRAController for task-specific adaptation
                self.controller = LoRAController(base_controller=self.controller,
                                                input_dim=hidden_size,
                                                output_dim=self.controller_output_size,
                                                rank=self.learning_rule_params.get('lora_rank', 1),
                                                strength=self.learning_rule_params.get('lora_strength', 1.0),
                                                init_g=self.learning_rule_params.get('lora_init_g', 0.1),
                                                penalty_types=self.learning_rule_params.get('penalty_types', {}),
                                                #concat_past_bases = learning_rule_params.get('concat_past_bases', False)
                                                )
            self.controller2h = nn.Linear(controller_output_size, hidden_size)
            self.controller2h.requires_grad_(controller2h_plastic)

        # Initialise RNN network layers
        # Input-to-hidden layer
        if self.rnd_layer_enabled:
            self.input2rnd = nn.Linear(input_size, rnd_size)
            self.input2h = nn.Linear(rnd_size, hidden_size)
            self.input2rnd.requires_grad_(False)
            self.effective_input_size = rnd_size
        else:
            self.input2h = nn.Linear(input_size, hidden_size)
            self.effective_input_size = input_size
        self.input2h.requires_grad_(input_plastic)

        # Hidden-to-hidden layer
        self.h2h = nn.Linear(hidden_size, hidden_size)
        self.h2h.requires_grad_(hidden_plastic)

        # Output layer
        if learning_rule == 'lora' and learning_rule_params['output_layer']== True:
            self.output_layer = LoRAOutputLayer(base_layer=nn.Linear(hidden_size, output_size).requires_grad_(False),
                                                input_dim=hidden_size,
                                                output_dim=output_size,
                                                rank=self.learning_rule_params.get('lora_rank', 1),
                                                strength=self.learning_rule_params.get('lora_strength', 1.0),
                                                init_g=self.learning_rule_params.get('lora_init_g', 0.1),
                                                penalty_types=self.learning_rule_params.get('penalty_types', {})
                                                )
        else:
            self.output_layer = nn.Linear(hidden_size, output_size)
            self.output_layer.requires_grad_(output_plastic)
        
        # Initialize all model weights
        self._initialize_weights()

    def PlasticityMode(self):
        """
        Create and return the appropriate plasticity mode object based on self.learning_rule.

        Returns:
            A subclass of BasePlasticityMode corresponding to the selected learning rule.
        """
        if self.learning_rule == 'standard_bp':
            return FixedPlasticity()
        elif self.learning_rule == 'lora':
            return FixedPlasticity()  # LoRA is handled in the controller
        else:
            raise ValueError(f"Unsupported plasticity mode: {self.learning_rule}")

    def Controller(self) -> nn.Module:
        """
        Initialize and return the appropriate controller object based on self.controller_type.

        Returns:
            A PyTorch module implementing the selected controller architecture.
        """
        if self.controller_type == 'simple':
            return SimpleController(
                in_dim=self.hidden_size,
                out_dim=self.controller_output_size,
                hidden_dims=self.controller_hidden_dims,
                nonlinearity=self.nonlinearity,
                output_activation=self.controller_output_activation,
                input_plastic=self.h2controller_plastic,
                controller_init_method=self.controller_init_method,
                controller_init_g=self.controller_init_g,
                controller_hidden_plastic=self.controller_hidden_plastic,
                tau=self.tau,
                dt=self.dt,
                noise_std=self.noise_std, 
                learning_rule=self.learning_rule
            )
        else:
            raise ValueError(f"Unsupported controller type: {self.controller_type}")

    def _initialize_weights(self):
        """
        Initialize weights for all layers in the network using parent class methods.
        """
        # Input weights
        if self.rnd_layer_enabled:
            self.initialize_weights(self.input2rnd, self.input2rnd.in_features)
        self.initialize_weights(self.input2h, self.effective_input_size)
        # Hidden weights
        self.initialize_weights(self.h2h, self.h2h.in_features)
        # Output weights
        if isinstance(self.output_layer, LoRAOutputLayer):
            # Init the base layer of the LoRA output layer using RNN initialization
            self.initialize_weights(self.output_layer.base_layer, self.output_layer.base_layer.in_features)
            # Initialize the LoRA-specific parameters
            self.output_layer._initialize_weights()
        else:
            self.initialize_weights(self.output_layer, self.output_layer.in_features)
        
        # Controller
        if self.controller_enabled:
            self.initialize_weights(self.controller2h, self.controller2h.in_features)
            self.controller._initialize_weights()
    
    
    def forward(self, input: torch.Tensor, hidden: Optional[torch.Tensor] = None) -> Union[
        Tuple[torch.Tensor, torch.Tensor, torch.Tensor],
        Tuple[torch.Tensor, torch.Tensor]]:
        """
        Forward pass through a full trial, computing hidden states, readout outputs, and optional controller signals.

        Args:
            input (torch.Tensor): Input tensor of shape (timesteps, batch_size, input_dim)
            hidden (Optional[torch.Tensor]): Optional initial hidden state

        Returns:
            If controller is enabled:
                Tuple of hidden states (T, B, H), outputs (T, B, O), and controller outputs (T, B, C)
            Else:
                Tuple of hidden states (T, B, H), outputs (T, B, O)
        """
        
        if hidden is None:
            hidden = self.init_hidden(input.shape[1], input.device)

        hidden_all = []
        output_all = []
        controller_outputs = [] if self.controller_enabled else None

        for t in range(input.size(0)):
            # Compute next step via plasticity mode (handles hidden, controller, and output)
            if self.controller_enabled:
                hidden, controller_out, output = self.plasticity_mode.step(self, input[t], hidden)
                controller_outputs.append(controller_out)
            else:
                hidden, output = self.plasticity_mode.step(self, input[t], hidden)

            hidden_all.append(hidden)
            output_all.append(output)

        # Stack collected outputs
        hidden_all = torch.stack(hidden_all, dim=0)      
        output_all = torch.stack(output_all, dim=0)      

        if self.controller_enabled:
            controller_outputs = torch.stack(controller_outputs, dim=0)  
            return hidden_all, output_all, controller_outputs

        return hidden_all, output_all
    
